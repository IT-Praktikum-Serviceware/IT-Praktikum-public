# Internal names for objects and links in the AIPE that are used as constants in our code
BASE_URL = "https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/data"

# Objects
SKILLS = "skills"                                       # our main skill object
REQUESTS = "request"                                    # our main request object
USER = "user"                                           # our main user object
FEEDBACK = "feedback-2"

# Object groups
REQUESTS_GROUP = "requests"
SKILLS_GROUP = "skills-2"
FEEDBACK_GROUP = "feedbacks"

# Specifications, these were predefined
CATALOG_ITEM = "sys-catalog-item"
CONSUMER_FEEDBACK = "consumer-feedback"
CONSUMER_REQUEST = "sys-consumer-request"

# Link definitions and the according relation names
ROUTING = "routing"                                     # our main request to user and vice versa link
ROUTING_RELATION_NAME = "routed-to"                     # our main request to user link definition name
ROUTING_RELATION_NAME_OTHER = "working-on"

USER_HAS_SKILLS = "user-has-skills"                     # our main skill to user and vice versa link
USER_HAS_SKILLS_RELATION_NAME = "skills-to-user"        # our main skill to user link definition name
USER_HAS_SKILLS_RELATION_NAME_OTHER = "user-has-skills"

FEEDBACK_LINK = "feedback-link"
FEEDBACK_LINK_RELATION_NAME = "feedback-to-request"
FEEDBACK_LINK_RELATION_NAME_OTHER = "request-has-feedback"

USER_HAS_FEEDBACK = "user-has-feedback"
USER_HAS_FEEDBACK_RELATION_NAME = "feedback-of-user"
USER_HAS_FEEDBACK_RELATION_NAME_OTHER = "user-feedback"
# These were predefined
AGENT_TO_USER = "agent-to-user-result"
AGENT_TO_USER_RELATION_NAME = "user-to-user"
AGENT_TO_USER_RELATION_NAME_OTHER = "user-to-user-2"

CATALOG_ITEM_REQUESTS = "sys-catalog-item-requests"
CATALOG_ITEM_REQUESTS_RELATION_NAME = "item-requests"
CATALOG_ITEM_REQUESTS_RELATION_NAME_OTHER = "requested-item"

REQUESTER_LINK = "sys-requester-link"
REQUESTER_LINK_RELATION_NAME = "requester"
REQUESTER_LINK_RELATION_NAME_OTHER = "requester-of"
