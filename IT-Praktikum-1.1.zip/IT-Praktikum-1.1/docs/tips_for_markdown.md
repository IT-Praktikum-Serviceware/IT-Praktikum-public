
## Tips to write markdown files:
- To write a list use either a hyphen or the according number with subpoints being able to be listed with an insertion of tab:
    - Unordered point
        - unordered subpoint

    1. ordered point 1
        1. subordered point 1
    2. ordered point 2
- To write bold text use two asterisks:
    - **bold**
- To wirte italic text use one asterisk:
    - *italic*
- To ignore Markdown formatting characters, use \ before the character:
    - This is not \*italicized* style
- For a line break, enter 2 spaces and then press enter
    - This is
    no line break
    - This is 
    no line break
    - This is  
    a line break
- To write hyperlinks use a pair of square brackets for the text of the link and a pair of round brackets for the URL following that:
    - [hyperlink](URLhere)
- To add images, use a exclamation mark, a pair of square brackets for the title of the image and a pair of round brackets for the file path where you enter the relational image path location:
    ![saul-goodman-here](assets/it-praktikum-v3.0.png)
- To write multi-line code in the readme use three backticks before and after the block of code:
    ```
    i = 10
    for j in range(i + 1):
        print(j)
    ``` 
- To write inline code in the readme use just one backtick:
    - Like this: `print("Hello World")`.
- To use headlines use # for H1, ## for H2, ### for H3 and so on:
    - # H1
    - ## H2
    - ### H3
    - #### H4
    - ##### H5
    - ###### H6
    - ###### H7