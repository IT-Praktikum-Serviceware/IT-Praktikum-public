import os
import sys
import json

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
from main.rest_api.api_functions import Get, Update, Create, Util, ChatGPT, get_access_token
from main.openai_api import chatgpt_query
import aipe_config

access_token = get_access_token()

def get_all_routed_to(access_token: str) -> list:
    """
    Holt alle Requests und bestimmt effizient die Agenten.

    :param access_token: Access-Token to authenticate.
    :return: List with "request", "skills" and "agent_id".
    """
    all_requests = Get.get_all_objects_by_type(aipe_config.REQUESTS, access_token)
    routed_requests = []
    
    for req in all_requests:
        request_id = req["system"].get("id", "N/A")

        description = req.get("description", "N/A") # Hier das Komma entfernt
        # Extrahieren des 'subject' und 'description'
        subject = req.get("subject", "N/A")
      
        # Hole die Agenten-ID
        agent_id = Get.get_current_linked_agent(str(request_id), access_token)
        
        # Erstelle das Format, das du benötigst
        routed_requests.append({
            "request_id":request_id,
            "subject": subject, # 'subject' als 'request'
            "description": description,  
            "agent_id": [agent_id] # Agenten-ID als Liste
        })
    return routed_requests # Rückgabe der angepassten Liste im gewünschten Format

if __name__ == "__main__": 
    print(get_all_routed_to(access_token))
