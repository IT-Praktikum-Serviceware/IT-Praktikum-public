import os
import sys
import json

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from main.rest_api.api_functions import Get, Util, get_access_token
from main.openai_api import chatgpt_skill_analyze_rating
#Abrufung des Zugriffstokens 
access_token = get_access_token()

test = [
    {
    "request_id": "AXWqRo",
    "subject": "Effiziente Performanceoptimierung von Systemen",
    "description": "Analysieren und optimieren Sie die Performance bestehender Systeme oder Anwendungen. Identifizieren Sie Engpässe, implementieren Sie effiziente Lösungen und verbessern Sie Ladezeiten, Reaktionsfähigkeit sowie Ressourcennutzung. Der Fokus liegt auf Skalierbarkeit, Stabilität und nachhaltiger Leistungssteigerung.",
    "expected_skill": "Performanceoptimierung - gut",
    "agent_id": ["442847"]
    },
    {
    "request_id": "1jMtTe",
    "subject": "Optimierung der Frontend-Performance und Benutzererfahrung",
    "description": "Analysieren und optimieren Sie die Frontend-Performance einer Webanwendung. Reduzieren Sie Ladezeiten, verbessern Sie die Responsivität und stellen Sie eine optimale User Experience sicher. Der Fokus liegt auf effizientem Code, Browser-Kompatibilität und einer flüssigen Bedienung.",
    "expected_skill": "Frontendoptimierung - mittel",
    "agent_id": ["442848"]
    },
    {
    "request_id": "bgGzvF",
    "subject": "Effiziente und sichere Datenmigration",
    "description": "Planen und führen Sie eine Datenmigration zwischen Systemen oder Datenbanken durch. Stellen Sie sicher, dass die Datenintegrität erhalten bleibt, minimieren Sie Ausfallzeiten und optimieren Sie den Migrationsprozess. Der Fokus liegt auf Automatisierung, Validierung und Fehlervermeidung.",
    "expected_skill": "Datenmigration - mittel",
    "agent_id": ["442849"]
    },
    {
    "request_id": "bgGzvF",
    "subject": "Effiziente Optimierung von Datenbanken",
    "description": "Analysieren und optimieren Sie die Performance einer Datenbank. Identifizieren Sie Engpässe, verbessern Sie Abfragen, Indexierung und Speicherstrategien, um Geschwindigkeit und Effizienz zu steigern. Der Fokus liegt auf Skalierbarkeit, Reduzierung von Latenzen und ressourcenschonendem Betrieb.",
    "expected_skill": "Datenbankoptimierung - mittel",
    "agent_id": ["442850"]
    },
    {
    "request_id": "zmSGxJ",
    "subject": "Sichere und effiziente Authentifizierungsverfahren",
    "description": "Analysieren und optimieren Sie bestehende Authentifizierungsmechanismen. Implementieren Sie sichere Anmeldeverfahren, Multi-Faktor-Authentifizierung (MFA) und rollenbasierte Zugriffskontrollen. Der Fokus liegt auf Sicherheit, Benutzerfreundlichkeit und Schutz vor unautorisiertem Zugriff.",
    "expected_skill": "	Zwei-Faktor-Authentifizierung - mittel",
    "agent_id": ["442846"]
    },
    {
    "request_id": "0Q9V7GT",
    "subject": "Effiziente Fehlerbehebung im Netzwerk",
    "description": "Identifizieren und beheben Sie Netzwerkprobleme zur Sicherstellung einer stabilen und performanten IT-Infrastruktur. Entwickeln Sie Strategien zur Fehleranalyse, Protokollüberwachung und schnellen Störungsbeseitigung. Der Fokus liegt auf Systemverfügbarkeit, Performance-Optimierung und Sicherheitsaspekten.",
    "expected_skill": "Netzwerkfehlerbehebung - gut",
    "agent_id": ["442842"]
    },
    {
    "request_id": "FXN1TBZ",
    "subject": "Effiziente Verwaltung von Benutzerrollen",
    "description": "Überprüfen und optimieren Sie die Benutzerrollenverwaltung zur Sicherstellung einer sicheren und bedarfsgerechten Zugriffskontrolle. Entwickeln Sie Richtlinien zur Vergabe, Änderung und Deaktivierung von Benutzerrechten. Der Fokus liegt auf Sicherheit, Compliance und operativer Effizienz.",
    "expected_skill": "Benutzerrollenverwaltung - gut",
    "agent_id": ["442850"]
    },
    {
    "request_id": "DHAT0RT",
    "subject": "Effiziente Fehleranalyse und Debugging von APIs",
    "description": "Identifizieren und beheben Sie Fehler in API-Integrationen zur Sicherstellung einer reibungslosen Kommunikation zwischen Systemen. Entwickeln Sie Strategien zur Protokollierung, Analyse und Optimierung von API-Anfragen und -Antworten. Der Fokus liegt auf Stabilität, Performance und Sicherheit.",
    "expected_skill": "Fehlermeldungsanalyse - schlecht",
    "agent_id": ["442844"]
    },
    {
    "request_id": "DHATGRT",
    "subject": "Effiziente mehrsprachige Unterstützung",
    "description": "Unterstützen Sie Benutzer in mehreren Sprachen, um eine reibungslose Kommunikation und Problemlösung zu gewährleisten. Entwickeln Sie Strategien zur Optimierung sprachübergreifender Support-Prozesse. Der Fokus liegt auf Verständlichkeit, Kundenzufriedenheit und kultureller Sensibilität.",
    "expected_skill": "mehrsprachige Unterstützung - mittel",
    "agent_id": ["442845"]
    },
    {
    "request_id": "C9ZWTQD",
    "subject": "Effektive Protokollierung der Benutzeraktivitäten",
    "description": "Überwachen und analysieren Sie Benutzeraktivitäten zur Verbesserung der Sicherheit und Nachvollziehbarkeit von Systemzugriffen. Entwickeln Sie Strategien zur effektiven Erfassung, Speicherung und Auswertung von Protokolldaten. Der Fokus liegt auf Compliance, Sicherheitsüberwachung und operativer Transparenz.",
    "expected_skill": "Benutzeraktivitätsprotokollierung - gut",
    "agent_id": ["442848"]
    },
    {
    "request_id": "SRHMH36",
    "subject": "Grundlegende Passwortsicherheit",
    "description": "Unterstützen Sie bei einfachen Aufgaben zur Passwortsicherheit, wie der Überprüfung grundlegender Sicherheitsrichtlinien und der Sensibilisierung für sichere Passwörter. Leiten Sie komplexere Sicherheitsprobleme an das zuständige Team weiter. Der Fokus liegt auf grundlegender Sicherheitsbewusstheit und Passwortverwaltung.",
    "expected_skill": "Passwortsicherheit - schlecht",
    "agent_id": ["443033"]
     },
     {
    "request_id": "NGQ7NFQ",
    "subject": "Minimale Kenntnisse zur Passwortsicherheit",
    "description": "Unterstützen Sie bei einfachsten Aufgaben zur Passwortsicherheit, wie dem Zurücksetzen vergessener Passwörter und der Anwendung grundlegender Sicherheitsregeln. Fortgeschrittene Sicherheitsmaßnahmen oder tiefgehende Analysen sind nicht erforderlich. Der Fokus liegt auf Basiswissen und einfacher Unterstützung.",
    "expected_skill": "Passwortsicherheit - schlecht",
    "agent_id": ["443033"]
    },
    {
    "request_id": "V6JBPY6",
    "subject": "Effektive Verwaltung von Sicherheitswarnungen",
    "description": "Überwachen und analysieren Sie Sicherheitswarnungen, um potenzielle Bedrohungen frühzeitig zu erkennen und angemessene Maßnahmen zu ergreifen. Entwickeln Sie Prozesse zur schnellen Identifikation, Priorisierung und Eskalation von Sicherheitsvorfällen. Der Fokus liegt auf Bedrohungserkennung, Reaktionsschnelligkeit und Risikominimierung.",
    "expected_skill": "Sicherheitswarnungen - gut",
    "agent_id": ["442847"]
    },
    {
    "request_id":"K3RQV55",
    "subject": "Effiziente Durchführung von Datenmigrationen",
    "description": "Planen und implementieren Sie Datenmigrationen zur Sicherstellung einer reibungslosen Übertragung von Daten zwischen Systemen. Entwickeln Sie Strategien zur Minimierung von Datenverlusten, Integritätsprüfungen und Optimierung der Migrationsprozesse. Der Fokus liegt auf Datenkonsistenz, Ausfallsicherheit und Effizienz.",
    "expected_skill": "Datenmigration - mittel",
    "agent_id": ["442844"]
    },
    {
    "request_id": "HDBMWS6",
    "subject": "Umfassende Überwachung von Kontobewegungen",
    "description": "Überwachen, analysieren und bewerten Sie Kontobewegungen, um Unregelmäßigkeiten und potenziellen Betrug frühzeitig zu erkennen. Entwickeln Sie proaktive Strategien zur Risikominimierung und zur Verbesserung der Sicherheitsmaßnahmen. Der Fokus liegt auf Betrugsprävention, Anomalieerkennung und Compliance-Einhaltung.",
    "expected_skill": "Kontoüberwachung - gut",
    "agent_id": ["443033"]
    },
    {
    "request_id": "2T45XM2",
    "subject": "Effiziente Optimierung der Systemperformance",
    "description": "Analysieren und verbessern Sie die Leistung von Systemen und Anwendungen zur Steigerung der Effizienz und Stabilität. Entwickeln Sie Strategien zur Identifikation von Engpässen, Ressourcennutzung und Optimierung von Prozessen. Der Fokus liegt auf Performance-Steigerung, Skalierbarkeit und Betriebskontinuität.",
    "expected_skill": "Performanceoptimierung - mittel",
    "agent_id": ["442843"]
    },
    {
    "request_id": "ABXTVDV",
    "subject": "Umfassende Optimierung der Systemperformance",
    "description": "Analysieren und optimieren Sie komplexe Systeme und Anwendungen, um maximale Effizienz, Skalierbarkeit und Stabilität zu gewährleisten. Entwickeln Sie fortgeschrittene Strategien zur Identifikation und Behebung von Performance-Engpässen, zur Ressourcennutzung und zur Verbesserung von Systemreaktionszeiten. Der Fokus liegt auf High-Performance, nachhaltiger Skalierung und Betriebseffizienz.",
    "expected_skill": "Performanceoptimierung - gut",
    "agent_id": ["442848"]
    },
    {
    "request_id": "9CMVK0V",
    "subject": "Einfache Unterstützung bei der Kontoüberwachung",
    "description": "Führen Sie grundlegende Aufgaben der Kontoüberwachung aus, wie das gelegentliche Durchsehen von Transaktionen ohne tiefere Analyse oder Bewertung. Eigenständige Entscheidungsfindung oder fortgeschrittene Betrugserkennung sind nicht erforderlich. Der Fokus liegt auf der rudimentären Sichtprüfung und dem Weiterleiten offensichtlicher Auffälligkeiten an kompetentere Stellen.",
    "expected_skill": "Kontoüberwachung - schlecht",
    "agent_id": ["442849"]
    }



]

# Testet die Routing-Logik mit verschiedenen Testfällen
def test_routing_logic(test_cases):
    """Testet die Routing-Logik durch die Analyse eines Benutzeranfrage-Texts und die Zuordnung zum besten Agenten."""
    # **Schritt 1: Agenten-Skills initialisieren**
    agents_skills_json = Util.get_all_agent_skills(access_token)
    agent_data = json.loads(agents_skills_json)
    
    if not agent_data or "skills" not in agent_data or "agents" not in agent_data or "agent_skills" not in agent_data:
        print("Fehler: Ungültige oder unvollständige Daten von init_agents_skills erhalten.")
        agent_skills = {}
    else:
        agent_skills = {}
        for entry in agent_data["agent_skills"]:
            agent_id = entry["agent_id"]
            skill_name = entry["skill_name"]
            skill_level = entry["skill_level"]
            
            if agent_id not in agent_skills:
                agent_skills[agent_id] = {}

            agent_skills[agent_id][skill_name] = skill_level
    
    # **Schritt 2: Alle verfügbaren Fähigkeiten sammeln**
    skill_list = [entry["skill_name"] for entry in agent_data["agent_skills"]]
    print(f"{skill_list}")

    # Erfolgsstatistik
    total_tests = len(test_cases)
    successful_tests = 0
    correct_agent_selection = 0
    correct_skill_level_selection = 0
    # Gewichtung
    weight_skill_match = 0.7  # 70% Gewichtung für das Vorhandensein der Fähigkeit
    weight_level_match = 0.3  # 30% Gewichtung für das richtige Fähigkeitsniveau
    

    # **Schritt 3: Testfälle durchlaufen**
    for test_case in test_cases:
        request_id = test_case["request_id"]
        
        # **Schritt 4: Anfrage-Details abrufen (Titel & Beschreibung)**
        request_text = Get.get_subject_and_description(request_id, access_token)
        print(request_text)
        subject = request_text.get('subject')
        description = request_text.get('description')
        expected_skill = test_case.get('expected_skill')
        print(expected_skill)
        
        request_text_combined = f"Titel:\n{subject}\nBeschreibung:\n{description}"

        # **Schritt 5: ChatGPT analysiert die benötigte Fähigkeit**
        skill_analysis = chatgpt_skill_analyze_rating("System Prompt", request_text_combined, skill_list, 100)
        
        if isinstance(skill_analysis, str):
            if "Skill:" in skill_analysis and "Rating:" in skill_analysis:
                try:
                    skill_part = skill_analysis.split("Skill:")[1].split("Rating:")[0].strip()
                    rating_part = skill_analysis.split("Rating:")[1].strip()
                    skill_analysis = {"skill": skill_part, "rating": rating_part}
                except IndexError:
                    print(f"❌ Fehler beim Parsen der Antwort: {skill_analysis}")
                    continue
            else:
                try:
                    skill_analysis = json.loads(skill_analysis)
                except json.JSONDecodeError:
                    print(f"❌ JSON-Fehler: Die Antwort von 'chatgpt_skill_analyze_rating' ist kein gültiges JSON: {skill_analysis}")
                    continue
        
        if "skill" not in skill_analysis or "rating" not in skill_analysis:
            print("❌ Fehler: Ungültige Antwort von chatgpt_skill_analyze_rating, fehlende Schlüssel")
            continue

       

        formatted_skill = f"{skill_analysis['skill']} - {skill_analysis['rating']}"
        
        print(f"Analyzed skill :{formatted_skill} ")
        print (f"{agent_skills}")

        
        # **Schritt 6: Besten Agenten für die Fähigkeit finden**
        suitable_agent_id, agent_scores = Util.find_best_agent_for_skill(formatted_skill, agent_skills)
        print(f"suitable_agent_id : {suitable_agent_id}")
        print("Scores für alle Agenten:")
        for agent_id, score in agent_scores.items():
            print(f"Agent {agent_id}: Score {score}")
        if suitable_agent_id is None:
            print("❌ Kein geeigneter Agent gefunden!")
            continue
        
        # **Schritt 7: Überprüfen, ob der gefundene Agent einer der erwarteten ist**
        expected_agent_ids = test_case["agent_id"]
        if suitable_agent_id in expected_agent_ids:
            successful_tests += 1
            correct_agent_selection += 1
        else:
            print(f"❌ Falscher Agent! Erwartet: {expected_agent_ids}, bekommen: {suitable_agent_id}")

        # **Schritt 8: Überprüfung der erwarteten Fähigkeit im richtigen Format**
        print(f"Überprüfung der erwarteten Fähigkeit: {expected_skill}")
        
        # Prüfe, ob der erwartete Skill im richtigen Format vorliegt (z. B. 'Datenbank - schlecht')
        if expected_skill:
            skill, rating = expected_skill.split(' - ')  # Teilt den String bei " - "
            print(f"Skill: {skill}")
            print(f"Rating: {rating}")
            expected_skill = skill
            expected_rating = rating
        else:
            print("Der Wert für expected_skill ist None oder leer!")
        
        # **Schritt 9: Prüfen, ob der Agent die Fähigkeit auf dem richtigen Level hat**
        if expected_skill in agent_skills.get(suitable_agent_id, {}):
           correct_skill_level_selection += weight_skill_match  # 70% vergeben, wenn die Fähigkeit existiert
    
           if agent_skills[suitable_agent_id].get(expected_skill) == expected_rating:
              correct_skill_level_selection += weight_level_match  # 30% vergeben, wenn auch das Level übereinstimmt

           else:
                print(f"❌ Fehler: Agent {suitable_agent_id} hat den Skill '{expected_skill}', aber mit falschem Level '{agent_skills[suitable_agent_id].get(expected_skill)}' statt '{expected_rating}'")
        else:
            print(f"❌ Fehler: Agent {suitable_agent_id} besitzt nicht den erwarteten Skill '{expected_skill}'")

        print(f"✅ Agent {suitable_agent_id} besitzt den erwarteten Skill '{expected_skill}' mit Level '{expected_rating}'.")

    # **Schritt 10: Erfolgsquote berechnen & ausgeben**
    success_rate = (successful_tests / total_tests) * 100 if total_tests > 0 else 0
    agent_selection_rate = (correct_agent_selection / total_tests) * 100 if total_tests > 0 else 0
    skill_level_accuracy = (correct_skill_level_selection / total_tests) * 100 if total_tests > 0 else 0

    print(f"✅ Test abgeschlossen: Erfolgsquote beträgt jetzt {success_rate:.2f}%")
    print(f"🧑‍💻 Erfolgsquote der Agentenauswahl: {agent_selection_rate:.2f}%")
    print(f"🎯 Erfolgsquote der richtigen Skill-Level-Zuordnung: {skill_level_accuracy:.2f}%")

    return success_rate, agent_selection_rate, skill_level_accuracy

if __name__ == "__main__": 
    test_routing_logic(test)
