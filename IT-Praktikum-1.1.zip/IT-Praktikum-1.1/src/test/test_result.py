import os
import pandas as pd
import matplotlib.pyplot as plt
from fpdf import FPDF
from datetime import datetime
from test_routing import test, test_routing_logic

def save_test_results(success_rate, agent_selection_rate, skill_level_accuracy):
    """
    Speichert die Testergebnisse in einer CSV-Datei und visualisiert die Entwicklung über die Zeit.
    """
    # Verzeichnis für die Ergebnisse
    results_dir = r"src\test\results"
    
    # Sicherstellen, dass das Verzeichnis existiert
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)
    
    # Dateiname für die Speicherung der Ergebnisse
    results_file = os.path.join(results_dir, "test_results.csv")
    
    # Überprüfen, ob die Datei existiert, sonst eine neue erstellen
    if not os.path.exists(results_file):
        df = pd.DataFrame(columns=["timestamp", "success_rate", "agent_selection_rate", "skill_level_accuracy"])
        df.to_csv(results_file, index=False)
    
    # Bestehende Ergebnisse laden
    df = pd.read_csv(results_file)
    
    # Neuen Datensatz hinzufügen
    new_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "success_rate": success_rate,
        "agent_selection_rate": agent_selection_rate,
        "skill_level_accuracy": skill_level_accuracy
    }

    if df.empty:
        df = new_data
    else:
        new_data_df = pd.DataFrame([new_data])  # Dictionary in DataFrame umwandeln
        df = pd.concat([df, new_data_df], ignore_index=True)

    df.to_csv(results_file, index=False)
    
    # Visualisierung
    plt.figure(figsize=(10, 5))
    plt.plot(df["timestamp"], df["success_rate"], label="Gesamterfolgsquote", marker='o')
    plt.plot(df["timestamp"], df["agent_selection_rate"], label="Agentenauswahl", marker='s')
    plt.plot(df["timestamp"], df["skill_level_accuracy"], label="Skill-Erkennung", marker='^')
    
    plt.xlabel("Datum & Uhrzeit")
    plt.ylabel("Prozent (%)")
    plt.title("Testentwicklung über die Zeit")
    plt.legend()
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    
    # Speichern des Diagramms
    plot_filename = os.path.join(results_dir, "test_results_plot.png")
    plt.savefig(plot_filename)
    plt.close()
    
    # PDF-Erstellung
    create_pdf_report(df, plot_filename, results_dir)

def create_pdf_report(df, plot_filename, results_dir):
    """
    Erstellt eine professionelle PDF mit den Testergebnissen.
    """
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    
    # Titel
    pdf.set_font("Arial", "B", 16)
    pdf.cell(200, 10, "Testergebnisse - Routing Logik", ln=True, align='C')
    pdf.ln(10)
    
    # Letztes Testergebnis
    last_test = df.iloc[-1]
    pdf.set_font("Arial", "", 12)
    pdf.cell(200, 10, f"Datum: {last_test['timestamp']}", ln=True)
    pdf.cell(200, 10, f"Gesamterfolgsquote: {last_test['success_rate']:.2f}%", ln=True)
    pdf.cell(200, 10, f"Agentenauswahl-Genauigkeit: {last_test['agent_selection_rate']:.2f}%", ln=True)
    pdf.cell(200, 10, f"Skill-Erkennungs-Genauigkeit: {last_test['skill_level_accuracy']:.2f}%", ln=True)
    pdf.ln(10)
    
    # Diagramm einfügen
    pdf.image(plot_filename, x=10, w=180)
    
    # PDF speichern
    pdf.output(os.path.join(results_dir, "test_report.pdf"))

# Beispielaufruf nach einem Test
if __name__ == "__main__":
    success_rate, agent_selection_rate, skill_level_accuracy = test_routing_logic(test)
    save_test_results(success_rate, agent_selection_rate, skill_level_accuracy)
