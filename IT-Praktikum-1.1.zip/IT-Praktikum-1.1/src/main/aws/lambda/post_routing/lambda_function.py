import os
import time
import json
import requests
# import tiktoken
import concurrent.futures
from openai import OpenAI
# API Version
import aipe_config

# Local version for testing
# from . import aipe_config
# from dotenv import load_dotenv
# load_dotenv()

# Base URL for AIPE requests
BASE_URL = aipe_config.BASE_URL

class Get: 
    """
    Class containing functions to get and request info from the API of the AI Process Engine from Serviceware.\n
    Functions:
    - 'get_access_token': This function retrieves an access token which is is required for further communication with the API.
    - 'get_subject_and_description': Fetches both the subject and description of an object.
    - 'get_all_skill_names': Retrieves a list of unique skill names from the API.
    - `get_all_agent_ids`: Retrieves all agent IDs from the API.
    - 'search_objects': Searches objects in AIPE.
    - 'get_object_id': Extracts the ID of an object from the JSON response.
    - 'get_display_name_from_json': Extracts the display name of an object from the JSON response.
    - 'get_display_name': Fetches the display name  of an object.
    - 'get_all_agent_ids': Retrieves all agent IDs from the API.
    - 'fetch_skills': Retrieves the skills of a specific agent.
    - `get_agent_skills`: Returns all existing skills of an agent, formatted as "skillname - skilllevel".
    - 'get_current_linked_agent': Retrieves the currently linked agent for a given data object, based on its ID.
    - 'get_object_type': Fetches the type of object.
    - 'extract_link_definitions_by_types': Extracts link definitions based on object types.
    - 'get_all_link_definitions': Retrieves all link definitions from the API.
    """
    # Funktion: Access Token holen
    
    def get_access_token() -> str | None:
        """
        This function sends a POST request for authentication and retrieves an access token.\n
        The token is required for further communication with the API.

        :return: The authentication token as a string or None in case of errors.
        """
        # Request the access token from the credentials
        token_url = os.getenv("TOKEN_URL")
        grant_type = os.getenv("GRANT_TYPE")
        client_id = os.getenv("CLIENT_ID")
        client_secret = os.getenv("CLIENT_SECRET")

        if not token_url or not client_id or not client_secret:
            raise ValueError("Missing authentification parameter")
        
        # Header for the authentication request specifying the content type for the token request
        header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        # Send the POST request to the token endpoint
        response = requests.post(token_url, headers=header, data={
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": grant_type
        })
        # Check if the request was successful (Status code 200)
        if response.status_code == 200:
            # Extract the access token from the response
            token_data = response.json()
            access_token = token_data.get('access_token')
            return access_token
        else:
            # If there are errors in the request, output status code and error message
            print(f"Error at Token request. Status code: {response.status_code}, Answer: {response.text}")
            return None

    def get_subject_and_description(data_object_id: str | int, access_token: str) -> dict[str, str] | None:
        """
        Retrieves the subject (display name) and description of an object.

        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: Authentication token.

        :return: A dictionary with 'subject' and 'description', or None in case of an error.
        """
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "propertyPaths": ["description", "system.display-name"]
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                data = response.json()
                # Extraction of data
                subject = data.get("values", {}).get("system.display-name", "Subject not available")
                description = data.get("values", {}).get("description", "Description not available")
                return {
                    "subject": subject,
                    "description": description
                }
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")
        return None

    def get_all_skill_names(access_token: str) -> list:
        """
        Retrieves all unique skill names from the API.

        :param access_token: Authentication token.

        :return: List of unique skill names.
        """
        try:
            # Retrieve all skills
            skill_list = Get.search_objects(type_name=aipe_config.SKILLS, access_token=access_token, max_pages=10, filter=None)
            if not skill_list:
                print("No skills found.")
                return []
            skillname_set = set()
            for skill in skill_list:
                id = Get.get_object_id(skill)
                if not id:
                    continue # Skip objects without a valid ID
                name = Get.get_display_name_from_json(skill)
                if name:
                    skillname = name.split(" - ")[0] # Only the skill name, without level
                    skillname_set.add(skillname) # Avoid duplicates
            unique_skills = list(skillname_set)
            print(f"{len(unique_skills)} unique skills found.")
            return unique_skills
        except Exception as e:
            print(f"Error during request: {e}")
            return []

    def get_all_agent_ids(access_token: str) -> list:
        """
        Retrieves all agent IDs from the API.

        :param access_token: Authentication token.

        :return: List of agent IDs.
        """
        print("Start get_all_agent_ids")
        try:
            # Retrieve all agents
            agents_list = Get.search_objects(type_name=aipe_config.USER, access_token=access_token, filter=None)
            if not agents_list:
                print("No requests found.")
                return []
            id_list = []
            for agent in agents_list:
                agent_id = Get.get_object_id(agent)
                if not agent_id:
                    continue  # Skip objects without a valid ID
                else:
                    id_list.append(agent_id)
            print(f"{len(id_list)} agent IDs found.")
            print(f"End get_all_agent_ids")
            return id_list
        except Exception as e:
            print(f"Error during request: {e}")
            return []

    def search_objects(type_name: str, access_token: str, max_pages=10, size=25, sort_attribute="system.id", sort_direction="asc", filter=None) -> list:
        """
        This method searches for objects of a specific type using a GET request.
        
        :param type_name: The name of the object type (e.g., "request").
        :param access_token: The authentication token.
        :param page: The page to retrieve (default: 0).
        :param size: The number of objects per page (default: 25).
        :param sort_attribute: The attribute by which sorting should be done (default: "system.id").
        :param sort_direction: The sorting direction (default: "asc").
        :param filter: Optional filter to further narrow down the objects.

        :return: A list of found objects or None in case of an error.
        """
        # API endpoint URL
        endpoint_url = f"{BASE_URL}/api/v1/objects"
        # Headers for the request with authentication
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json"
        }
        result = []
        print(f"Searching for objects of type '{type_name}' on the first {max_pages} pages.")
        for page in range(max_pages + 1): # run through all pages
            # Parameters for the GET request
            params = {
                "typeName": type_name,
                "page": page,                       # result page
                "size": size,                       # number of results per page
                "sortAttribute": sort_attribute,    # Sorting by attribute
                "sortDirection": sort_direction     # Direction of sorting
            }
            # Optional filter, if specified
            if filter:
                params["filter"] = filter
            try:
                # Send the GET request
                response = requests.get(endpoint_url, headers=headers, params=params)
                # Check the response status code
                if response.status_code == 200:
                    # Extract objects from the response
                    data = response.json()
                    objects = data.get("objects", [])
                    result.extend(objects)
                    print(f"Successfully retrieved {len(objects)} objects of type '{type_name}'")
                elif response.status_code == 400:
                    print(f"Error: Invalid request. Please check the parameters, Answer: {response.text}")
                elif response.status_code == 404:
                    print(f"Error: No object of type '{type_name}' found.")
                else:
                    print(f"Error: Status code {response.status_code}, Answer: {response.text}")
            except requests.exceptions.RequestException as e:
                print(f"Error during request: {e}")
                return None
        return result

    def get_object_id(obj: dict) -> str | None:
        """
        Extracts the ID of an object from the JSON response.

        :param obj: JSON object.

        :return: Object ID or None if no ID is found.
        """
        try:
            # Attempt to extract the ID from various possible fields
            obj_id = obj.get("system", {}).get("id") # Originally expected field
            if not obj_id:
                obj_id = obj.get("dataObjectId") # Alternative field for the ID
            if obj_id:
                return obj_id
            else:
                print(f"Warning: ID was not found. Full object: {json.dumps(obj, indent=2)}")
                return None
        except Exception as e:
            print(f"Erorr while getting object with ID: {e}. Full object: {json.dumps(obj, indent=2)}")
            return None
  
    def get_display_name_from_json(obj: dict) -> str | None:
        """
        Extracts the display name of an object from the JSON response.

        :param obj: JSON object.

        :return: Display name or None if no ID is found.
        """
        try:
            # Attempt to extract the display name from various possible fields
            display_name = obj.get("system", {}).get("display-name") # Originally expected field
            if display_name:
                return display_name
            else:
                print(f"Warning: Display name was not found. Full object: {json.dumps(obj, indent=2)}")
                return None
        except Exception as e:
            print(f"Erorr while getting object with display name: {e}. Full object: {json.dumps(obj, indent=2)}")
            return None

    def get_display_name(data_object_id: str | int, access_token: str) -> str:
        """
        Retrieves the subject (display name) of an object.

        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: Authentication token.

        :return: Display name or None in case of an error.
        """
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "propertyPaths": [ "system.display-name"]
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                data = response.json()
                # Extraction of data
                displayname = data.get("values", {}).get("system.display-name", "Display name not available")
                return displayname
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")
        return None

    def fetch_skills(agent_id: str | int, access_token: str) -> list:
        """
        Retrieves the skills of a specific agent.

        :param agent_id: The ID of the agent whose skills should be fetched.
        :param access_token: Authentication token.

        :return: A list of the agent's skills in the format:
             [{"agent_id": <agent_id>, "skill_name": <skill_name>, "skill_level": <skill_level>}, ...]
        """
        skills = Get.get_agent_skills(agent_id, access_token)
        agent_skill_data = []
        # Convert each skill entry into a dictionary
        for skill_entry in skills:
            skill_parts = skill_entry.split(" - ")
            skill_name = skill_parts[0]
            skill_level = skill_parts[1] if len(skill_parts) > 1 else "" # If there is no level, leave blank
            agent_skill_data.append({
                "agent_id": agent_id,
                "skill_name": skill_name,
                "skill_level": skill_level
            })
        print(f"Agent {agent_id}: {len(agent_skill_data)} skills retrieved") # Output of the number of retrieved skills
        return agent_skill_data

    def get_agent_skills(data_object_id: str | int, access_token: str) -> list:
        """
        This function retrieves all existing skills for the specified agent in the format "SkillName - SkillLevel".

        :param data_object_id: The ID of the agent.
        :param access_token: Authentication token.

        :return: A list of skill names in the format "SkillName - SkillLevel".
        """
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "linkDefinitionName": aipe_config.USER_HAS_SKILLS,
            "relationName": aipe_config.USER_HAS_SKILLS_RELATION_NAME_OTHER,
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                links_data = response.json()
                skill_objects = links_data.get('objects', [])
                skillname_list = []
                for skill in skill_objects:
                    id = Get.get_object_id(skill)
                    if not id:
                        continue # Skip objects without a valid ID
                    name = Get.get_display_name(id, access_token)
                    if name:
                        skillname_list.append(name)
                print(f"{len(skillname_list)} skills found for the agent.")
                return skillname_list
            elif response.status_code == 404:
                print("Error: Definition, object or link does not exist.")
                return []
            elif response.status_code == 400:
                print("Error: Invalid request.")
                return []
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return []
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")
            return []

    def get_current_linked_agent(data_object_id: str | int, access_token: str) -> str | None:
        """
        Retrieves the currently linked agent for a given data object.

        :param data_object_id: The ID of the data object for which the linked agent should be retrieved.
        :param access_token: Authentication token.

        :return: The ID of the linked agent if found, otherwise None.
        """
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "linkDefinitionName": aipe_config.ROUTING,
            "relationName": aipe_config.ROUTING_RELATION_NAME,
        }
        try:
            # Send a GET request to the API
            response = requests.get(endpoint_url, headers=headers, params=params)
            # Check if the request was successful
            if response.status_code == 200:
                links_data = response.json()
                linked_objects = links_data.get('objects', [])  
                # Check if there are linked objects
                if linked_objects:
                    linked_agent_id = linked_objects[0].get('system', {}).get('id')
                    print(f"Found agent: {linked_agent_id}")
                    return linked_agent_id
                else:
                    print("No links found.")
                    return None
            # Handle specific status codes
            elif response.status_code == 404:
                print("Erorr: Object or link does not exist.")
                return None
            elif response.status_code == 400:
                print("Erorr: Invalid request.")
                return None
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")
            return None

    def get_object_type(data_object_id: str | int, access_token: str) -> str | None:
        """
        Retrieves the type of object.
        
        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: Authentication token.

        :return: The object type as a string, or None in case of an error.
        """
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "propertyPaths": ["system.type-name"]
        }
        try:
            # HTTP GET request
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                # Extract JSON data
                data = response.json()
                # Try to extract the type from the values
                type_name = data.get("values", {}).get("system.type-name", None)
                if type_name:
                    return type_name
                else:
                    print("The object type could not be found.")
                    return None
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")
            return None

    def extract_link_definitions_by_types(object_types: dict, access_token: str) -> dict | None:
        """
        Extracts a specific link definition based on the given object types.
        
        :param object_types: A dictionary with 'word1' and 'word2' as object type definitions.
        :param access_token: Authentication token.

        :return: A dictionary with 'linkDefinitionName' and 'relationName', or None if no matching definition is found.
        """
        # Retrieve all link definitions using the get_all_link_definitions method
        link_definitions = Get.get_all_link_definitions(access_token)
        if not link_definitions:
            print("Error while retrieving the link definitions.")
            return None
        left_object_type = object_types.get("word1")
        right_object_type = object_types.get("word2")
        print(f"Type of the left object: {left_object_type}")
        print(f"Type of the right object: {right_object_type}")
        # Variable for counting matching definitions
        matched_definitions = []
        # Search through link definitions for a matching definition
        for definition in link_definitions:
            left_to_right = definition.get("leftToRight", {})
            right_to_left = definition.get("rightToLeft", {})
            left_source = left_to_right.get("source", {})
            right_source = right_to_left.get("source", {})
            if (left_source.get("definitionName") == left_object_type and right_source.get("definitionName") == right_object_type):
                matched_definitions.append({
                    "linkDefinitionName": definition.get("name"),
                    "relationName": left_to_right.get("relationName"),
                })
            if (left_source.get("definitionName") == right_object_type and right_source.get("definitionName") == left_object_type):
                matched_definitions.append({
                    "linkDefinitionName": definition.get("name"),
                    "relationName": right_to_left.get("relationName"), # inverse case, for right to left, e.g. the case when removing skills to user links
                })
        print(f"Matching definitions: {matched_definitions}")
        # Output how many matching definitions were found
        print(f"Number of matching definitions for {left_object_type} and {right_object_type}: {len(matched_definitions)}")
        if matched_definitions:
            return matched_definitions[0] # Return the first matching definition
        else:
            print("No matching route definitions found.")
            return None

    def get_all_link_definitions(access_token: str) -> list | None:
        """
        Retrieves all link definitions from the API.

        :param access_token: Authentication token.

        :return: A list of all link definitions or None in case of an error.
        """
        # Endpoint URL for retrieving all link definitions
        endpoint_url = f"{BASE_URL}/api/v1/link-definitions"
        # Headers for the GET request with authentication
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        try:
            # Send the GET request
            response = requests.get(endpoint_url, headers=headers)
            # Check the response status code
            if response.status_code == 200:
                # Extract JSON data
                data = response.json()
                link_definitions = data.get("linkDefinitions", [])
                print(f"Successfully retrieved {len(link_definitions)} link definitions.")
                return link_definitions
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")
            return None

class Update: 
    """
    Class containing functions updating relations and properties of objects in the AI Process Engine from Serviceware.\n
    Functions:
    - 'remove_link': Removes an existing link between two objects.
    - 'update_link_with_dynamic_relation': Creates a link between two objects using a provided link definition.
    - `update_link`: Updates the connection between two objects, dynamically identifying the correct link definition.
    """
    def remove_link(data_object_id: str | int, linked_object_id: str | int, access_token: str) -> None:
        """
        Removes a link from an object.

        :param data_object_id: The ID of the main object from which the link should be removed.
        :param linked_object_id: The ID of the object that should no longer be linked.
        :param access_token: Authentication token.
        """
        # Retrieve object types
        object_type_1 = Get.get_object_type(data_object_id, access_token)
        object_type_2 = Get.get_object_type(linked_object_id, access_token)
        if not object_type_1 or not object_type_2:
            print("Error: Object type could not be retrieved.")
            return None
        # Extract link definitions based on the types
        link_definition = Get.extract_link_definitions_by_types({"word1": object_type_1, "word2": object_type_2}, access_token)
        if not link_definition:
            print("No matching link definition found.")
            return None
        # URL and headers for the request
        url = f"{BASE_URL}/api/v1/objects/{data_object_id}"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        # Create payload
        payload = {
            "links": [
                {
                    "linkDefinitionName": link_definition["linkDefinitionName"],
                    "relationName": link_definition["relationName"],
                    "remove": [linked_object_id],
                }
            ]
        }
        try:
            # Send PATCH request
            response = requests.patch(url, json=payload, headers=headers)
            # Handle response status codes
            if response.status_code == 200:
                print("Link successfully removed.")
                return response # No further output necessary
            elif response.status_code == 400:
                print("Incorrect request:", response.json())
            elif response.status_code == 404:
                print("Object not found.")
            elif response.status_code == 409:
                print("Conflict while removing link:", response.json())
            else:
                print(f"Unexpected error: {response.status_code}, {response.text}")
            return response
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e} (Probably there was no link between the objects.)")
            return None

    def update_link_with_dynamic_relation(left_id: str | int, right_id: str | int, link_definition: dict, access_token: str) -> None:
        """
        This function links a request with an agent based on a single link definition.
        
        :param left_id: The ID of the request to be linked.
        :param right_id: The ID of the agent to be linked with the request.
        :param link_definition: A dictionary in the format:
        {'linkDefinitionName': 'name1', 'relationName': 'relation1'}.
        :param access_token: Authentication token.
        """
        # Check if link_definition is a dictionary
        if not isinstance(link_definition, dict):
            raise ValueError("The parameter link_definition must be a dictionary.")
        # Ensure that the required keys are present
        link_definition_name = link_definition.get('linkDefinitionName')
        relation_name = link_definition.get('relationName')
        if not link_definition_name or not relation_name:
            raise ValueError("The link definition must contain 'linkDefinitionName' and 'relationName'.")
        # API endpoint for updating the link
        endpoint_url = f"{BASE_URL}/api/v1/external/objects/{left_id}"
        # Request headers
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        # Data payload for the request (no "remove" anymore)
        data = {
            "links": [
                {
                    "linkDefinitionName": link_definition_name, # The specified link definition name
                    "relationName": relation_name,              # The specified relation
                    "add": [right_id]                           # Add the agent's ID
                    # No "remove" anymore, as links are not being removed
                }
            ]
        }
        try:
            # Send the PATCH request
            response = requests.patch(endpoint_url, headers=headers, json=data)
            # Evaluate the status codes
            if response.status_code == 200:
                print(f"Link {link_definition_name} successfully updated with {relation_name}.")
            elif response.status_code == 400:
                print("Error: Invalid object attributes.")
            elif response.status_code == 404:
                print("Error: Object not found.")
            elif response.status_code == 409:
                print("Error: A link could not be added.")
            else:
                print(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"Error during request: {e}")

    def update_link(main_object_id: str | int, linked_object_id: str | int, access_token: str) -> None:
        """
        Updates the connection between two objects and checks both directions for the link definition.

        :param main_object_id: ID of the main object.
        :param linked_object_id: ID of the linked object.
        :param access_token: Authentication token.
        """
        # Retrieve object types
        main_object_type = Get.get_object_type(main_object_id, access_token)
        linked_object_type = Get.get_object_type(linked_object_id, access_token)
        if not main_object_type or not linked_object_type:
            print("Error: The object type can not be retrieved.")
            return None
        # Try to find the link definition in the original order
        link_definition = Get.extract_link_definitions_by_types({"word1": main_object_type, "word2": linked_object_type}, access_token)
        # If no definition is found, try in the reversed order
        reversed = False
        if not link_definition:
            link_definition = Get.extract_link_definitions_by_types({"word1": linked_object_type, "word2": main_object_type}, access_token)
            reversed = True  # Mark that the order was reversed
        if not link_definition:
            print(f"No matching link definition found for {main_object_type} and {linked_object_type}.")
            return
        # Prepare parameters for updating the connection
        link_definitions = {
            "linkDefinitionName": link_definition["linkDefinitionName"],
            "relationName": link_definition["relationName"]
        }
        # Consider the reversed order if necessary
        from_object_id = linked_object_id if reversed else main_object_id
        to_object_id = main_object_id if reversed else linked_object_id
        # Create or update the connection
        try:
            Update.update_link_with_dynamic_relation(from_object_id, to_object_id, link_definitions, access_token)
            print(f"Link successfully updated between '{from_object_id}' and '{to_object_id}'.")
        except Exception as e:
            print(f"Error during updating the link: {e}")

class Util:
    """
    Class containing utility functions for string, object and relation formatting and matching algorithms.\n
    Functions:
    - 'get_all_agent_skills': Retrieves all available skills, agents, and their assigned skills in a structured JSON format.
    - 'find_best_agent_for_skill': Identifies the best agent based on required skills and assigns a matching score.
    """
    # Gets all Skill, Agent and relations between those two objects and formats them
    def get_all_agent_skills(access_token: str) -> str | dict[str, str]:
        """
        This function collects all available skills, agents, and the respective skills of agents and returns them as a JSON object.
        The data is processed in parallel for efficiency.
        
        :param access_token: Authentication token.
        
        :return: A JSON object containing all skills, agents, and agent skills.
        """
        try:
            # Step 1: Fetch all skills
            print("Retrieve all skill names...")
            all_skills = Get.get_all_skill_names(access_token)
            # Step 2: Fetch agent IDs
            print("Retrieve all agent IDs...")
            all_agents = Get.get_all_agent_ids(access_token)
            # Initialize list for agent skills
            agent_skills = []
            # Fetch skills for all agents in parallel using ThreadPoolExecutor
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                results = executor.map(lambda agent_id: Get.fetch_skills(agent_id, access_token),all_agents)
            # Collect all results in a list
            for result in results:
                agent_skills.extend(result)
            # Create final result as JSON
            result = {
                "skills": all_skills,
                "agents": all_agents,
                "agent_skills": agent_skills
            }
            json_result = json.dumps(result, indent=4, ensure_ascii=False) # Format the result as JSON
            return json_result
        except Exception as e:
            print(f"Error during initialization: {e}")
            return {"error": str(e)}

    # Matching algorithm
    def find_best_agent_for_skill(required_skills: str, agent_skills: dict) -> tuple[str, dict[str, str]]:
        """
        Finds the best agent based on the required skills and outputs the scores of all agents.

        :param required_skills: Required skills in the format "Skill - Level" (e.g., Network Basics - good).
        :param agent_skills: Available agent skills with levels.

        :return: Tuple with (ID of the best agent, scores of all agents as a dict).
        """
        best_agent = None
        best_match_score = -1
        agent_scores = {}  # Store scores for all agents
        # Define skill levels as a mapping for comparison
        skill_levels = {
            "schlecht": 1,
            "mittel": 2,
            "gut": 3
        }
        # Iterate over all agents and their skills
        for agent_id, skills in agent_skills.items():
            match_score = 0 # Points for exact or close matches
            partial_match_score = 0 # Points for partial matches
            # Check the required skills
            if " - " in required_skills: # Check the format
                skill_name, required_level = required_skills.split(" - ")
                agent_level = skills.get(skill_name) # Get the level of the agent
                if agent_level:
                    required_level = required_level.strip()
                    agent_level = agent_level.strip()
                    # Calculate the difference between required level and agent's current level
                    level_difference = abs(skill_levels[required_level] - skill_levels[agent_level])
                    if level_difference == 0:
                        match_score += 2 # Same level -> +2 points
                    elif level_difference == 1:
                        match_score += 1 # Difference of 1 level -> +1 point
                    elif level_difference == 2:
                        match_score += 0.5 # Difference of 2 levels -> +0.5 points
                    else:
                        partial_match_score += 0 # Difference bigger than 2 levels -> 0 points
                else:
                    partial_match_score += 0 # Skill missing -> 0 points
            else:
                print(f"Invalid format for skill rating: {required_skills}")
            # Calculate total score
            total_score = match_score + partial_match_score
            agent_scores[agent_id] = total_score # Save score for agent
            # Update the best agent if the score is higher
            if total_score > best_match_score:
                best_agent = agent_id
                best_match_score = total_score
        # Return the best agent and scores of all agents
        return best_agent, agent_scores


class ChatGPT:
    """
    Class containing functions to cover functionality to send requests to ChatGPT.\n
    Functions:
    - 'chatgpt_query': Queries the OpenAI ChatGPT API with a custom user prompt.
    - 'token_estimator': Estimates for a given text an equivalent amount of tokens.
    """
    # Default cases for a system prompt and a skill list
    SYSTEM_PROMPT = "You are a helpful assistant that categorizes requests into skills and provides a skill rating as 'gut', 'mittel', or 'schlecht'."
    SKILLS = [
        "Troubleshooting & Fehlerdiagnose",
        "Datenbankkenntnisse",
        "IT-Sicherheitswissen & Password Management",
        "Netzwerkgrundlagen",
        "API-Integration",
        "Cybersecurity",
        "UX-Kompetenz"
    ]

    def chatgpt_query(prompt = "What is the number of the universe? Answer only with the joking answer.",
                  system_prompt = "You are a helpful assistant that provides concise answers.",
                  tokens = 50, temperature = 0.5, model = "gpt-3.5-turbo") -> str:
        """
        Queries the OpenAI ChatGPT API with a custom user prompt and system behavior prompt, allowing adjustments to the model, token limit, and temperature.

        :param prompt: The main user query that defines the request for ChatGPT.
        :param system_prompt: A prompt to define the assistant's behavior.
        :param tokens: The maximum number of tokens for the response. Determines the response length.
        :param temperature: A value between 0 and 1 that controls the randomness of the response.
                            - Lower values result in more deterministic responses.
                            - Higher values produce more creative and varied outputs.
        :param model: The name of the OpenAI model to be used. Defaults to "gpt-3.5-turbo".

        :return: The response from ChatGPT as a clean string.
        """
        # Retrieve OpenAI API key
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key is missing. Ensure it is set in the environment variables.")
        # Initialize the OpenAI client with the API key
        client = OpenAI(api_key=api_key)
        # Send request to the ChatGPT API
        try:
            print(f"Using this OpenAI Model: {model}") # Debug
            print(f"ChatGPT temperature: {temperature}") # Debug
            print("Not printing the ChatGPT prompt since it is too long") # Debug
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=tokens,
                temperature=temperature
            )
            # Extract and return the response content
            result = response.choices[0].message.content.strip()
            print(f"ChatGPT Response:\n{result}") # Debug
            print(f"This was the maximum allowed amount of tokens: {tokens}") # Debug
            # print(f"This is how many tokens estimatedly were used: {token_estimator(result)}") # Debug
            return result
        except Exception as e:
            raise Exception(f"Error communicating with the OpenAI API: {e}")

    # def token_estimator(text: str, model="gpt-3.5-turbo") -> int:
    #     """
    #     Estimates for a given text an equivalent amount of tokens.

    #     :param text: The text whose amount of tokens is to be estimated.
    #     :param model: The model that is used (Default is "gpt-3.5-turbo").

    #     :return: Estimated amount of tokens.
    #     """
    #     print("Start token_estimator")
    #     encoding = tiktoken.encoding_for_model(model)
    #     tokens = encoding.encode(text)
    #     print(f"End token_estimator")
    #     return len(tokens)

def lambda_handler(event, context):
    """Main lambda processing function."""
    try:
        time1 = time.time()
        # Step 1: Retrieve request ID from body
        body = json.loads(event.get("body", "{}"))
        request_id = body.get("id")
        time2 = time.time()
        print(f"ID {request_id} retrieved in {time2 - time1:.2f}s")

        # Step 2: Retrieve Access Token
        access_token = Get.get_access_token()
        if not access_token:
            access_token = Get.get_access_token()
            if not access_token:
                return {
                    'statusCode': 401,
                    'body': json.dumps("Access Token could not be retrieved.")
                    }
        time3 = time.time()
        print(f"Access Token retrieved in {time3 - time2:.2f}s")
        print(f"Total process time right now {time3 - time1:.2f}s")
        
        # Step 3: Carry out skill analysis
        request_text = Get.get_subject_and_description(request_id, access_token)
        request = f"Titel:\n{request_text.get('subject')}\nBeschreibung:\n{request_text.get('description')}"
        time4 = time.time()
        print(f"Subject and description retrieved in {time4 - time3:.2f}s")
        print(f"Total process time right now {time4 - time1:.2f}s")

        # For testing purposes enter here custom request:
        # request = "Titel:\nDatenbank-Optimierung für bessere Leistung\nBeschreibung:\nIch brauche einen Experten, der schon lange Erfahrung mit Datenbank hat. Ich will, dass Berichte schneller laden, um meine Arbeit ohne Verzögerung durchführen zu können. Das ist echt wichtig!"

        print(f"Request:\n{request}")

        skill_list = Get.get_all_skill_names(access_token)
        time5 = time.time()
        print(f"Skill names retrieved in {time5 - time4:.2f}s")
        print(f"Total process time right now {time5 - time1:.2f}s")
        
        prompt = ("Du hast die Aufgabe, einen erforderlichen 'Skill' und das dazugehörige 'Rating'"
                  "für eine gegebene von einem Nutzer gegebene 'Request' zu bestimmen.\n"
                  "Du kannst das Rating aus folgenden Optionen wählen: 'gut', 'mittel' oder 'schlecht'.\n\n"
                  "Du kannst aus folgenden Skills wählen:\n{skills}\n\n"
                  "Request Text:\n'{request}'\n\n"
                  "Gebe nun nur den benötigten Skill, sowie Rating in folgender Form an, um die Request zu bearbeiten:\n"
                  "Skillname - Rating\n"
                  "Also kann z.B. deine Antwort so aussehen:\nBenutzerfreundlichkeit - mittel\n\n"
                  "Falls die Anfrage in keinem Zusammenhang mit den aufgelisteten Fähigkeiten steht, antworte mit vollständig leerem Text. "
                  "Du sollst also in dem Fall gar nichts antworten!"
                  ).format(skills = ', '.join(skill_list), request=request)
        skill_analysis = ChatGPT.chatgpt_query(prompt=prompt, system_prompt=ChatGPT.SYSTEM_PROMPT, tokens=50, temperature=0.4, model='gpt-3.5-turbo')
        print(f"Skill analysis: {skill_analysis}")
        time6 = time.time()
        print(f"Analysed the skill with ChatGPT in {time6 - time5:.2f}s")
        print(f"Total process time right now {time6 - time1:.2f}s")

        # Step 4: Get all agent skills
        agents_skills = Util.get_all_agent_skills(access_token)
        agents_skills_json = json.loads(agents_skills)
        if not agents_skills_json or "skills" not in agents_skills_json or "agents" not in agents_skills_json or "agent_skills" not in agents_skills_json:
            print("Error: Received invalid or incomplete data from get_all_agent_skills.")
        time7 = time.time()
        print(f"All agent skills retrieved in {time7 - time6:.2f} seconds.")
        print(f"Total process time right now {time7 - time1:.2f}s")

        agent_skills = {}
        # Debug: Check if the agent skills got saved correctly
        # print(f"Agents Skills: {agents_skills}")
        for entry in agents_skills_json["agent_skills"]:
            agent_id = entry["agent_id"]
            skill_name = entry["skill_name"]
            skill_level = entry["skill_level"]
            if agent_id not in agent_skills:
                agent_skills[agent_id] = {}
            agent_skills[agent_id][skill_name] = skill_level
        # Find the matching agent for the skill
        suitable_agent_id, agent_scores = Util.find_best_agent_for_skill(skill_analysis, agent_skills)
        print("Scores for all agents:")
        for agent_id, score in agent_scores.items():
            print(f"Agent {agent_id}: Score {score}")
        # For testing purposes enter here a custom agent id
        # suitable_agent_id = 442843
        print(f"Suitable Agent ID: {suitable_agent_id}")
        time8 = time.time()
        print(f"Best agent found in {time8 - time7:.2f}s")
        print(f"Total process time right now {time8 - time1:.2f}s")

        # Step 5: Check the currently linked agent
        current_linked_agent_id = Get.get_current_linked_agent(request_id, access_token)
        print(f"Currently linked agent: {current_linked_agent_id}")
        time9 = time.time()
        print(f"Current linked agent retrieved in {time9 - time8:.2f}s")
        print(f"Total process time right now {time9 - time1:.2f}s")

        # Step 5.2: Checking the link
        if current_linked_agent_id == suitable_agent_id:
            print("The correct agent is already linked to this request. No changes needed.")
            return {
                'statusCode': 200,
                'body': json.dumps(f"Request {request_id} is already linked with agent {suitable_agent_id}. No changes have been made.")
                }
        else:
            # If the wrong agent is linked, remove and update
            if current_linked_agent_id:
                Update.remove_link(request_id, current_linked_agent_id, access_token)
                print(f"Wrong agent {current_linked_agent_id} removed.")
        time10 = time.time()
        print(f"Link removed in {time10 - time9:.2f}s")
        print(f"Total process time right now {time10 - time1:.2f}s")

        # Step 6: Link the request with the agent
        Update.update_link(request_id, suitable_agent_id, access_token)
        print(f"Request {request_id} was linked with agent {suitable_agent_id}.")
        time11 = time.time()
        print(f"Request linked in {time11 - time10:.2f}s")
        print(f"Total time: {time11 - time1:.2f}s")
        return {
            'statusCode': 200,
            'body': json.dumps(f"Request {request_id} was linked with agent {suitable_agent_id}.")
            }
    except Exception as e:
        print(f"Error in the lambda handler: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"An error has occured: {str(e)}")
        }
