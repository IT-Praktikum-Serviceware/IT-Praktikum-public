import os
import logging
import tiktoken
from openai import OpenAI
from dotenv import load_dotenv

log_dir = "src/main/logs"
os.makedirs(log_dir, exist_ok=True)

# logging main basic config
logging.basicConfig(
    filename=f"{log_dir}/chatgpt_query.log", # path to log file
    level=logging.DEBUG, # Minimum log level
    format="%(asctime)s - %(levelname)s - %(message)s", # log formatting
    encoding="utf-8",
    force = True
)

# Check if there is already an existing StreamHandler
logger = logging.getLogger()
# if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG) # Minimum log level

# Filter for external logs
class NoExternalLogsFilter(logging.Filter):
    def filter(self, record):
        return "." not in record.name # Only use own logs

console_handler.addFilter(NoExternalLogsFilter())
console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
console_handler.setFormatter(console_formatter)

# Add to root logger
logger.addHandler(console_handler)

# Using model 3.5 as default, https://platform.openai.com/docs/models

def chatgpt_query(prompt = "What is the number of the universe? Answer only with the joking answer.",
                  system_prompt = "You are a helpful assistant that provides concise answers.",
                  tokens = 50, temperature = 0.5, model = "gpt-3.5-turbo") -> str:
    """
    Queries the OpenAI ChatGPT API with a custom user prompt and system behavior prompt, allowing adjustments to the model, token limit, and temperature.

    :param prompt: The main user query that defines the request for ChatGPT.
    :param system_prompt: A prompt to define the assistant's behavior.
    :param tokens: The maximum number of tokens for the response. Determines the response length.
    :param temperature: A value between 0 and 1 that controls the randomness of the response.
                        - Lower values result in more deterministic responses.
                        - Higher values produce more creative and varied outputs.
    :param model: The name of the OpenAI model to be used. Defaults to "gpt-3.5-turbo".

    :return: The response from ChatGPT as a clean string.
    """
    logging.info("Start chatgpt_query")
    # Load environment variables from .env file
    load_dotenv()
    # Retrieve OpenAI API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OpenAI API key is missing. Ensure it is set in the environment variables.")
    # Initialize the OpenAI client with the API key
    client = OpenAI(api_key=api_key)
    # Send request to the ChatGPT API
    try:
        logging.info(f"Using this OpenAI Model: {model}") # Debug
        logging.info(f"ChatGPT temperature: {temperature}") # Debug
        logging.debug(f"ChatGPT Prompt:\n{prompt}") # Debug
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            max_tokens=tokens,
            temperature=temperature
        )
        # Extract and return the response content
        result = response.choices[0].message.content.strip()
        logging.debug(f"ChatGPT Response:\n{result}") # Debug
        logging.info(f"This was the maximum allowed amount of tokens: {tokens}") # Debug
        logging.info(f"This is how many tokens estimatedly were used: {token_estimator(result)}") # Debug
        logging.info("End chatgpt_query")
        return result
    except Exception as e:
        raise Exception(f"Error communicating with the OpenAI API: {e}")

def token_estimator(text: str, model="gpt-3.5-turbo") -> int:
    """
    Estimates for a given text an equivalent amount of tokens.

    :param text: The text whose amount of tokens is to be estimated.
    :param model: The model that is used (Default is "gpt-3.5-turbo").

    :return: Estimated amount of tokens.
    """
    logging.debug("Start token_estimator")
    encoding = tiktoken.encoding_for_model(model)
    tokens = encoding.encode(text)
    logging.debug(f"End token_estimator")
    return len(tokens)

def call_until_skill_match(function, skill_list, request, system_prompt="You are a helpful assistant.", temperature=0.7, max_retries=10, tokens=50):
    """
    Repeatedly calls the given function until a valid skill has been picked from the `skill_list`.

    :param function: The function, that shall be called (e.g. `chatgpt_skill_analyze` or `chatgpt_multi_skill_analyze`).
    :param skill_list: List of skills that are being searched for.
    :param request: The text of the request.
    :param system_prompt: The system prompt that defines the context.
    :param temperature: Temperature setting for the API (between 0 and 1, default is 0.7).
    :param max_retries: Maximum amount of retries until an error is raised (default is 10).
    :param tokens: Maximum amount of tokens for the generation.

    :return: The first valid answer with a skill from the `skill_list`.
    :raises ValueError: Will be raised if no skill has been found after `max_retries`.
    """
    retries = 0
    while retries < max_retries:
        retries += 1
        # Call function
        response = function(
            system_prompt=system_prompt,
            request=request,
            skill_list=skill_list,
            tokens=tokens,
            temperature=temperature
        )
        # Debugging
        logging.info(f"Attempt {retries}: {response}")
        # Check if the answer contains a valid skill
        if isinstance(response, list): # Multi skill function
            valid_skills = [skill for skill in response if skill in skill_list]
            if valid_skills:
                return valid_skills
        elif isinstance(response, str) and response in skill_list: # Single skill function
            return response
    raise ValueError(f"No matching skill found after {max_retries} retries.")

if __name__ == "__main__":
    chatgpt_query()
    print(token_estimator("was ist der volle Name von Donald Trump?"))
    print(token_estimator("Schreibe ein langes Gedicht über Göthe."))
    print(token_estimator("Schreib mir einen Code der eine Spracherkennunungs-KI implementiert."))
