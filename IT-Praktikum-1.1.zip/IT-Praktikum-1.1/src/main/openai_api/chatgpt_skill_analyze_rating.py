import json
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from openai_api import chatgpt_query

def chatgpt_skill_analyze_rating(request="My printer does not work.",
                                 system_prompt="You are a helpful assistant that categorizes requests into skills and provides a skill rating as 'gut', 'mittel', or 'schlecht'.",
                                 skill_list=
                                 ["Troubleshooting & Fehlerdiagnose", "Datenbankkenntnisse", "IT-Sicherheitswissen & Password Management",
                                  "Netzwerkgrundlagen", "API-Integration", "Cybersecurity", "UX-Kompetenz"],
                                  tokens=50, temperature=0.5, model="gpt-3.5-turbo") -> str:
    """
    Analyzes a request to determine the required skill and its rating level ('gut', 'mittel', or 'schlecht').

    :param request: The text of the user request to be analyzed.
    :param system_prompt: General system behavior prompt for ChatGPT.
    :param skill_list: List of available skills for analysis.
    :param tokens: Maximum number of tokens allowed in ChatGPT's response.
    :param temperature: The temperature setting for the API (between 0 and 1, default is 0.5).
    :param model: The model to use for the ChatGPT API (Default is ).

    :return: A formatted string with the request, skill, and rating level.
    """
    # Generate the prompt for ChatGPT
    general_prompt = (
        "You are tasked with determining the required skill and its level of proficiency for a given user request.\n"
        "You can choose the skill level from: 'gut', 'mittel', or 'schlecht'.\n\n"
        "Here are the definitions for each rating:\n"
        "'schlecht': The task requires minimal experience with the skill. Basic or introductory knowledge is sufficient.\n"
        "'mittel': The task requires moderate knowledge and experience with the skill but does not demand deep expertise.\n"
        "'gut': The task requires advanced expertise, specialized knowledge, or significant experience with the skill.\n\n"
        "Skills to choose from: {skills}\n\n"
        "### Your Task:\n"
        "Request text: '{request}'\n"
        "Provide your response in this exact format: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}.\n"
        "If the request is unrelated to any listed skills, respond with: {{\"skill\": \"None\", \"rating\": \"Invalid\"}}."
    ).format(skills=', '.join(skill_list), request=request)
    try:
        # Send the request to the ChatGPT API and retrieve the response
        response_text = chatgpt_query(prompt=general_prompt, system_prompt=system_prompt, tokens=tokens, temperature=temperature, model=model)
        try:
            # Parse response as JSON
            skill_data = json.loads(response_text)
            if isinstance(skill_data, dict) and 'skill' in skill_data and 'rating' in skill_data:
                # Validate the rating value
                if skill_data['rating'] not in ['gut','mittel', 'schlecht']:
                    skill_data['rating'] = "Invalid"  # Mark invalid rating
                return f"Skill: {skill_data['skill']} Rating: {skill_data['rating']}"
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON response: {e}")
    except Exception as api_error:
        print(f"Unexpected API Error: {api_error}")
        return "Skill: Error communicating with API Rating: Invalid"
    # Handle cases where the response structure is unexpected
    return "Skill: Unknown Rating: Invalid"

if __name__ == "__main__":
    # Test case 1: Expected rating "gut"
    example_request = "Als Benutzer möchte ich verdächtige E-Mails auf Sicherheitsrisiken prüfen lassen, um Phishing-Angriffe zu vermeiden."
    result = chatgpt_skill_analyze_rating(request=example_request)
    print("Test Case 1:", result)

    # Test case 2: Empty request
    empty_request = ""
    result_empty = chatgpt_skill_analyze_rating(request=empty_request)
    print("Test Case 2:", result_empty)

    # Test case 3: Simple API-related request, expected rating "schlecht"
    basic_request = "How can I send an API request?"
    result_basic = chatgpt_skill_analyze_rating(request=basic_request)
    print("Test Case 3:", result_basic)

    # Test case 4: Complex technical task, expected rating "gut"
    complex_request = "Please help me implement a secure authentication mechanism using OAuth2."
    result_complex = chatgpt_skill_analyze_rating(request=complex_request)
    print("Test Case 4:", result_complex)

    # Test case 5: Unrelated request
    unrelated_request = "Please describe the meaning of life."
    result_unrelated = chatgpt_skill_analyze_rating(request=unrelated_request)
    print("Test Case 5:", result_unrelated)
