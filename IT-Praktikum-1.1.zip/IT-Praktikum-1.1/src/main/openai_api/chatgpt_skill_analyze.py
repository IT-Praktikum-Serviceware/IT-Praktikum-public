import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from openai_api import chatgpt_query

# This script sends a given prompt to the chatgpt api and gives a response on what skill from a given list fits best a given request
# 2 functions, 1 that returns only one skill, the other that may return multiple skills
# Improved modularity, so the function below can be called from anywhere and you just need to specify the request really, but ideally the skill list too.
# Optionally you can modify the system prompt, user prompt or the number of tokens.

def chatgpt_skill_analyze(request="Meine VPN-Verbindung wird unterbrochen.",
                          system_prompt = "You are a helpful assistant that categorizes requests into skills and most answers very consise and short.",
                          skill_list =
                          ["Troubleshooting & Fehlerdiagnose", "Datenbankkenntnisse", "IT-Sicherheitswissen & Password Management",
                           "Netzwerkgrundlagen", "API-Integration", "Cybersecurity", "UX-Kompetenz"],
                           tokens=50, temperature=0.5, model= "gpt-3.5-turbo") -> str:
    """
        Send the given request text to ChatGPT to determine the required skill from the given list of skill.\n
        **Important: Should always return only one skill.**
        
        :param request: The whole text of the client request.
        :param system_prompt: This is a general system prompt that decides what the response should look like.
        :param skill_list: The list of skills from which the best matching skill will be chosen.
        :param tokens: The amount of tokens with which the request is generated.
        :param temperature: The temperature setting for the API (between 0 and 1, default is 0.5).
        :param model: The model that is used (Default is "gpt-3.5-turbo").

        :return: The determined skill required to handle the given request from the given predefined list
    """
    general_prompt = (
            f"Determine which of the following skills is required to handle this request:\n"
            f"{', '.join(skill_list)}\n\n"
            f"Request text: '{request}'\n\n"
            f"Respond only with the single most important skill to solve that request out of the listed skills."
        )
    # chatgpt answer
    skill = chatgpt_query(prompt=general_prompt, system_prompt=system_prompt, tokens=tokens, temperature=temperature, model=model)

    # if the response is empty or contains 'None', return an appropriate response 
    if skill == '' or skill.lower() == 'none':
        return "Fehler bei Generierung der Antwort."
    return skill

def chatgpt_multi_skill_analyze(request = "Meine VPN-Verbindung wird unterbrochen.",
                                system_prompt = "You are a helpful assistant that categorizes requests into skills and most answers very consise and short.",
                                skill_list =
                                ["Troubleshooting & Fehlerdiagnose", "Datenbankkenntnisse", "IT-Sicherheitswissen & Password Management",
                                 "Netzwerkgrundlagen", "API-Integration", "Cybersecurity", "UX-Kompetenz"],
                                tokens=50, temperature=0.3, model="gpt-3.5-turbo") -> str:
    """
        Send the given request text to ChatGPT to determine the required skill from the given list of skill.\n
        **Important: May return multiple skills.**
        
        :param request: The whole text of the client request.
        :param system_prompt: This is a general system prompt that decides what the response should look like.
        :param skill_list: The list of skills from which the best matching skill will be chosen.
        :param tokens: The amount of tokens with which the request is generated.
        :param temperature: The temperature setting for the API (between 0 and 1, default is 0.3).
        :param model: The model that is used (Default is "gpt-3.5-turbo").

        :return: The determined skill required to handle the given request from the given predefined list
    """
    general_prompt = (
            f"Determine which of the following skills are required to handle this request:\n"
            f"{', '.join(skill_list)}\n\n"
            f"Request text: '{request}'\n\n"
            f"Respond with a list of relevant skills separated by commas. Use only the exact skill names provided in the list above.\n"
            f"If no skills are needed, respond with 'None'."
            )
    # chatgpt answer
    response_text = chatgpt_query(prompt=general_prompt, system_prompt=system_prompt, tokens=tokens, temperature=temperature, model=model)

    # if the response is empty or contains 'None', return an appropriate response 
    if not response_text or response_text.lower() == 'none':
        return "Fehler bei Generierung der Antwort."
    # return response_text
    # interpret the response as a list of skills
    skills = [skill.strip() for skill in response_text.split(',')]
    # return skills
    # Check if the skills are in the original skill list
    valid_skills = [skill for skill in skills if skill in skill_list]
    if not valid_skills:
        return "Antwort war nicht in der gegebenen Skill Liste enthalten"
    return valid_skills

# Example usage of function
if __name__ == "__main__":
    # five example requests, that model different technical problems
    test_requests = [
        "Als Benutzer möchte ich verdächtige E-Mails auf Sicherheitsrisiken prüfen lassen, um Phishing-Angriffe zu vermeiden.", # Cybersecurity (+ IT-Sicherheitswissen & Password Management)
        "Als Benutzer möchte ich Dateien ohne Fehlermeldungen speichern können, um meine Arbeit effizient abzuschließen.", # Troubleshooting & Fehlerdiagnose (+ Datenbankkenntnisse)
        "Als Benutzer möchte ich, dass Berichte schneller laden, um meine Arbeit ohne Verzögerung durchführen zu können.", # Troubleshooting & Fehlerdiagnose (+ Datenbankkenntnisse)
        "Als Benutzer möchte ich ein sicheres Passwort erstellen, das den Sicherheitsrichtlinien entspricht, um mein Konto zu schützen.", # IT-Sicherheitswissen & Password Management (+ Cybersecurity)
        "Als Benutzer möchte ich eine stabile VPN-Verbindung, um sicher und ohne Unterbrechung auf das Netzwerk zugreifen zu können." # Netzwerkgrundlagen (+ IT-Sicherheitswissen & Password Management, Cybersecurity)
        ]
    # first version skill list
    # test_skill_list = ["Software Support", "Hardware Support", "Network Support", "Email Support", "IT Security Support"]
    # previous version of skill list
    # test_skill_list = ["Produktwissen", "Fehlerdiagnose und Debugging", "Datenbankkenntnisse", "IT-Sicherheitswissen", "Beratungskompetenz", "API-Integration", "UX-Kompetenz"]
    test_skill_list = ["Troubleshooting & Fehlerdiagnose", "Datenbankkenntnisse", "IT-Sicherheitswissen & Password Management", "Netzwerkgrundlagen", "API-Integration", "Cybersecurity", "UX-Kompetenz"]

    print("Processing requests and assigning just one skill.")
    # to every request one skill should be matched
    for test_request in test_requests:
        determined_skill = chatgpt_skill_analyze(request=test_request)
        print(f"Determined skill for the request:\n'{test_request}'\n-> {determined_skill}\n")

    print("\nProcessing requests and assigning multiple skills.")
    for test_request in test_requests:
        determined_skills = chatgpt_multi_skill_analyze(request=test_request)
        print(f"Determined skills for the request:\n'{test_request}'\n-> {', '.join(determined_skills)}\n")
