import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from chatgpt_skill_analyze import chatgpt_skill_analyze, chatgpt_multi_skill_analyze
from chatgpt_query import chatgpt_query, token_estimator, call_until_skill_match

def token_estimator_test(test_requests):
    """
    Testet die Tokenanzahl für die Prompts, die an chatgpt_skill_analyze und chatgpt_multi_skill_analyze gesendet werden.\n
    Führt Tests direkt über die vorhandenen Analyse-Methoden durch.
    """
    # Beispielhafte Liste von Skills
    test_skill_list = [
        "Troubleshooting & Fehlerdiagnose",
        "Datenbankkenntnisse",
        "IT-Sicherheitswissen & Password Management",
        "Netzwerkgrundlagen",
        "API-Integration",
        "Cybersecurity",
        "UX-Kompetenz"
    ]
    # Sicherstellen, dass test_requests eine Liste ist
    if not isinstance(test_requests, list):
        test_requests = [test_requests]

    for request in test_requests:
        print(f"Anfrage: {request}")

        # Tokenanzahl für chatgpt_skill_analyze
        single_skill_result = chatgpt_skill_analyze(request=request, skill_list=test_skill_list, system_prompt="You are a helpful assistant.",
                                                    tokens=50, temperature=0.7)
        tokens_single_skill = token_estimator(single_skill_result, model="gpt-3.5-turbo")
        print(f"Single Skill Result: {single_skill_result}")
        print(f"Single Skill Prompt - Geschätzte Tokens: {tokens_single_skill}")

        # Tokenanzahl für chatgpt_multi_skill_analyze
        multi_skill_result = chatgpt_multi_skill_analyze(
            system_prompt="You are a helpful assistant.",
            request=request,
            skill_list=test_skill_list,
            tokens=50,
            temperature=0.7
        )
        # tokens_multi_skill = token_estimator(multi_skill_result, model="gpt-3.5-turbo")
        print(f"Multi Skill Result: {multi_skill_result}")
        # print(f"Multi Skill Prompt - Geschätzte Tokens: {tokens_multi_skill}")
        print("-" * 50)

def prompt_test():
    skill_list = ["A", "B", "C", "X", "Y", "Z"]
    request_info = "ABC und XYZ"
    prompt = (
                        "Du hast die Aufgabe, einen erforderlichen 'Skill' und das dazugehörige 'Rating'"
                        "für eine gegebene von einem Nutzer gegebene 'Request' zu bestimmen.\n"
                        "Du kannst das Rating aus folgenden Optionen wählen: 'gut', 'mittel' oder 'schlecht'.\n\n"
                        "Du kannst aus folgenden Skills wählen:\n{skills}\n\n"
                        "Request Text:\n'{request}'\n\n"
                        "Gebe nun nur den benötigten Skill, sowie Rating in folgender Form an, um die Request zu bearbeiten:\n"
                        "Skillname - Rating\n"
                        "Also kann z.B. deine Antwort so aussehen:\nBenutzerfreundlichkeit - mittel\n\n"
                        "Falls die Anfrage in keinem Zusammenhang mit den aufgelisteten Fähigkeiten steht, antworte mit vollständig leerem Text. "
                        "Du sollst also in dem Fall gar nichts antworten!"
                    ).format(skills = ', '.join(skill_list), request=request_info)
    return prompt    

# Example
if __name__ == "__main__":
    print(prompt_test())
    
    request = "Hilfe, ich kann psycopg2 einfach nicht pip installen."
    request1 = "Mein Passwort wird nicht erkannt"
    print(chatgpt_skill_analyze(request=request))
    print(token_estimator(request1))
    print(chatgpt_multi_skill_analyze(request=request))
    print(chatgpt_query(prompt=f"Folgende Anfrage: \"{request}\"\nAntworte **nur** mit einem oder, wenn nötig, mehreren Fähigkeiten, die benötigt werden, um die Anfrage zu lösen."))

    # prompt = "Was ist die wichtigsten Fähigkeit, wenn es darum geht, Fehler von Druckern zu beheben? Antworte nur mit der Nennung der Fähigkeit und ohne Satzzeichen."
    # print(len(prompt))
    # print(chatgpt_skill_analyze(prompt=prompt))
    # print(chatgpt_multi_skill_analyze(prompt=prompt))
    
    example_skill_list = [
        "Troubleshooting & Fehlerdiagnose",
        "Datenbankkenntnisse",
        "IT-Sicherheitswissen & Password Management",
        "Netzwerkgrundlagen",
        "API-Integration",
        "Cybersecurity",
        "UX-Kompetenz"
    ]
    example_request = "Passwort falsch"
    result = call_until_skill_match(chatgpt_multi_skill_analyze, example_skill_list, example_request)
    token_estimator_test(example_request)
