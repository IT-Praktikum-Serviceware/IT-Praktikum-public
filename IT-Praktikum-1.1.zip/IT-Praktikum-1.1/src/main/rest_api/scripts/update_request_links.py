import os
import sys
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
from api_functions import Get, Update, Create, Util, ChatGPT, get_access_token
import aipe_config

if __name__ == "__main__":
    start_time = time.time()
    access_token = get_access_token()

    Update.remove_all_skill_links(access_token)
    mid_time = time.time()
    print(f"Remove skill links time {time.time() - mid_time:.2f}")
    Create.new_request_links(access_token)

    print(f"Process time {time.time() - start_time:.2f}")
