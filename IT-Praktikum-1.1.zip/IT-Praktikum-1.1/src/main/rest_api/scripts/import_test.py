import sys
import os

# Füge das Wurzelverzeichnis, zum Python-Pfad hinzu 
# Dies ist notwendig weil Python nur Module und Pakete erkennt, die im Python-Pfad, also im sys.path definiert sind
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from api_functions import Get, Update, Create, Util, ChatGPT, get_access_token
from openai_api import chatgpt_query, chatgpt_skill_analyze, chatgpt_skill_analyze_rating

# prompt = "Was ist die wichtigste Fähigkeit, wenn es darum geht Fehler von Druckern zu beheben? Antworte nur mit der Nennung der Fähigkeit und ohne Satzzeichen."
# print(chatgpt_skill_analyze(prompt=prompt))

i = 10
for j in range(i):
    print(j + 1)
