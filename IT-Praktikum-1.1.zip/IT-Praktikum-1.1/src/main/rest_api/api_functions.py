import os
import sys
import json
import time
import inspect
import logging
import requests
import concurrent.futures
from typing import Any
from dotenv import load_dotenv

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
from openai_api import chatgpt_query, chatgpt_skill_analyze_rating, chatgpt_multi_skill_analyze
import aipe_config

log_dir = "src/main/logs"
os.makedirs(log_dir, exist_ok=True)

# logging main basic config
logging.basicConfig(
    filename=f"{log_dir}/api_functions.log", # path to log file
    level=logging.DEBUG, # Minimum log level
    format="%(asctime)s - %(levelname)s - %(message)s", # log formatting
    encoding="utf-8",
    force = True
)

# Check if there is already an existing StreamHandler
logger = logging.getLogger()
# if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG) # Minimum log level

# Filter for external logs
class NoExternalLogsFilter(logging.Filter):
    def filter(self, record):
        return "." not in record.name # Only use own logs

console_handler.addFilter(NoExternalLogsFilter())
console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
console_handler.setFormatter(console_formatter)

# Add to root logger
logger.addHandler(console_handler)

# Example usage of functions in api_function_test.py

# Base URL of the API used to access objects of the AI Process Engine
BASE_URL = aipe_config.BASE_URL

def get_access_token() -> str | None:
    """
    This function sends a POST request for authentication and retrieves an access token.\n
    The token is required for further communication with the API.

    :return: The authentication token as a string or None in case of errors.
    """
    logging.info("Start get_access_token")
    # Load environment variables to get secret data like client_secret and token_url
    load_dotenv()
    # Request the access token from the credentials
    url = os.getenv("token_url")
    grant = os.getenv("grant_type")
    id = os.getenv("client_id")
    secret = os.getenv("client_secret")
    # Header for the authentication request specifying the content type for the token request
    header = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    # Data for authentication: contains required parameters like Grant Type, Client ID, and Client Secret
    data = {
        'grant_type': grant,
        'client_id': id,
        'client_secret': secret,
    }
    # Send the POST request to the token endpoint
    response = requests.post(url=url, headers=header, data=data)
    # Check if the request was successful (Status code 200)
    if response.status_code == 200:
        # Extract the access token from the response
        token_data = response.json()
        access_token = token_data.get('access_token')
        logging.info(f"End get_access_token")
        return access_token
    else:
        # If there are errors in the request, output status code and error message
        logging.error(f"Error at Token request. Status code: {response.status_code}, Answer: {response.text}")
        return None

# Get and request infos from AIPE
class Get:
    """
    Class containing functions to get and request info from the AI Process Engine from Serviceware.\n
    Functions:
    - `extract_subjects_and_descriptions`: Extracts the subjects and descriptions of all requests.
    - `get_all_objects_by_type`: Retrieves all objects from the AIPE by a specific type.
    - `fetch_object`: Fetches data for an object by its ID.
    - `fetch_skills`: Retrieves the skills of a specific agent.
    - `get_object_type`: Fetches the type of object.
    - `get_display_name`: Fetches the display name  of an object.
    - `get_subject_and_description`: Fetches both the subject and description of an object.
    - `get_subject`: Fetches only the subject (display name) of an object.
    - `get_description`: Fetches only the description of an object.
    - `get_existing_links`: Fetches all existing links for a given object.
    - 'get_existing_request_links': Fetches all existing request to user links for a given object.
    - 'get_existing_skill_links': Fetches all existing skills to user links for a given object.
    - `search_objects`: Searches objects in AIPE.
    - `get_agent_id_by_display_name`: Retrieves the object ID of a user based on the display name.
    - `get_object_id`: Extracts the ID of an object from the JSON response.
    - 'get_display_name_from_json': Extracts the display name of an object from the JSON response.
    - `get_pending_objects`: Identifies objects that have no linked objects.
    - `get_all_link_definitions`: Retrieves all link definitions from the API.
    - `extract_link_definitions_by_types`: Extracts link definitions based on object types.
    - `get_all_object_definition_names`: Retrieves the names of all object definitions from the API, including optional drafts.
    - `get_agent_skills`: Returns all existing skills of an agent, formatted as "skillname - skilllevel".
    - `get_skill_id_by_name`: Returns the ID of a skill based on its name.
    - `get_all_agent_ids`: Retrieves all agent IDs from the API.
    - `get_all_skill_names`: Retrieves a list of unique skill names from the API.
    - `get_current_linked_agent`: Retrieves the currently linked agent for a given data object, based on its ID.
    """
    def extract_subjects_and_descriptions(requests: list, access_token: str) -> str:
        """
        Extracts the subjects and descriptions of all requests.

        :param requests: List of request objects.
        :param access_token: Authentication token.

        :return: List of strings with all requests combined.
        """
        logging.info("Start extract_subjects_and_descriptions")
        combined_text = ""
        for request in requests:
            request_id = request.get("system", {}).get("id")
            if not request_id:
                continue
            subject_description = Get.get_subject_and_description(request_id, access_token)
            if subject_description:
                entry = f"Titel: {subject_description.get('subject', '').strip()}\Beschreibung: {subject_description.get('description', '').strip()}"
                combined_text += entry + "\n\n"
        logging.info(f"End extract_subjects_and_descriptions")
        return combined_text.strip()

    def get_all_objects_by_type(type_name: str, access_token: str) -> list:
        """
        Retrieves all objects with a specific type from the AIPE.

        :param access_token: Authentication token.

        :return: List of all request objects.
        """
        logging.info("Start get_all_objects_by_type")
        all_requests = []
        max_pages = 10
        try:
            response = Get.search_objects(type_name=type_name, access_token=access_token, max_pages=max_pages)
        except Exception as e:
            logging.error(f"Error when requesting data from API: {e}")
        if isinstance(response, dict):
            requests_data = response.get("data", [])
        else:
            requests_data = response
        all_requests.extend(requests_data) # Add requests to list
        logging.info(f"End get_all_objects_by_type")
        return all_requests

    def fetch_object(data_object_id: str | int, access_token: str) -> dict | None:
        """
        Fetches the data of an object based on its ID.

        :param data_object_id: The ID of the object.
        :param access_token: Authentication token.

        :return: JSON data of the object or None in case of an error.
        """
        logging.info("Start fetch_object")
        # Build the URL to retrieve the specific object
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}"
        # Set headers containing the access token and accepted data format (JSON)
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        try:
            # Send the GET request to the endpoint
            response = requests.get(endpoint_url, headers=headers)
            # Check if the request was successful (status code 200)
            if response.status_code == 200:
                # Extract data in JSON format
                data = response.json()
                logging.debug("Data successfully retrieved:")
                # Print formatted data
                logging.debug(json.dumps(data, indent=4))
                logging.info(f"End fetch_object")
                return data
            elif response.status_code == 400:
                logging.error(f"Error: Invalid request (Status code {response.status_code}).")
            elif response.status_code == 404:
                logging.error(f"Error: Objekt with ID {data_object_id} not found (Status code {response.status_code}).")
            elif response.status_code == 401:
                logging.error(f"Error: Unauthorized access (Status code {response.status_code}). Token may be invalid.")
            elif response.status_code == 500:
                logging.error(f"Error: Servor error (Status code {response.status_code}). Please try later again.")
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            # If there is a problem with the request, catch the exception and print the error
            logging.error(f"Error during request: {e}")

    def fetch_skills(agent_id: str | int, access_token: str) -> list:
        """
        Retrieves the skills of a specific agent.

        :param agent_id: The ID of the agent whose skills should be fetched.
        :param access_token: Authentication token.

        :return: A list of the agent's skills in the format:
             [{"agent_id": <agent_id>, "skill_name": <skill_name>, "skill_level": <skill_level>}, ...]
        """
        logging.info("Start fetch_skills")
        skills = Get.get_agent_skills(agent_id, access_token)
        agent_skill_data = []
        # Convert each skill entry into a dictionary
        for skill_entry in skills:
            skill_parts = skill_entry.split(" - ")
            skill_name = skill_parts[0]
            skill_level = skill_parts[1] if len(skill_parts) > 1 else "" # If there is no level, leave blank
            agent_skill_data.append({
                "agent_id": agent_id,
                "skill_name": skill_name,
                "skill_level": skill_level
            })
        logging.info(f"Agent {agent_id}: {len(agent_skill_data)} skills retrieved") # Output of the number of retrieved skills
        logging.info(f"End fetch_skills")
        return agent_skill_data

    def get_object_type(data_object_id: str | int, access_token: str) -> str | None:
        """
        Retrieves the type of object.
        
        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: Authentication token.

        :return: The object type as a string, or None in case of an error.
        """
        logging.info("Start get_object_type")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "propertyPaths": ["system.type-name"]
        }
        try:
            # HTTP GET request
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                # Extract JSON data
                data = response.json()
                # Try to extract the type from the values
                type_name = data.get("values", {}).get("system.type-name", None)
                if type_name:
                    logging.info(f"End get_object_type")
                    return type_name
                else:
                    logging.warning("The object type could not be found.")
                    return None
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return None

    def get_display_name(data_object_id: str | int, access_token: str) -> str:
        """
        Retrieves the subject (display name) of an object.

        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: Authentication token.

        :return: Display name or None in case of an error.
        """
        logging.info("Start get_display_name")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "propertyPaths": [ "system.display-name"]
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                data = response.json()
                # Extraction of data
                displayname = data.get("values", {}).get("system.display-name", "Display name not available")
                logging.info(f"End get_display_name")
                return displayname
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
        return None

    def get_subject_and_description(data_object_id: str | int, access_token: str) -> dict[str, str] | None:
        """
        Retrieves the subject (display name) and description of an object.

        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: Authentication token.

        :return: A dictionary with 'subject' and 'description', or None in case of an error.
        """
        logging.info("Start get_subject_and_description")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "propertyPaths": ["description", "system.display-name"]
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                data = response.json()
                # Extraction of data
                subject = data.get("values", {}).get("system.display-name", "Subject not available")
                description = data.get("values", {}).get("description", "Description not available")
                logging.info(f"End get_subject_and_description")
                return {
                    "subject": subject,
                    "description": description
                }
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
        return None

    def get_subject(data_object_id: str | int, access_token: str) -> str:
        """
        This function retrieves only the subject (display-name) of an object.

        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: The authentication token.

        :return: The subject as a string, or None in case of an error.
        """
        logging.info("Start get_subject")
        result = Get.get_subject_and_description(data_object_id, access_token)
        if result:
            logging.info(f"End get_subject")
            return result.get("subject")
        return None

    def get_description(data_object_id: str | int, access_token: str) -> str:
        """
        This function retrieves only the description of an object.

        :param data_object_id: The ID of the object to be retrieved.
        :param access_token: The authentication token.

        :return: The description as a string, or None in case of an error.
        """
        logging.info("Start get_description")
        result = Get.get_subject_and_description(data_object_id, access_token)
        if result:
            logging.info(f"End get_description")
            return result.get("description")
        return None

    # This gets the links of the specified link definiton of the specified object
    def get_existing_links(data_object_id: str | int, link_definition: str, access_token: str, specified_relation_name="", other_relation_name = False) -> list:
        """
        This function retrieves all existing links for the specified object with the specified link.\n
        Make sure that the given data_object_id is actually a existing object object with given links.

        :param data_object_id: The ID of the object.
        :param link_definition: The link definition name.
        :param access_token: The authentication token.
        :param specified_relation_name: The specified relation name.
        :param other_relation_name: Whether the other relation name, the relation name for the inverse relation of the link definiton should be used.

        :return: A list of links or an empty list in case of an error.
        """
        logging.info("Start get_existing_links")
        if specified_relation_name:
            relation_name = specified_relation_name
        else:
            for name, value in inspect.getmembers(aipe_config): # searching for all variables in aipe_config
                if value == link_definition:
                    link_def_value_name = name # get the name of the constant of the link definition, e.g. "ROUTING"
                    break
            if other_relation_name: # add the relation name constant so the value of the relation name can be gotten
                rel_name = link_def_value_name + "_RELATION_NAME_OTHER"
            else:
                rel_name = link_def_value_name + "_RELATION_NAME"
            relation_name = getattr(aipe_config, rel_name, None) # search for the relation name in aipe_config
        if relation_name is None:
            logging.error("Error: The relation name could not be found.")
            return []
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        # Optional parameters for link query
        logging.info(f"Searching for existing links for object {data_object_id} with link definition '{link_definition}' and relation name '{relation_name}'.")
        params = {
            "linkDefinitionName": link_definition,
            "relationName": relation_name,
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                links_data = response.json()
                logging.info(f"End get_existing_links")
                return links_data.get('objects', [])
            elif response.status_code == 404:
                logging.error("Error: Definition, object or link does not exist.")
                return []
            elif response.status_code == 400:
                logging.error("Error: Invalid request.")
                return []
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return []
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return []

    # This gets the request to user links
    def get_existing_request_links(request_object_id: str | int, access_token: str) -> list:
        """
        This function specifically retrieves all existing routed links for the specified object. This works only for the request to user link.\n
        Make sure that the given skill_object_id is actually a existing request object with given links.

        :param data_object_id: The ID of the object.
        :param access_token: The authentication token.

        :return: A list of links or an empty list in case of an error.
        """
        logging.info("Start get_existing_request_links")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{request_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        # Optional parameters for link query
        logging.info(f"Searching for existing links for object {request_object_id} with link definition '{aipe_config.ROUTING}' and relation name '{aipe_config.ROUTING_RELATION_NAME}'.")
        params = {
            "linkDefinitionName": aipe_config.ROUTING,
            "relationName": aipe_config.ROUTING_RELATION_NAME,
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                links_data = response.json()
                logging.info(f"End get_existing_request_links")
                return links_data.get('objects', [])
            elif response.status_code == 404:
                logging.error("Error: Definition, object or link does not exist.")
                return []
            elif response.status_code == 400:
                logging.error("Error: Invalid request.")
                return []
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return []
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return []

    # This gets the skills to user links
    def get_existing_skill_links(skill_object_id: str | int, access_token: str) -> list:
        """
        This function specifically retrieves all existing user has skills links for the specified object. This works only for the request to user link.\n
        Make sure that the given skill_object_id is actually a existing skill object with given links.

        :param data_object_id: The ID of the object.
        :param access_token: The authentication token.

        :return: A list of links or an empty list in case of an error.
        """
        logging.info("Start get_existing_skill_links")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{skill_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        # Optional parameters for link query
        logging.info(f"Searching for existing links for object {skill_object_id} with link definition '{aipe_config.USER_HAS_SKILLS}' and relation name '{aipe_config.USER_HAS_SKILLS_RELATION_NAME}'.")
        params = {
            "linkDefinitionName": aipe_config.USER_HAS_SKILLS,
            "relationName": aipe_config.USER_HAS_SKILLS_RELATION_NAME,
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            logging.info(response)
            if response.status_code == 200:
                links_data = response.json()
                res = links_data.get('objects', [])
                for link in res:
                    logging.info(f"Found existing link with {link.get('system', {}).get('display-name')}, {link.get('system', {}).get('id')}.")
                logging.info(f"End get_existing_skill_links")
                return res
            elif response.status_code == 404:
                logging.error("Error: Definition, object or link does not exist.")
                return []
            elif response.status_code == 400:
                logging.error("Error: Invalid request.")
                return []
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return []
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return []

    def search_objects(type_name: str, access_token: str, max_pages=10, size=25, sort_attribute="system.id", sort_direction="asc", filter=None) -> list:
        """
        This method searches for objects of a specific type using a GET request.
        
        :param type_name: The name of the object type (e.g., "request").
        :param access_token: The authentication token.
        :param page: The page to retrieve (default: 0).
        :param size: The number of objects per page (default: 25).
        :param sort_attribute: The attribute by which sorting should be done (default: "system.id").
        :param sort_direction: The sorting direction (default: "asc").
        :param filter: Optional filter to further narrow down the objects.

        :return: A list of found objects or None in case of an error.
        """
        logging.info("Start search_objects")
        # API endpoint URL
        endpoint_url = f"{BASE_URL}/api/v1/objects"
        # Headers for the request with authentication
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json"
        }
        result = []
        logging.info(f"Searching for objects of type '{type_name}' on the first {max_pages} pages.")
        for page in range(max_pages + 1): # run through all pages
            # Parameters for the GET request
            params = {
                "typeName": type_name,
                "page": page,                       # result page
                "size": size,                       # number of results per page
                "sortAttribute": sort_attribute,    # Sorting by attribute
                "sortDirection": sort_direction     # Direction of sorting
            }
            # Optional filter, if specified
            if filter:
                params["filter"] = filter
            try:
                # Send the GET request
                response = requests.get(endpoint_url, headers=headers, params=params)
                # Check the response status code
                if response.status_code == 200:
                    # Extract objects from the response
                    data = response.json()
                    objects = data.get("objects", [])
                    result.extend(objects)
                    logging.info(f"Successfully retrieved {len(objects)} objects of type '{type_name}'")
                elif response.status_code == 400:
                    logging.error(f"Error: Invalid request. Please check the parameters, Answer: {response.text}")
                elif response.status_code == 404:
                    logging.error(f"Error: No object of type '{type_name}' found.")
                else:
                    logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
            except requests.exceptions.RequestException as e:
                logging.error(f"Error during request: {e}")
                return None
        logging.info(f"End search_objects")
        return result

    def get_agent_id_by_display_name(display_name_value: str, access_token: str) -> str:
        """
        This function retrieves the object ID of a user (type 'user') based on the 'display-name'.
        
        :param display_name_value: The display name to search for.
        :param access_token: The authentication token.

        :return: The object ID of the user or None if no user is found.
        """
        logging.info("Start get_agent_id_by_display_name")
        try:
            # Retrieve all users if the filter does not work correctly on the API side
            users = Get.search_objects(type_name=aipe_config.USER, access_token=access_token)
            if not users:
                logging.warning("No user found.")
                return None
            # Search for the matching user in the Python code
            for user in users:
                display_name = user.get("system", {}).get("display-name")
                if display_name == display_name_value:
                    user_id = Get.get_object_id(user)
                    logging.info(f"User ID for '{display_name_value}' found: {user_id}")
                    logging.info(f"End get_agent_id_by_display_name")
                    return user_id
            # No matching user found
            logging.warning(f"No user found with display name '{display_name_value}'")
            return None
        except Exception as e:
            logging.error(f"Error while searching for user ID: {e}")
            return None

    def get_object_id(obj: dict) -> str | None:
        """
        Extracts the ID of an object from the JSON response.

        :param obj: JSON object.

        :return: Object ID or None if no ID is found.
        """
        try:
            # Attempt to extract the ID from various possible fields
            obj_id = obj.get("system", {}).get("id") # Originally expected field
            if not obj_id:
                obj_id = obj.get("dataObjectId") # Alternative field for the ID
            if obj_id:
                return obj_id
            else:
                logging.warning(f"Warning: ID was not found. Full object: {json.dumps(obj, indent=2)}")
                return None
        except Exception as e:
            logging.error(f"Erorr while getting object with ID: {e}. Full object: {json.dumps(obj, indent=2)}")
            return None

    def get_display_name_from_json(obj: dict) -> str | None:
        """
        Extracts the display name of an object from the JSON response.

        :param obj: JSON object.

        :return: Display name or None if no ID is found.
        """
        try:
            # Attempt to extract the display name from various possible fields
            display_name = obj.get("system", {}).get("display-name") # Originally expected field
            if display_name:
                return display_name
            else:
                logging.warning(f"Warning: Display name was not found. Full object: {json.dumps(obj, indent=2)}")
                return None
        except Exception as e:
            logging.error(f"Erorr while getting object with display name: {e}. Full object: {json.dumps(obj, indent=2)}")
            return None

    def get_pending_objects(type_name: str, access_token: str) -> list:
        """
        Determines all skills that have no linked objects.

        :param access_token: Authentication token.

        :return: List of object IDs of skills without links.
        """
        logging.info("Start get_pending_objects")
        try:
            # Retrieve all objects
            object_list = Get.search_objects(type_name=type_name, access_token=access_token, filter=None)
            if not object_list:
                logging.warning(f"No objects of type {type_name} found.")
                return []
            pending_objects = []
            # Check links for each object
            for obj in object_list:
                obj_id = Get.get_object_id(obj)
                if not obj_id:
                    continue # Skip objects without a valid ID
                # Get the existing links for this object
                if type_name == aipe_config.SKILLS:
                    link_definition = aipe_config.USER_HAS_SKILLS
                elif type_name == aipe_config.REQUESTS:
                    link_definition = aipe_config.ROUTING
                else:
                    link_definition = ""
                links = Get.get_existing_links(obj_id, link_definition, access_token)
                # If no objects exist, add the request ID to the pending objects
                if not links:
                    pending_objects.append(obj_id)
            logging.info(f"{len(pending_objects)} objects found without link.")
            logging.info(f"End get_pending_objects")
            return pending_objects
        except Exception as e:
            logging.error(f"Error while processing pending objects: {e}")
            return []

    def get_all_link_definitions(access_token: str) -> list | None:
        """
        Retrieves all link definitions from the API.

        :param access_token: Authentication token.

        :return: A list of all link definitions or None in case of an error.
        """
        logging.info("Start get_all_link_definitions")
        # Endpoint URL for retrieving all link definitions
        endpoint_url = f"{BASE_URL}/api/v1/link-definitions"
        # Headers for the GET request with authentication
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        try:
            # Send the GET request
            response = requests.get(endpoint_url, headers=headers)
            # Check the response status code
            if response.status_code == 200:
                # Extract JSON data
                data = response.json()
                link_definitions = data.get("linkDefinitions", [])
                logging.info(f"Successfully retrieved {len(link_definitions)} link definitions.")
                logging.info(f"End get_all_link_definitions")
                return link_definitions
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return None

    def extract_link_definitions_by_types(object_types: dict, access_token: str) -> dict | None:
        """
        Extracts a specific link definition based on the given object types.
        
        :param object_types: A dictionary with 'word1' and 'word2' as object type definitions.
        :param access_token: Authentication token.

        :return: A dictionary with 'linkDefinitionName' and 'relationName', or None if no matching definition is found.
        """
        # Retrieve all link definitions using the get_all_link_definitions method
        logging.info("Start extract_link_definitions_by_types")
        link_definitions = Get.get_all_link_definitions(access_token)
        if not link_definitions:
            logging.error("Error while retrieving the link definitions.")
            return None
        left_object_type = object_types.get("word1")
        right_object_type = object_types.get("word2")
        logging.debug(f"Type of the left object: {left_object_type}")
        logging.debug(f"Type of the right object: {right_object_type}")
        # Variable for counting matching definitions
        matched_definitions = []
        # Search through link definitions for a matching definition
        for definition in link_definitions:
            left_to_right = definition.get("leftToRight", {})
            right_to_left = definition.get("rightToLeft", {})
            left_source = left_to_right.get("source", {})
            right_source = right_to_left.get("source", {})
            if (left_source.get("definitionName") == left_object_type and right_source.get("definitionName") == right_object_type):
                matched_definitions.append({
                    "linkDefinitionName": definition.get("name"),
                    "relationName": left_to_right.get("relationName"),
                })
            if (left_source.get("definitionName") == right_object_type and right_source.get("definitionName") == left_object_type):
                matched_definitions.append({
                    "linkDefinitionName": definition.get("name"),
                    "relationName": right_to_left.get("relationName"), # inverse case, for right to left, e.g. the case when removing skills to user links
                })
        logging.debug(f"Matching definitions: {matched_definitions}")
        # Output how many matching definitions were found
        logging.info(f"Number of matching definitions for {left_object_type} and {right_object_type}: {len(matched_definitions)}")
        logging.info(f"End extract_link_definitions_by_types")
        if matched_definitions:
            return matched_definitions[0] # Return the first matching definition
        else:
            logging.warning("No matching route definitions found.")
            return None

    def get_all_object_definition_names(access_token: str, include_drafts=False) -> list:
        """
        Retrieves all object names from the object definitions.

        :param access_token: Authentication token.
        :param include_drafts: Whether to include drafts in the response (default: False).

        :return: A list of object definition names or None in case of an error.
        """
        logging.info("Start get_all_object_definition_names")
        endpoint_url = f"{BASE_URL}/api/v1/object-definitions"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "includeDrafts": str(include_drafts).lower() # API expects 'true' or 'false' as a string
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                data = response.json()
                logging.info(f"End get_all_object_definition_names")
                # Extract only the names from the object definitions
                return [obj.get('name') for obj in data.get("objectDefinitions", []) if 'name' in obj]
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
        return None

    def get_agent_skills(data_object_id: str | int, access_token: str) -> list:
        """
        This function retrieves all existing skills for the specified agent in the format "SkillName - SkillLevel".

        :param data_object_id: The ID of the agent.
        :param access_token: Authentication token.

        :return: A list of skill names in the format "SkillName - SkillLevel".
        """
        logging.info("Start get_agent_skills")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "linkDefinitionName": aipe_config.USER_HAS_SKILLS,
            "relationName": aipe_config.USER_HAS_SKILLS_RELATION_NAME_OTHER,
        }
        try:
            response = requests.get(endpoint_url, headers=headers, params=params)
            if response.status_code == 200:
                links_data = response.json()
                skill_objects = links_data.get('objects', [])
                skillname_list = []
                for skill in skill_objects:
                    id = Get.get_object_id(skill)
                    if not id:
                        continue # Skip objects without a valid ID
                    name = Get.get_display_name(id, access_token)
                    if name:
                        skillname_list.append(name)
                logging.info(f"{len(skillname_list)} skills found for the agent.")
                logging.info(f"End get_agent_skills")
                return skillname_list
            elif response.status_code == 404:
                logging.error("Error: Definition, object or link does not exist.")
                return []
            elif response.status_code == 400:
                logging.error("Error: Invalid request.")
                return []
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return []
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return []

    def get_skill_id_by_name(skill_name: str, access_token: str) -> str | None:
        """
        Returns the ID of a skill based on its name.

        :param skill_name: The name of the skill.

        :return: The ID of the skill or None if the skill was not found.
        """
        logging.info("Start get_skill_id_by_name")
        try:
            # Retrieve all skills
            skill_list = Get.search_objects(type_name=aipe_config.SKILLS, access_token=access_token)
            if not skill_list:
                logging.info("No skills found.")
                return None
            # Search for the skill
            for skill in skill_list:
                skill_id = Get.get_object_id(skill)
                display_name = Get.get_display_name(skill_id, access_token)
                if display_name and skill_name in display_name:
                    logging.info(f"Skill '{skill_name}' found. ID: {skill_id}")
                    logging.info(f"End get_skill_id_by_name")
                    return skill_id
            logging.warning(f"Skill '{skill_name}' not found.")
            return None
        except Exception as e:
            logging.error(f"Error while searching for skill ID: {e}")
            return None

    def get_all_agent_ids(access_token: str) -> list:
        """
        Retrieves all agent IDs from the API.

        :param access_token: Authentication token.

        :return: List of agent IDs.
        """
        logging.info("Start get_all_agent_ids")
        try:
            # Retrieve all agents
            agents_list = Get.search_objects(type_name=aipe_config.USER, access_token=access_token, filter=None)
            if not agents_list:
                logging.warning("No requests found.")
                return []
            id_list = []
            for agent in agents_list:
                agent_id = Get.get_object_id(agent)
                if not agent_id:
                    continue  # Skip objects without a valid ID
                else:
                    id_list.append(agent_id)
            logging.info(f"{len(id_list)} agent IDs found.")
            logging.info(f"End get_all_agent_ids")
            return id_list
        except Exception as e:
            logging.error(f"Error during request: {e}")
            return []

    def get_all_skill_names(access_token: str) -> list:
        """
        Retrieves all unique skill names from the API.

        :param access_token: Authentication token.

        :return: List of unique skill names.
        """
        try:
            # Retrieve all skills
            skill_list = Get.search_objects(type_name=aipe_config.SKILLS, access_token=access_token, filter=None)
            if not skill_list:
                print("No skills found.")
                return []
            skillname_set = set()
            for skill in skill_list:
                id = Get.get_object_id(skill)
                if not id:
                    continue # Skip objects without a valid ID
                name = Get.get_display_name_from_json(skill)
                if name:
                    skillname = name.split(" - ")[0] # Only the skill name, without level
                    skillname_set.add(skillname) # Avoid duplicates
            unique_skills = list(skillname_set)
            print(f"{len(unique_skills)} unique skills found.")
            return unique_skills
        except Exception as e:
            print(f"Error during request: {e}")
            return []

    def get_current_linked_agent(data_object_id: str | int, access_token: str) -> str | None:
        """
        Retrieves the currently linked agent for a given data object.

        :param data_object_id: The ID of the data object for which the linked agent should be retrieved.
        :param access_token: Authentication token.

        :return: The ID of the linked agent if found, otherwise None.
        """
        logging.info("Start get_current_linked_agent")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        params = {
            "linkDefinitionName": aipe_config.ROUTING,
            "relationName": aipe_config.ROUTING_RELATION_NAME,
        }
        try:
            # Send a GET request to the API
            response = requests.get(endpoint_url, headers=headers, params=params)
            # Check if the request was successful
            if response.status_code == 200:
                links_data = response.json()
                linked_objects = links_data.get('objects', [])  
                # Check if there are linked objects
                if linked_objects:
                    linked_agent_id = linked_objects[0].get('system', {}).get('id')
                    logging.info(f"Found agent: {linked_agent_id}")
                    logging.info(f"End get_current_linked_agent")
                    return linked_agent_id
                else:
                    logging.warning("No links found.")
                    return None
            # Handle specific status codes
            elif response.status_code == 404:
                logging.error("Erorr: Object or link does not exist.")
                return None
            elif response.status_code == 400:
                logging.error("Erorr: Invalid request.")
                return None
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
            return None

# Updating relations and other properties of objects in the AIPE 
class Update:
    """
    Class containing functions updating relations and properties of objects in the AI Process Engine from Serviceware.\n
    Functions:
    - `delete_object`: Deletes an object by its ID, with optional dry-run and force mode.
    - `update_request_link`: Links a request to an agent using a predefined link definition.
    - `update_skill_link`: Links a skill to an agent using a predefined link definition.
    - `update_link`: Updates the connection between two objects, dynamically identifying the correct link definition.
    - `update_link_with_dynamic_relation`: Creates a link between two objects using a provided link definition.
    - `remove_link`: Removes an existing link between two objects.
    - 'remove_all_skill_links': Removes all links for all skills, specifically the skill to user link.
    - `activate_draft`: Activates a draft object definition in the AIPE Data Model.
    - `delete_all_objects`: Deletes all objects of a specific type.
    """
    def delete_object(data_object_id: str | int, access_token: str, dry_run=False, force=False) -> None | bool:
        """
        This function deletes a data object based on its ID.

        :param data_object_id: The ID of the data object to be deleted.
        :param access_token: Authentication token.
        :param dry_run: If True, only a test run is performed without actually deleting the object.
        :param force: If True, security warnings and dependencies are ignored.
        """
        # Build the URL for the endpoint to delete the object
        logging.info("Start delete_object")
        endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}"
        # Set the request headers
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }
        try:
            # Send the DELETE request to the endpoint with the parameters
            response = requests.delete(endpoint_url, headers=headers)
            # Check if the request was successful (status code 204 means deletion was successful)
            if response.status_code == 204:
                logging.info("The object was deleted successfully.")
                    # If a dry run was performed (status code 202)
            elif response.status_code == 202:
                logging.info("Dry run carried out. Object can be deleted, but was not.")
                return False
            # Handle error responses (e.g., 400, 404, 409)
            elif response.status_code == 400:
                logging.error("Error: Invalid parameter. Only dry_run or force can be set to true.")
            elif response.status_code == 404:
                logging.error("Error: The specified object does not exist.")
            elif response.status_code == 409:
                logging.error("Error: The object should not be deleted, because it is actively used.")
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            # Exception handling for connection issues or similar problems
            logging.error(f"Error during request: {e}")
        logging.info(f"End delete_object")

    def update_request_link(request_id: str | int, agent_id: str | int, access_token: str) -> None:
        """
        Links a request to an agent by calling the method `update_link_with_dynamic_relation` with the appropriate link definition.

        :param request_id: The ID of the request to be linked to an agent.
        :param agent_id: The ID of the agent to whom the request should be linked.
        :param access_token: Authentication token.
        """
        logging.info("Start update_request_link")
        # Create a dictionary for the link definition
        link_definitions = {
                "linkDefinitionName": aipe_config.ROUTING,          # Link definition
                "relationName": aipe_config.ROUTING_RELATION_NAME   # Relation
        }
        # Call the dynamic method
        Update.update_link_with_dynamic_relation(request_id, agent_id, link_definitions, access_token)
        logging.info(f"End update_request_link")

    # TODO: Fix, does not work. update_link is functional tho
    def update_skill_link(agent_id: str | int, skill_id: str | int, access_token: str) -> None:
        """
        Links a skill to an agent by calling the method `update_link_with_dynamic_relation` with the appropriate link definition.

        :param agent_id: The ID of the agent to whom the skill should be linked.
        :param skill_id: The ID of the skill to be linked to the agent.
        :param access_token: Authentication token.
        """
        logging.info("Start update_skill_link")
        # Create a dictionary for the link definition
        link_definitions = {
                "linkDefinitionName": aipe_config.USER_HAS_SKILLS,          # Link definition
                "relationName": aipe_config.USER_HAS_SKILLS_RELATION_NAME   # Relation
        }
        # Call the dynamic method
        Update.update_link_with_dynamic_relation(agent_id, skill_id, link_definitions, access_token)
        logging.info(f"End update_skill_link")

    def update_link(main_object_id: str | int, linked_object_id: str | int, access_token: str) -> None:
        """
        Updates the connection between two objects and checks both directions for the link definition.

        :param main_object_id: ID of the main object.
        :param linked_object_id: ID of the linked object.
        :param access_token: Authentication token.
        """
        logging.info("Start update_link")
        # Retrieve object types
        main_object_type = Get.get_object_type(main_object_id, access_token)
        linked_object_type = Get.get_object_type(linked_object_id, access_token)
        if not main_object_type or not linked_object_type:
            logging.error("Error: The object type can not be retrieved.")
            return None
        # Try to find the link definition in the original order
        link_definition = Get.extract_link_definitions_by_types({"word1": main_object_type, "word2": linked_object_type}, access_token)
        # If no definition is found, try in the reversed order
        reversed = False
        if not link_definition:
            link_definition = Get.extract_link_definitions_by_types({"word1": linked_object_type, "word2": main_object_type}, access_token)
            reversed = True  # Mark that the order was reversed
        if not link_definition:
            logging.warning(f"No matching link definition found for {main_object_type} and {linked_object_type}.")
            return
        # Prepare parameters for updating the connection
        link_definitions = {
            "linkDefinitionName": link_definition["linkDefinitionName"],
            "relationName": link_definition["relationName"]
        }
        # Consider the reversed order if necessary
        from_object_id = linked_object_id if reversed else main_object_id
        to_object_id = main_object_id if reversed else linked_object_id
        # Create or update the connection
        try:
            Update.update_link_with_dynamic_relation(from_object_id, to_object_id, link_definitions, access_token)
            logging.info(f"Link successfully updated between '{from_object_id}' and '{to_object_id}'.")
        except Exception as e:
            logging.error(f"Error during updating the link: {e}")
        logging.info(f"End update_link")

    def update_link_with_dynamic_relation(left_id: str | int, right_id: str | int, link_definition: dict, access_token: str) -> None:
        """
        This function links a request with an agent based on a single link definition.
        
        :param left_id: The ID of the request to be linked.
        :param right_id: The ID of the agent to be linked with the request.
        :param link_definition: A dictionary in the format:
        {'linkDefinitionName': 'name1', 'relationName': 'relation1'}.
        :param access_token: Authentication token.
        """
        logging.info("Start update_link_with_dynamic_relation")
        # Check if link_definition is a dictionary
        if not isinstance(link_definition, dict):
            raise ValueError("The parameter link_definition must be a dictionary.")
        # Ensure that the required keys are present
        link_definition_name = link_definition.get('linkDefinitionName')
        relation_name = link_definition.get('relationName')
        if not link_definition_name or not relation_name:
            raise ValueError("The link definition must contain 'linkDefinitionName' and 'relationName'.")
        # API endpoint for updating the link
        endpoint_url = f"{BASE_URL}/api/v1/external/objects/{left_id}"
        # Request headers
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        # Data payload for the request (no "remove" anymore)
        data = {
            "links": [
                {
                    "linkDefinitionName": link_definition_name, # The specified link definition name
                    "relationName": relation_name,              # The specified relation
                    "add": [right_id]                           # Add the agent's ID
                    # No "remove" anymore, as links are not being removed
                }
            ]
        }
        try:
            # Send the PATCH request
            response = requests.patch(endpoint_url, headers=headers, json=data)
            # Evaluate the status codes
            if response.status_code == 200:
                logging.info(f"Link {link_definition_name} successfully updated with {relation_name}.")
            elif response.status_code == 400:
                logging.error("Error: Invalid object attributes.")
            elif response.status_code == 404:
                logging.error("Error: Object not found.")
            elif response.status_code == 409:
                logging.error("Error: A link could not be added.")
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")
        logging.info(f"End update_link_with_dynamic_relation")

    def remove_link(data_object_id: str | int, linked_object_id: str | int, access_token: str) -> None:
        """
        Removes a link from an object.

        :param data_object_id: The ID of the main object from which the link should be removed.
        :param linked_object_id: The ID of the object that should no longer be linked.
        :param access_token: Authentication token.
        """
        logging.info("Start remove_link")
        # Retrieve object types
        object_type_1 = Get.get_object_type(data_object_id, access_token)
        object_type_2 = Get.get_object_type(linked_object_id, access_token)
        if not object_type_1 or not object_type_2:
            logging.error("Error: Object type could not be retrieved.")
            return None
        # Extract link definitions based on the types
        link_definition = Get.extract_link_definitions_by_types({"word1": object_type_1, "word2": object_type_2}, access_token)
        if not link_definition:
            logging.warning("No matching link definition found.")
            return None
        # URL and headers for the request
        url = f"{BASE_URL}/api/v1/objects/{data_object_id}"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        # Create payload
        payload = {
            "links": [
                {
                    "linkDefinitionName": link_definition["linkDefinitionName"],
                    "relationName": link_definition["relationName"],
                    "remove": [linked_object_id],
                }
            ]
        }
        try:
            # Send PATCH request
            response = requests.patch(url, json=payload, headers=headers)
            # Handle response status codes
            if response.status_code == 200:
                logging.info("Link successfully removed.")
                return response # No further output necessary
            elif response.status_code == 400:
                logging.error("Incorrect request:", response.json())
            elif response.status_code == 404:
                logging.error("Object not found.")
            elif response.status_code == 409:
                logging.error("Conflict while removing link:", response.json())
            else:
                logging.error(f"Unexpected error: {response.status_code}, {response.text}")
            logging.info(f"End remove_link")
            return response
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e} (Probably there was no link between the objects.)")
            return None

    def remove_all_skill_links(access_token):
        """
        Removes all links between skills and agents.

        :param access_token: Authentication token.
        """
        logging.info("Start remove_all_skill_links")

        skills = Get.get_all_objects_by_type(aipe_config.SKILLS, access_token)
        logging.debug(type(skills))
        logging.debug(f"{len(skills)} skills")
        for skill in skills:
            skill_id = Get.get_object_id(skill)
            logging.debug(skill_id)
            
            linked_objects = Get.get_existing_skill_links(skill_id, access_token)
            
            for link in linked_objects:
                obj_id = link.get("system", {}).get("id")
                logging.debug(obj_id)
                Update.remove_link(skill_id, obj_id, access_token)
        logging.info("End remove_all_skill_links")

    def activate_draft(object_definition_name: str, access_token: str) -> Any | None:
        """
        Activates the draft of an Object Definition in the AIPE Data Model.

        :param object_definition_name: System name of the Object Definition to be activated.
        :param access_token: Authentication token.
        """
        logging.info("Start activate_draft")
        # URL for activating the draft
        endpoint_url = f"{BASE_URL}/api/v1/object-definitions/{object_definition_name}/draft/activate"
        # Request headers
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        try:
            # Execute the POST request for activation
            response = requests.post(endpoint_url, headers=headers)
            # Process the response
            if response.status_code == 200:
                logging.info(f"The draft '{object_definition_name}' was successfully activated.")
                logging.info(f"End activate_draft")
                return response.json() if response.text else None
            elif response.status_code == 404:
                logging.error(f"Error: The draft '{object_definition_name}' was not found (404).")
            elif response.status_code == 409:
                logging.error(f"Error: The draft '{object_definition_name}' could not be activated (409).")
            elif response.status_code == 500:
                logging.error(f"Error: Other modules could not be notified (500).")
            else:
                logging.error(f"Unexpected error: {response.status_code} - {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Connection error: {e}")

    def delete_all_objects(type_name: str, access_token: str, force=False) -> None:
        """
        Deletes all objects of a specific type in the AI Process Engine.\n
        Note: This function is not intended to be used for deleting the user objects. To delete all request objects the parameter 'force' must be 'True'.

        :param type_name: The name of the object type to be deleted.
        :param access_token: The authentication token.
        :param force: Boolean value whether to delete all objects of type requests too.
        """
        logging.info("Start delete_all_objects")
        if ((type_name == aipe_config.REQUESTS and not force) or (type_name == aipe_config.USER)): # Objects of type user should under no circumstance be deleted by script
            logging.warning(f"Cancelling deletion process. The object of type {type_name} is not allowed to be deleted by this script.")
            return
        all_objects = []
        max_pages = 15
        
        # Note: If there are more than ~60 skills, you may need to execute this script multiple times
        objects = Get.search_objects(type_name=type_name, access_token=access_token, max_pages=max_pages)
        if isinstance(objects, dict):
            objects_data = objects.get("data", [])
        else:
            objects_data = objects
        all_objects.extend(objects_data)
        logging.debug(all_objects)
        logging.info(f"Now deleting {len(all_objects)} objects of type {type_name}...")
        for skill in all_objects:
            id = Get.get_object_id(skill)
            logging.debug(id)
            Update.delete_object(id, access_token)
        logging.info(f"Deleted {len(all_objects)} objetcs of type {type_name}.")
        logging.info(f"End delete_all_objects")

# Functions creating new AIPE objects
class Create:
    """
    Class containing functions creating objects, relations and properties of objects in the AI Process Engine from Serviceware.\n
    Functions:
    - `create_object_skill`: Creates an object instance of type "Skills" in AIPE Data Explorer.
    - `create_object_user`:  Creates an object instance of type "User" with the specified attributes.
    - `create_object_request`: Creates an object instance of type "Request" with a given subject and description.
    - `create_objects_from_json`: Reads a JSON file and creates multiple objects based on its content.
    - `create_links_from_json`: Creates links between objects using data from a JSON file.
    - `create_object_definition_draft`: Creates a draft of an object definition in the AIPE Data Model.
    - `create_agent_skill_links`: Links agents with required skills based on request analysis.
    - 'new_request_links': Creates links between agents and the required skills based on requests.
    - `create_rated_skills_in_aipe`: Creates skill objects with different rating levels ("bad", "medium", "good") in AIPE.
    """
    def create_object_skill(type_name: str, object_name: str, access_token: str) -> Any | None:
        """
        Creates an object instance of the object definition "Skills" in AIPE Data Explorer with the specified name and type.

        :param type_name: Type of the object definition.
        :param object_name: Object name.
        :param access_token: Authentication token.
        """
        logging.info("Start create_object_skill")
        # URL for creating the object
        endpoint_url = f"{BASE_URL}/api/v1/objects"
        # Headers for the request
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        # Object data
        payload = {
            "typeName": type_name,  # Type of the object definition
            "dataObject": {         # System data of the object
                "name": object_name
            },
            "links": []  # No links are added
        }
        try:
            # Sending the POST request to the server
            response = requests.post(endpoint_url, headers=headers, json=payload)
            # Processing the response
            if response.status_code == 201: # Status code 201 means the object was successfully created
                logging.info(f"Successfully created the skill {object_name}.")
                logging.info(f"End create_object_skill")
                return response.json()
            elif response.status_code == 400:
                logging.error(f"Error: Invalid request (Status code {response.status_code}), Answer: {response.text}")
            elif response.status_code == 401:
                logging.error(f"Error: Unauthorized access (Status code {response.status_code}). Check the Token.")
            elif response.status_code == 500:
                logging.error(f"Error: Server error (Status code {response.status_code}). Try again later.")
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")

    def create_object_user(type_name: str, first_name: str, last_name: str, email: str, user_name: str, access_token: str) -> Any | None:
        """
        Creates an object instance of the object definition "User" in AIPE Data Explorer with the specified parameters.

        :param type_name: Type of the object definition.
        :param first_name: First name of the object.
        :param last_name: Last name of the object.
        :param email: Email of the object.
        :param user_name: Username of the object.
        :param access_token: Authentication token.
        """
        logging.info("Start create_object_user")
        # URL for creating the object
        endpoint_url = f"{BASE_URL}/api/v1/objects"
        # Headers for the request
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        # Object data
        payload = {
            "typeName": type_name,  # Type of the object definition
            "dataObject": {         # System data of the object
                "first-name": first_name,
                "last-name": last_name,
                "email": email,
                "user-name": user_name
            },
            "links": []  # No links are added
        }
        try:
            # Sending the POST request to the server
            response = requests.post(endpoint_url, headers=headers, json=payload)
            # Processing the response
            if response.status_code == 201:  # Status code 201 means the object was successfully created
                logging.info(f"Successfully created the user {user_name}.")
                logging.info(f"End create_object_user")
                return response.json()
            elif response.status_code == 400:
                logging.error(f"Error: Invalid request (Status code {response.status_code}), Answer: {response.text}")
            elif response.status_code == 401:
                logging.error(f"Error: Unauthorized access (Status code {response.status_code}). Check the Token.")
            elif response.status_code == 500:
                logging.error(f"Error: Server error (Status code {response.status_code}). Try again later.")
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")

    def create_object_request(type_name: str, subject: str, description: str, access_token: str) -> Any | None:
        """
        Creates an object instance of the object definition "Request" in AIPE Data Explorer with the specified parameters.

        :param type_name: Type of the object definition.
        :param subject: Subject of the request.
        :param description: Description of the request.
        :param access_token: Authentication token.
        """
        logging.info("Start create_object_request")
        # URL for creating the object
        endpoint_url = f"{BASE_URL}/api/v1/objects"
        # Headers for the request
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        # Object data
        payload = {
            "typeName": type_name,  # Object type
            "dataObject": {         # System data of the object
                "subject": subject,
                "description": description
            },
            "links": []  # No links are added
        }
        try:
            # Sending the POST request to the server
            response = requests.post(endpoint_url, headers=headers, json=payload)
            # Processing the response
            if response.status_code == 201:  # Status code 201 means the object was successfully created
                logging.info(f"Successfully created the request {subject}.")
                logging.info(f"End create_object_request")
                return response.json()
            elif response.status_code == 400:
                logging.error(f"Error: Invalid request (Status code {response.status_code}), Answer: {response.text}")
            elif response.status_code == 401:
                logging.error(f"Error: Unauthorized access (Status code {response.status_code}). Check the Token.")
            elif response.status_code == 500:
                logging.error(f"Error: Server error (Status code {response.status_code}). Try again later.")
            else:
                logging.error(f"Error: Status code {response.status_code}, Answer: {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during request: {e}")

    def create_objects_from_json(file_path: str, access_token: str) -> dict:
        """
        Creates objects from the JSON file "init-data" and returns a mapping of their names and IDs.
        The function processes three types of objects:
        - "skills": Creates skill objects based on their name.
        - "user": Creates user objects with first name, last name, email, and username.
        - "request": Creates request objects with subject and description.
        
        * For each successfully created object, its ID is extracted and added to the ID map.
        * If errors occur or required fields are missing, the object is skipped.
        
        :param file_path: Path to the JSON file "init-data" containing the object data.
        :param access_token: Authentication token.
        
        :return: A dictionary with object names or user data as keys and their IDs as values.
        """
        logging.info("Start create_objects_from_json")
        id_map = {}
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                data = json.load(file)
        except Exception as e:
            logging.error(f"Error while reading the file {file_path}: {e}")
            return id_map
        objects = data.get("objects", [])
        if not objects:
            logging.error("Error: The array 'objects' is missing in the file.")
            return id_map
        for obj in objects:
            type_name = obj.get("typeName")
            if not type_name:
                logging.warning(f"Skipped object without field 'typeName': {obj}")
                continue
            if type_name == aipe_config.SKILLS:
                # Processing of objects of type 'skills'
                object_name = obj.get("name")
                if not object_name:
                    logging.warning(f"Skipping object of type 'skills' because the name is missing: {obj}")
                    continue
                result = Create.create_object_skill(type_name, object_name, access_token)
            elif type_name == aipe_config.USER:
                # Processing of objects of type 'user'
                first_name = obj.get("first-name")
                last_name = obj.get("last-name")
                email = obj.get("email")
                user_name = obj.get("user-name")
                if not all([first_name, last_name, email, user_name]):
                    logging.warning(f"Skipping object of type 'user' because mandatory fields are missing: {obj}")
                    continue
                result = Create.create_object_user(type_name, first_name, last_name, email, user_name, access_token)
            elif type_name == aipe_config.REQUESTS:
                # Processing of objects of type 'request'
                subject = obj.get("subject")
                description = obj.get("description")
                if not all([subject, description]):
                    logging.warning(f"Skipping object of type 'request' because mandatory fields are missing: {obj}")
                    continue
                result = Create.create_object_request(type_name, subject, description, access_token)
            else:
                logging.warning(f"Skipping object with type '{type_name}' because the type is not supported: {obj}")
                continue
            # Extracting the object ID and adding it to the map
            if result:
                obj_id = Get.get_object_id(result)
                if obj_id:
                    if type_name == aipe_config.USER:
                        # Store the ID under multiple keys for easier searching
                        user_name = obj.get("user-name")
                        full_name = f"{obj.get('first-name', '')} {obj.get('last-name', '')}".strip()
                        email = obj.get("email")
                        # Add all possible keys to the id_map
                        for identifier in [user_name, full_name, email]:
                            if identifier:
                                id_map[identifier] = obj_id
                                logging.info(f"Object '{identifier}' with ID '{obj_id}' was created.")
                    else:
                        object_identifier = obj.get("name") or obj.get("subject")
                        id_map[object_identifier] = obj_id
                        logging.info(f"Object '{object_identifier}' with ID '{obj_id}' was created.")
                else:
                    logging.info(f"Error: ID for object '{obj}' could not be extracted.")
        logging.info(f"End create_objects_from_json")
        return id_map

    def create_links_from_json(file_path: str, id_map: dict, access_token: str) -> None:
        """
        Creates links between objects based on the JSON file "init-data" and the object IDs, using dynamic connection updates via update_link.
        
        :param file_path: Path to the JSON file "init-data".
        :param id_map: Dictionary {object_name: object_id}.
        :param access_token: Authentication token.
        """
        logging.info("Start create_links_from_json")
        try:
            # Reading the JSON file
            with open(file_path, "r", encoding="utf-8") as file:
                data = json.load(file)
                links = data.get("links", [])
        except Exception as e:
            logging.error(f"Error while reading the file {file_path}: {e}")
            return
        if not isinstance(links, list):
            logging.error("Error: 'links' must be a list.")
            return
        for link in links:
            main_object_name = link.get("mainObjectName")
            linked_object_name = link.get("linkedObjectName")
            if not main_object_name or not linked_object_name:
                logging.warning(f"Link skipped because of missing data: {link}")
                continue
            # Retrieving the object IDs
            main_object_id = id_map.get(main_object_name)
            linked_object_id = id_map.get(linked_object_name)
            if not main_object_id or not linked_object_id:
                logging.warning(f"Link skipped because objects were not found: {link}")
                continue
            # Creating the connection via update_link
            try:
                Update.update_link(main_object_id, linked_object_id, access_token)
                logging.info(f"Link successfully created between '{main_object_name}' (ID: {main_object_id}) and '{linked_object_name}' (ID: {linked_object_id}).")
            except Exception as e:
                logging.error(f"Error while creating link between '{main_object_name}' and '{linked_object_name}': {e}")
        logging.info(f"End create_links_from_json")

    def create_object_definition_draft(name: str, access_token: str, object_group_name=None) -> Any | None:
        """
        Creates a draft of an object definition in the AIPE data model with the given parameters.
        
        :param name: Unique name of the object.
        :param access_token: Authentication token.
        :param object_group_name: (Optional) Name of the object group where the object should be created.
        """
        logging.info("Start create_object_definition_draft")
        # URL to create the draft
        endpoint_url = f"{BASE_URL}/api/v1/object-definitions/draft"
        # Request header
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        # Request payload
        payload = {
            "name": name,
            "displayNames": {
                "translations": [
                    {
                        "language": "en",
                        "value": name
                    }
                ]
            },
            "kind": "object"
        }
        # Optional: Add object Group Name if specified
        if object_group_name:
            payload["objectGroupName"] = object_group_name
        try:
            # Executing the POST request
            response = requests.post(endpoint_url, headers=headers, json=payload)
            # Response processing
            if response.status_code == 201:
                logging.info("Der Entwurf der Object Definition wurde erfolgreich erstellt.")
                logging.info(f"End create_object_definition_draft")
                return response.json() if response.text else None
            elif response.status_code == 400:
                logging.error(f"Error: Invalid request (Status code {response.status_code}).")
            elif response.status_code == 401:
                logging.error(f"Error: Unauthorized access (Status code {response.status_code}). Check the Token.")
            elif response.status_code == 409:
                logging.error(f"Error: An object with this name already exists (Status code {response.status_code}).")
            elif response.status_code == 500:
                logging.error(f"Error: Server error (Status code {response.status_code}) Try again later.")
            else:
                logging.error(f"Unexpected error: {response.status_code} - {response.text}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Connection error: {e}")

    def create_agent_skill_links(skill_list: list, access_token: str) -> None:
        """
        Creates links between agents and the required skills based on requests.
        
        :param access_token: Authentication token.
        """
        logging.info("Start create_agent_skill_links")
        starttime = time.time()
        try:
            # Step 1: Retrieve all skills and their IDs (once)
            logging.info("Retrieving all skills and their IDs...")
            skills = Get.search_objects(type_name=aipe_config.SKILLS, access_token=access_token)
            # Dictionary: {Skill-Name: Skill-ID}
            skill_dict = {skill["name"]: skill["system"]["id"] for skill in skills}
            if not skill_dict:
                logging.info("No skills found. End process.")
                return
            # Step 2: Search all requests
            logging.info("Searching all requests...")
            requests = Get.search_objects(type_name=aipe_config.REQUESTS, access_token=access_token)
            if not requests:
                logging.info("No requests found. End process.")
                return
            for request in requests: # Analyze for every request the according skill and user
                # Retrieve the request ID
                request_id = Get.get_object_id(request)
                if not request_id:
                    logging.info(f"Invalid request: {request}. Skipped.")
                    continue
                # Retrieve title (subject) and description
                logging.info(f"Retrieving subject and description for request ID '{request_id}'...")
                subject_and_description = Get.get_subject_and_description(request_id, access_token)
                request_info = f"Titel:\n{subject_and_description.get('subject')}\nBeschreibung:\n{subject_and_description.get('description')}"
                # Step 3: Retrieve the assigned agents
                logging.info(f"Retrieving the agent for request ID '{request_id}'...")
                agents = Get.get_existing_request_links(request_id, access_token)
                if not agents:
                    logging.info(f"No agent for request ID '{request_id}' found. Skipped.")
                    continue
                for agent in agents:
                    # Step 4: Analyze the skill with ChatGPT
                    logging.info(f"Analyze required skill for request...")
                    prompt = (
                        "Du hast die Aufgabe, einen erforderlichen 'Skill' und das dazugehörige 'Rating'"
                        "für eine gegebene von einem Nutzer gegebene 'Request' zu bestimmen.\n"
                        "Du kannst das Rating aus folgenden Optionen wählen: 'gut', 'mittel' oder 'schlecht'.\n\n"
                        "Du kannst aus folgenden Skills wählen:\n{skills}\n\n"
                        "Request Text:\n'{request}'\n\n"
                        "Gebe nun nur den benötigten Skill, sowie Rating in folgender Form an, um die Request zu bearbeiten:\n"
                        "Skillname - Rating\n"
                        "Also kann z.B. deine Antwort so aussehen:\nBenutzerfreundlichkeit - mittel\n\n"
                        "Falls die Anfrage in keinem Zusammenhang mit den aufgelisteten Fähigkeiten steht, antworte mit vollständig leerem Text. "
                        "Du sollst also in dem Fall gar nichts antworten!"
                    ).format(skills = ', '.join(skill_list), request=request_info)
                    needed_skill = chatgpt_query(prompt=prompt, temperature=0.5, model='gpt-3.5-turbo')
                    # skill_analysis = Util.format_skill_analysis(needed_skill)
                    if not needed_skill:
                        logging.info(f"Invalid answer for request. Skipped.")
                        continue
                    # Get skill ID directly from the dictionary (instead of calling get_skill_id_by_name every time)
                    skill_id = skill_dict.get(needed_skill)
                    if not skill_id:
                        logging.info(f"Skill ID for '{needed_skill}' not found. Skipped.")
                        continue
                    # Step 6: Linking the agent to the skill
                    agent_id = Get.get_object_id(agent)
                    if agent_id is None:
                        logging.info(f"Error: The agent ID could not be retrieved.")
                        continue
                    # skill_id = Get.get_skill_id_by_name(needed_skill, access_token)
                    # if skill_id is None:
                    #     logging.info(f"Error: The skill ID could not be retrieved.")
                    #     continue
                    logging.info(f"Linking agent '{agent_id}' with skill '{needed_skill}' (ID: {skill_id})...")
                    Update.update_link(agent_id, skill_id, access_token)
                    logging.info(f"Current process time {time.time() - starttime:.2f}")
            endtime = time.time()
            duration = endtime - starttime
            logging.info(f"Process end: {duration:.2f}")
        except Exception as e:
            logging.info(f"Error during processing: {e}")
        logging.info(f"End create_agent_skill_links")

    def new_request_links(access_token):
        """
        Creates links between agents and the required skills based on requests.

        :param access_token: Authentication token.
        """
        logging.info("Start create_agent_skill_links")
        current_skill_list = []

        skills = Get.get_all_objects_by_type(aipe_config.SKILLS, access_token)
        logging.debug(len(skills))
        logging.debug(type(skills))
        for skill in skills:
            skill_id = skill.get("name", {})
            current_skill_list.append(skill_id)

        Create.create_agent_skill_links(current_skill_list, access_token)
        logging.info("End create_agent_skill_links")

    def create_rated_skills_in_aipe(skills: list, access_token: str) -> None:
        """
        Creates skill objects with - good, - medium, and - bad ratings in AIPE based on a given skill list.
        
        :param skills: List of skills.
        :param access_token: Authentication token.
        """
        logging.info("Start create_rated_skills_in_aipe")
        if not skills:
            return
        for skill_name in skills:
            for rating in ["schlecht", "mittel", "gut"]:
                full_skill_name = f"{skill_name} - {rating}"
                Create.create_object_skill(type_name=aipe_config.SKILLS, object_name=full_skill_name, access_token=access_token)
        logging.info(f"End create_rated_skills_in_aipe")

# Util functions:
class Util:
    """
    Class containing utility functions for string, object and relation formatting and matching algorithms.\n
    Functions:
    - `get_all_agent_skills`: Retrieves all available skills, agents, and their assigned skills in a structured JSON format.
    - `format_skill_analysis`: Formats ChatGPT skill analysis response into "skill - rating" format.
    - `find_best_agent_for_skill`: Identifies the best agent based on required skills and assigns a matching score.
    """
    # Prompt string formatting
    def format_skill_analysis(chatgpt_response: str) -> str | None:
        """
        Formats the response from chatgpt_skill_analyze_rating into the format "skill - rating."

        :param chatgpt_response: The response from chatgpt_skill_analyze_rating in the format:
        "Skill: Skill Name Rating: poor/average/good"

        :return: A string in the format "skill - rating" (e.g., "UX expertise - good")
        """
        logging.info("Start format_skill_analysis")
        try:
            # Check if the response is a string
            if not isinstance(chatgpt_response, str):
                raise ValueError("The input must be a string.")
            # Extract skill and rating from the string
            skill_prefix = "Skill: "
            rating_prefix = "Rating: "
            if skill_prefix in chatgpt_response and rating_prefix in chatgpt_response:
                skill_start = chatgpt_response.index(skill_prefix) + len(skill_prefix)
                rating_start = chatgpt_response.index(rating_prefix) + len(rating_prefix)
                # Extract skill and rating values
                skill_name = chatgpt_response[skill_start:chatgpt_response.index(rating_prefix)].strip()
                rating = chatgpt_response[rating_start:].strip()
                # Check if the rating is valid
                if rating in ['gut', 'mittel', 'schlecht']:
                    logging.info(f"End format_skill_analysis")
                    return f"{skill_name} - {rating}"
                else:
                    raise ValueError("Invalid rating found")
            else:
                raise ValueError("Invalid format of answer")
        except ValueError as e:
            logging.error(f"Error while formatting the answer: {e}")
            return None

    # Gets all Skill, Agent and relations between those two objects and formats them
    def get_all_agent_skills(access_token: str) -> str | dict[str, str]:
        """
        This function collects all available skills, agents, and the respective skills of agents and returns them as a JSON object.
        The data is processed in parallel for efficiency.
        
        :param access_token: Authentication token.
        
        :return: A JSON object containing all skills, agents, and agent skills.
        """
        logging.info("Start get_all_agent_skills")
        start_time = time.time()
        try:
            # Step 1: Fetch all skills
            logging.debug("Retrieve all skill names...")
            all_skills = Get.get_all_skill_names(access_token)
            # Step 2: Fetch agent IDs
            logging.debug("Retrieve all agent IDs...")
            all_agents = Get.get_all_agent_ids(access_token)
            # Initialize list for agent skills
            agent_skills = []
            # Fetch skills for all agents in parallel using ThreadPoolExecutor
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                results = executor.map(lambda agent_id: Get.fetch_skills(agent_id, access_token),all_agents)
            # Collect all results in a list
            for result in results:
                agent_skills.extend(result)
            # Create final result as JSON
            result = {
                "skills": all_skills,
                "agents": all_agents,
                "agent_skills": agent_skills
            }
            json_result = json.dumps(result, indent=4, ensure_ascii=False) # Format the result as JSON
            end_time = time.time()
            logging.info(f"JSON data successfully generated in {end_time - start_time:.2f} seconds.") # Print total time
            logging.info(f"End get_all_agent_skills")
            return json_result
        except Exception as e:
            logging.error(f"Error during initialization: {e}")
            return {"error": str(e)}

    # Matching algorithm
    def find_best_agent_for_skill(required_skills: str, agent_skills: dict) -> tuple[str, dict[str, str]]:
        """
        Finds the best agent based on the required skills and outputs the scores of all agents.

        :param required_skills: Required skills in the format "Skill - Level" (e.g., Network Basics - good).
        :param agent_skills: Available agent skills with levels.

        :return: Tuple with (ID of the best agent, scores of all agents as a dict).
        """
        logging.info("Start find_best_agent_for_skill")
        best_agent = None
        best_match_score = -1
        agent_scores = {}  # Store scores for all agents
        # Define skill levels as a mapping for comparison
        skill_levels = {
            "schlecht": 1,
            "mittel": 2,
            "gut": 3
        }
        # Iterate over all agents and their skills
        for agent_id, skills in agent_skills.items():
            match_score = 0 # Points for exact or close matches
            partial_match_score = 0 # Points for partial matches
            # Check the required skills
            if " - " in required_skills: # Check the format
                skill_name, required_level = required_skills.split(" - ")
                agent_level = skills.get(skill_name) # Get the level of the agent
                if agent_level:
                    required_level = required_level.strip()
                    agent_level = agent_level.strip()
                    # Calculate the difference between required level and agent's current level
                    level_difference = abs(skill_levels[required_level] - skill_levels[agent_level])
                    if level_difference == 0:
                        match_score += 2 # Same level -> +2 points
                    elif level_difference == 1:
                        match_score += 1 # Difference of 1 level -> +1 point
                    elif level_difference == 2:
                        match_score += 0.5 # Difference of 2 levels -> +0.5 points
                    else:
                        partial_match_score += 0 # Difference bigger than 2 levels -> 0 points
                else:
                    partial_match_score += 0 # Skill missing -> 0 points
            else:
                logging.warning(f"Invalid format for skill rating: {required_skills}")
            # Calculate total score
            total_score = match_score + partial_match_score
            agent_scores[agent_id] = total_score # Save score for agent
            # Update the best agent if the score is higher
            if total_score > best_match_score:
                best_agent = agent_id
                best_match_score = total_score
        # Return the best agent and scores of all agents
        logging.info(f"End find_best_agent_for_skill")
        return best_agent, agent_scores

# Ex-chatgpt_rest_functions.py, edge-case like other differing relation names to be covered with analysis from chatpgt
class ChatGPT:
    """
    Class containing functions to cover scenarios if the agent-skill relation name differs in the AI Process Engine from Serviceware.\n
    Functions:
    - `identify_matching_words`: Retrieves the best matches for 'request' and 'user' from a list of object names.
    - `select_best_relation`: Chooses the best relation that represents assignment or processing.
    - `get_chatgpt_skill_list`: Generates a list of required skills based on all requests.
    """
    def identify_matching_words(object_names: list) -> dict[str, str] | None:
        """
        Identifies the best matches for the terms 'request' and 'user' from a list of object names using the ChatGPT API.
        
        :param object_names: A list of object names.
        
        :return: A dictionary with 'word1' and 'word2' as the most suitable names.
        """
        logging.info("Start identify_matching_words")
        # Prompt to find the matching word
        prompt = (f"Hier ist eine Liste von Objektnamen: {', '.join(object_names)}.\n"
            "Identifiziere:\n"
            "1. Das Wort, das am ehesten Begriffe wie 'request', 'Anfrage' oder 'ticket' beschreibt.\n"
            "2. Das Wort, das am ehesten Begriffe wie 'user', 'Experte' oder 'agent' beschreibt.\n"
            "Gib das Ergebnis **exakt** in der Form 'word1, word2' zurück.\n"
            "Nutze ausschließlich Begriffe aus der Liste."
        )
        system_prompt = "You are a helpful assistant that provides concise answers."
        max_tokens=50
        temperature=0.5
        try:
            # Send request to ChatGPT
            result = chatgpt_query(prompt=prompt, system_prompt=system_prompt, tokens=max_tokens, temperature=temperature)
            # Validate and parse the response
            if ", " in result:
                word1, word2 = result.split(", ", 1)
                word1 = word1.strip()
                word2 = word2.strip()
                # Validate: Words must be in the original list
                if word1 in object_names and word2 in object_names:
                    # Return as a dictionary instead of a set
                    logging.info(f"End identify_matching_words")
                    return {"word1": word1, "word2": word2}
                else:
                    logging.error(f"Error: Word '{word1}' or '{word2}' are not in the list.")
                    return None
            else:
                logging.error("Error: Answer does not equal the expected format 'word1, word2'.")
                return None
        except Exception as e:
            logging.error(f"Error while calling chatgpt_query: {e}")
            return None

    def select_best_relation(relation_names) -> dict[str, str] | None:
        """
        Selects the best relation from a list of relations using the ChatGPT API that most likely describes an assignment or processing.
        
        :param relation_names: A list of relations in the format "linkDefinitionName: XX relationName: XX."
        
        :return: A dictionary with the keys 'linkDefinitionName' and 'relationName' or None in case of errors.
        """
        logging.info("Start select_best_relation")
        # Normalize input (clean up spaces and commas)
        relation_names = [relation.strip().rstrip(",") for relation in relation_names]
        # Create prompt
        prompt = (
            f"Hier ist eine Liste von Relationen im Format 'linkDefinitionName: XX relationName: XX':\n"
            f"{', '.join(relation_names)}.\n"
            "Identifiziere diejenige Relation, die am ehesten beschreibt, dass eine Zuweisung oder Bearbeitung stattfindet.\n"
            "Gib exakt eine Antwort im Format 'linkDefinitionName: XX relationName: XX' zurück.\n"
            "Nutze ausschließlich Begriffe aus der bereitgestellten Liste."
        )
        system_prompt = "You are a helpful assistant that provides concise answers."
        max_tokens=50
        temperature=0.0
        try:
            # Send request to ChatGPT
            result = chatgpt_query(prompt=prompt, system_prompt=system_prompt, tokens=max_tokens, temperature=temperature)
            # Check if the response is in the correct format
            if "linkDefinitionName" in result and "relationName" in result:
                # Parse the response if it's in the correct format
                link_definition_name, relation_name = result.split(" relationName: ")
                logging.info(f"End select_best_relation")
                return {
                    'linkDefinitionName': link_definition_name.replace("linkDefinitionName: ", "").strip(),
                    'relationName': relation_name.strip()
                }
            else:
                logging.error(f"Error: Answer does not equal the expected format: {result}.")
                return None
        except Exception as e:
            logging.error(f"Error while calling chatgpt_query: {e}")
            return None

    # Get a skill list generated by chatgpt
    def get_chatgpt_skill_list(all_requests: list, length: int) -> list:
        """
        Asks ChatGPT for a list of skills for all requests.
        
        :param all_requests: Combined text of all requests.
        :param length: Number of requests.
        
        :return: List of general skills to solve the requests.
        """
        logging.info("Start get_chatgpt_skill_list")
        if not all_requests:
            logging.info("No requests to process.")
            return []    
        # Dynamic limitation based on the number of requests (exponentially scaled)
        max_skills = round(length ** 0.66)  # Scaling with exponent 0.66
        logging.info(f"This is how many requests there are: {length}")
        logging.info(f"So, the maximum number of skills is: {max_skills}")
        request_text = ("Analysiere die folgenden Anfragen und identifiziere die wichtigsten allgemeinen Skills, "
                        "die zur Lösung dieser Probleme erforderlich sind. Die Ausgabe sollte folgende Regeln beachten:\n"
                        f"- Versuche nicht mehr als {max_skills} Skills zu identifizieren. Das ist aber nur eine Maximalvorgabe. Es dürfen auch weniger Skills sein.\n"
                        "- Erstelle eine kompakte, durch Kommas getrennte Liste der benötigten Fähigkeiten.\n"
                        "- Nutze präzise Skill-Bezeichnungen anstelle von vagen oder allgemeinen Begriffen.\n"
                        "- Vermeide doppelte, synonyme oder überlappende Begriffe.\n"
                        "- Füge keine zusätzlichen Erklärungen oder Formatierungen hinzu.\n"
                        "- Verwende keine Satzzeichen außer Kommas, die die Skills voneinander trennen.\n"
                        "- Verwende eine neutrale, allgemeinverständliche Sprache.\n\n"
                        "Hier sind die Anfragen, die analysiert werden sollen:\n"
                        f"{all_requests}")
        try:
            response = chatgpt_query(request_text, tokens=250, temperature=0.5, model="gpt-4o-mini") # Limit the amount of used tokens, ~100 should be used
            skills = [skill.strip() for skill in response.split(",") if skill.strip()]
            logging.info(f"This is how many skills were analysed: {len(skills)}")
            logging.info(f"End get_chatgpt_skill_list")
            return skills
        except Exception as e:
            logging.error(f"Error while calling chatgpt_query: {e}")
            return []
