import os
import sys
import json
import logging
from api_functions import Get, Update, Create, Util, ChatGPT, get_access_token

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
import aipe_config

data_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../data')
file_path = os.path.join(data_folder, 'init_data.json')

def api_function_test():
    # Zugriff auf den Access Token
    access_token = get_access_token()

    # Retrieve all open (not-linked) objects
    # pendingObjs = Get.get_pending_objects(type_name=aipe_config.SKILLS, access_token=access_token)
    # print(pendingObjs)
    # print(type(pendingObjs))

    # Definierte ID des abzurufenden Objekts
    data_object_id = "gtF9Dk"
    skill_object_id = "IqcPnE"

    # object_data = Get.fetch_object(data_object_id, access_token)
    # print(object_data)
    # print(type(object_data))

    # print("Objektdaten:", object_data)
    # obj_type = Get.get_object_type(data_object_id, access_token)
    # print(obj_type)

    # links = Get.get_existing_links(skill_object_id, aipe_config.USER_HAS_SKILLS, access_token, other_relation_name=False)
    # print(links)
    # print(type(links))

    # skill_links = Get.get_existing_skill_links(skill_object_id, access_token)
    # print(skill_links)
    # print(type(skill_links))

    # links = Get.get_all_link_definitions(access_token)
    # print(links)
    # print(type(links))

    # print(json.dumps(links, indent=4))
    # object_id = Get.get_object_id(object_data)
    # print(f"Object id: {object_id}")
    # print(type(object_id))

    # sub_desc = Get.get_subject_and_description(data_object_id, access_token)
    # print(f"Subject and description of request: {sub_desc}")
    # print(type(sub_desc))

    # sub = Get.get_subject(data_object_id, access_token)
    # print(f"Subject of request: {sub}")
    # print(type(sub))
    
    # desc = Get.get_description(data_object_id, access_token)
    # print(f"Description of request: {desc}")
    # print(type(desc))

    # skills_list = Get.search_objects(type_name=aipe_config.SKILLS, access_token=access_token) # getallusers einfach mit der search_objects methode
    # print(skills_list)
    # print(type(users))
    # for skill in skills_list:
    #     print(json.dumps(Get.get_object_id(skill), indent=4))
    
    # Abrufen der Objekt-ID basierend auf dem display-name
    # display_name_value = "Vuong Trinh"
    # object_id = Get.get_agent_id_by_display_name(display_name_value, access_token)
    # print(object_id)
    # print(type(object_id))

    # request_id = 443021
    # agent_id = 442845 # ID bestimmen git get agent id oder schon direkte Ausgabe, Vuong Trinh
    # Update.update_request_link(request_id, agent_id, access_token) # Request wurde Vuong zugewiesen

    # search_results = Get.search_objects(type_name="request", access_token=access_token, filter=None) # alle requests finden
    # print(json.dumps(search_results, indent=4))

    # is_dry_run = True  # Setze dies auf True für einen Testdurchlauf ohne tatsächliches Löschen
    # force = True  # Setze dies auf True, um das Löschen ohne Sicherheitswarnungen zu erzwingen
    # Update.delete_object(data_object_id, access_token, dry_run=False, force=False)

    # link_definitions = Get.get_all_link_definitions(access_token)
    # for link_def in link_definitions:
    # print(json.dumps(link_def, indent=4))
    # left="request"
    # right="user"

    # print(relevant)
    request_id = 443294
    agent_id = 442845 # ID bestimmen mit get agent id oder schon direkte Ausgabe - Vuong
    # skills = Get.fetch_skills(agent_id, access_token)
    # print(type(skills))
    # print(skills)
    # ids = Get.get_all_skill_names(access_token)
    # print(ids)
    # dname = Get.get_display_name(agent_id, access_token)
    # print(dname)
    # print(type(dname))

    liniks = Get.get_agent_skills(agent_id, access_token)
    print(liniks)
    # agent_id = 442845
    # skill_id = "B0xpB7"
    # Update.update_link(request_id, agent_id, access_token)
    # Update.update_link(skill_object_id, agent_id, access_token)
    # Update.update_skill_link(agent_id, skill_object_id, access_token)

    # res = Update.remove_link(request_id, agent_id, access_token)
    # print(res)
    # print(type(res))

    # skill_name = "Benutzerfreundlichkeit - mittel"
    # skill_id = Get.get_skill_id_by_name(skill_name, access_token)
    # print(skill_id)
    # print(type(skill_id))

    # all = Get.get_all_object_definition_names(access_token)
    # print(all)
    # print(type(all))
    
    # all= ["Inquiry", "Professionale", "Skill", "Email"]
    # types = ChatGPT.identify_matching_words(all)
    # print(types)
    # print(type(types))

    # definitions = Get.extract_link_definitions_by_types(types, access_token)
    # print(definitions)
    # print(type(definitions))

    # all_objects = Get.get_all_objects_by_type(aipe_config.USER, access_token)
    # print(all_objects)
    # print(type(all_objects))
    # print(len(all_objects))

    # test = ["linkDefinitionName: routing relationname: routed-to, linkDefinitionName: skill relationname: has-ability , linkDefinitionName: Author relationname: written-by "]
    # definition = select_best_relation(test)
    # print("best:" ,best)
    # Update.update_link_with_dynamic_relation(request_id, agent_id, definition, access_token)
    # print(definition)

    # testing Create functions for initialization skript
    # id_map = Create.create_objects_from_json(file_path, access_token)
    # print(id_map)
    # print(type(id_map))
    # print(type(file_path))
    # Create.create_links_from_json(file_path, id_map, access_token)

    # Test skill and test_skill doesnt work
    # test skill does work
    
    # Create.create_object_definition_draft("testskill", access_token)
    # Create.create_agent_skill_links(access_token)
    # Update.activate_draft("to_be_deleted", access_token)

    # init = Util.init_agents_skills(access_token)
    # print(init)

    # Tests für Laufzeit von get_all_agent_skills
    # Util.get_all_agent_skills(access_token)
    # Now duration 17.50s
    # Older duration 22.56s

if __name__ == "__main__":
    api_function_test()
