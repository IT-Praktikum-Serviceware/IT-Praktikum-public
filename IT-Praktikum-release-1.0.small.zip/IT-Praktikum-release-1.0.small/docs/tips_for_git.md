# GitHub Tips

- Use **git clone https://github.com/lolepp/IT-Praktikum** to clone this repo
- Open the terminal (Hotkey: Ctrl + Shift + ö)
- Use **git checkout \<branch>** to open the branch you want to work on
- With **git add .** changes are saved for the next commit; instead of the dot you can specify which files should be added
- **git commit -m “\<message here>”** is the reference that is then pushed
- With **git push origin \<branch>** all commits are pushed
- **git pull** fetches all changes from the repo and merges them directly
- With **git fetch origin (\<branch>)** all changes (from a special branch) are downloaded from the online repo
- Use **git merge \<branch>** to integrate changes from the specified branch into the current branch
- Commands for information:
    - **git branch** (which branch you are on or have locally),
    - **git status** (current local changes compared to the last commit),
    - **git log** (check the log of all commits (on the selected branch)),
    - **git -help** (shows the help view for git, can also be combined with other commands)
    - **git --help** (opens local html documentation for git, can also be combined with other commands)
- **Keep the security of confidential information in mind**, more information here:

    [Removing confidential data from a repository](https://docs.github.com/de/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository)
    
    [Support GitHub](https://support.github.com/request)