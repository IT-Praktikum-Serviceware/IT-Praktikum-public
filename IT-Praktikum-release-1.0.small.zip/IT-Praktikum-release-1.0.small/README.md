# IT-Praktikum 24/25 ServiceWare
Code repository for the practical IT project management module in the winter semester 24/25.

## Getting started

### Project setup

#### Dependencies:
- Python. We recommend using at least Python version 3.9. 

    [Download page](https://www.python.org/downloads/)
- Git
    
    [Download page](https://git-scm.com/downloads)

#### Setup:
1. Clone this repo using the following command in a terminal.

    ```
    git clone https://github.com/IT-Praktikum-Serviceware/IT-Praktikum.git
    ```

    Beware that the URL may have changed and that you have access to the repository.

2. Install the defined requirements in `requirements.txt` using the following command.

    ```
    pip install -r requirements.txt
    ```

3. Check and define the `aipe_config.py` file.
    - For the `aipe_config.py`: Use the *internal* names that are defined in the AIPE.
    

4. Check and define the and the `.env` file
    - To define the `.env` file, first copy the `.env.template`, rename it to `.env` and then define the values for the `OPENAI API KEY` and the credentials for access to the Rest API of the AIPE.

5. Make sure that the following object and link definitions exist in the AIPE.

    Structure of the objects in the AIPE:
    ![Object relations in the AIPE](docs/assets/aipe_relation.png)

6. Execute `init.py` using this command.

    ```
    python init.py
    ```

### Weblinks
[Webclient of the Serviceware AIPE](https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/)

[Documentation of the Serviceware AIPE](https://docs.serviceware-se.com/serviceware-platform/de/ai_process_engine.html)

[Documentation of the RestAPI of the AIPE](https://petstore.swagger.io/?url=https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/data/docs)

[GitHub Repository](https://github.com/IT-Praktikum-Serviceware/IT-Praktikum)

## Project structure

### UML diagram
![UML-Diagramm](docs/assets/it-praktikum-v6.0.png)


#### Glossary
- AIPE = AI Process Engine
