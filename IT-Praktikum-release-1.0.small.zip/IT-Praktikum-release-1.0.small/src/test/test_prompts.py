import os
import sys
import json
import time
import hashlib

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from main.rest_api.api_functions import Get, Util, get_access_token
from main.openai_api import chatgpt_query
from test_routing import test

# Immature and not finished code. Proceed accordingly

# Caching-System für API-Aufrufe
cache = {}

def generate_cache_key(request, skill_list):
    """Erzeugt einen eindeutigen Cache-Schlüssel basierend auf Anfrage & Skill-Liste."""
    return hashlib.sha256((request + ",".join(skill_list)).encode()).hexdigest()

def chatgpt_skill_analyze_rating_prompts(request, skill_list, tokens=250, temperature=0.0, model="gpt-3.5-turbo"):
    """Ruft ChatGPT mit verschiedenen Prompts auf, um die benötigte Fähigkeit zu bestimmen."""
    if not skill_list or not request:
        print("❌ Fehler: Ungültige Eingabeparameter.")
        return {}

    cache_key = generate_cache_key(request, skill_list)
    if cache_key in cache:
        return cache[cache_key] # Holt die Antwort aus dem Cache, falls vorhanden

    prompts = [
        ("GENERAL_PROMPT",(
        "You are tasked with determining the required skill and its level of proficiency for a given user request.\n"
        "You can choose the skill level from: 'gut', 'mittel', or 'schlecht'.\n\n"
        "Here are the definitions for each rating:\n"
        "'schlecht': The task requires minimal experience with the skill. Basic or introductory knowledge is sufficient.\n"
        "'mittel': The task requires moderate knowledge and experience with the skill but does not demand deep expertise.\n"
        "'gut': The task requires advanced expertise, specialized knowledge, or significant experience with the skill.\n\n"
        "Skills to choose from: {skills}\n\n"
        "### Your Task:\n"
        "Request text: '{request}'\n"
        "Provide your response in this exact format: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}.\n"
        "If the request is unrelated to any listed skills, respond with: {{\"skill\": \"None\", \"rating\": \"Invalid\"}}."
        )),
        ("DETAILED_INSTRUCTION_PROMPT", (
            "You are tasked with determining the required skill and its level of proficiency for a given user request.\n"
            "You can choose the skill level from: 'gut', 'mittel', or 'schlecht'.\n\n"
            "Here are the definitions for each rating:\n"
            "'schlecht': The task requires minimal experience with the skill. Basic or introductory knowledge is sufficient.\n"
            "'mittel': The task requires moderate knowledge and experience with the skill but does not demand deep expertise.\n"
            "'gut': The task requires advanced expertise, specialized knowledge, or significant experience with the skill.\n\n"
            "Skills to choose from: {skills}\n\n"
            "### Your Task:\n"
            "Request text: '{request}'\n"
            "Provide your response in this exact format: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}.\n"
            "If the request is unrelated to any listed skills, respond with: {{\"skill\": \"None\", \"rating\": \"Invalid\"}}."
        )),
        ("SIMPLIFIED_PROMPT", (
            "You are tasked with determining the required skill and its level of proficiency for a given user request.\n"
            "You can choose the skill level from: 'gut', 'mittel', or 'schlecht'.\n\n"
            "Provide your response in this format: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}.\n"
            "If the request is unrelated, respond with: {{\"skill\": \"None\", \"rating\": \"Invalid\"}}."
        )),
        ("CONTEXTUAL_PROMPT", (
            "Analyze the following user request and determine which skill is needed and at what proficiency level.\n"
            "Allowed skill levels: 'gut', 'mittel', 'schlecht'.\n\n"
            "User Request: '{request}'\n"
            "Available skills: {skills}\n"
            "Response Format: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}."
        )),
        ("DIRECTIVE_PROMPT", (
            "Given the following user request, identify the most relevant skill and its proficiency level.\n"
            "Levels: 'gut', 'mittel', 'schlecht'.\n"
            "Skills List: {skills}\n"
            "User Request: '{request}'\n"
            "Response: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}."
        )),
        ("STRICT_PROMPT", (
            "Strictly follow these instructions: Determine the required skill and proficiency level ('gut', 'mittel', 'schlecht')\n"
            "Here are the definitions for each rating:\n"
            "'schlecht': The task requires minimal experience with the skill. Basic or introductory knowledge is sufficient.\n"
            "'mittel': The task requires moderate knowledge and experience with the skill but does not demand deep expertise.\n"
            "'gut': The task requires advanced expertise, specialized knowledge, or significant experience with the skill.\n\n"
            "for this user request: '{request}'. Choose from these skills: {skills}.\n"
            "Format the response exactly as: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}."
        ))
    ]

    responses = {}

    for prompt_name, prompt_template in prompts:
        prompt = prompt_template.format(skills=', '.join(skill_list), request=request)
        try:
            print(f"📨 Sende Prompt: {prompt_name}")
            response_text = chatgpt_query(prompt=prompt, system_prompt=prompt_name, tokens=tokens, temperature=temperature, model=model)
            print(f"📩 Antwort von API ({prompt_name}): {response_text}")

            try:
                skill_data = json.loads(response_text)
                if isinstance(skill_data, dict) and 'skill' in skill_data and 'rating' in skill_data:
                    responses[prompt_name] = skill_data
                else:
                    responses[prompt_name] = {"skill": "Unknown", "rating": "Invalid"}
            except json.JSONDecodeError:
                responses[prompt_name] = {"skill": "Error", "rating": "Invalid JSON"}
        except Exception as e:
            responses[prompt_name] = {"skill": "Error", "rating": str(e)}

    cache[cache_key] = responses # Speichert das Ergebnis im Cache
    return responses

# ANSI Escape Codes für Farben
COLORS = {
    "reset": "\033[0m",
    "red": "\033[91m",
    "green": "\033[92m",
    "yellow": "\033[93m",
    "blue": "\033[94m",
    "cyan": "\033[96m",
    "bold": "\033[1m"
}
def evaluate_test_cases(test_cases):
    """Testet die Routing-Logik, indem Anfragen analysiert und mit den erwarteten Ergebnissen verglichen werden."""
    if not test_cases:
        print(f"{COLORS['yellow']}⚠️ Warnung: 'test_cases' ist leer oder ungültig.{COLORS['reset']}")
        return []
    print(f"\n{COLORS['cyan']}🔍 Starte Testfall-Analyse...{COLORS['reset']}")
    time.sleep(1)

    # Agenten-Skills abrufen
    # Speichere statische Kopie der Agenten-Skill-Daten
    access_token = get_access_token()
    agents_skills_json = Util.get_all_agent_skills(access_token)
    agent_data = json.loads(agents_skills_json)
    skill_list = [entry["skill_name"] for entry in agent_data.get("agent_skills", [])]
    
    print(f"\n{COLORS['green']}✅ Statische Agentenfähigkeiten geladen:{COLORS['reset']}")
    print(f"{COLORS['blue']}{', '.join(skill_list)}{COLORS['reset']}\n")
    time.sleep(1)

    results = []
    prompt_accuracies = {}

    print(f"{COLORS['bold']}📏----------------------------------------📏{COLORS['reset']}")
    
    for test in test_cases:
        request = test.get("description", "")
        expected_skill, expected_rating = test.get("expected_skill", "None - Invalid").split(" - ")
        request_id = test.get("request_id", "Unknown")

        print(f"\n{COLORS['cyan']}🆕 Testfall: {request_id}{COLORS['reset']}")
        print(f"   📌 Erwarteter Skill: {COLORS['bold']}{expected_skill} ({expected_rating}){COLORS['reset']}")
        print(f"   📝 Anfrage: {COLORS['blue']}{request}{COLORS['reset']}")
        time.sleep(0.5)

        responses = chatgpt_skill_analyze_rating_prompts(request, skill_list=skill_list)

        if not responses:
            print(f"{COLORS['red']}❌ Keine gültige Antwort für Request ID: {request_id}{COLORS['reset']}")
            continue

        print(f"\n{COLORS['yellow']}🎯 Bewertete Antworten von ChatGPT:{COLORS['reset']}")

        for prompt_name, response in responses.items():
            received_skill = response.get("skill", "None")
            received_rating = response.get("rating", "Invalid")

            # Bewertung der Genauigkeit
            skill_match = received_skill == expected_skill
            rating_match = received_rating == expected_rating
            accuracy = (skill_match * 0.7) + (rating_match * 0.3)
            accuracy_score = int(accuracy * 100)

            # Farbe je nach Genauigkeit
            color = COLORS["green"] if accuracy_score >= 80 else COLORS["yellow"] if accuracy_score >= 50 else COLORS["red"]

            print(f"   ➤ {COLORS['bold']}{prompt_name}:{COLORS['reset']} {color}{received_skill} ({received_rating}) - Genauigkeit: {accuracy_score}%{COLORS['reset']}")

            # Speichere Genauigkeit für spätere Auswertung
            if prompt_name not in prompt_accuracies:
                prompt_accuracies[prompt_name] = []
            prompt_accuracies[prompt_name].append(accuracy_score)

        # Bestes Prompt basierend auf Genauigkeit bestimmen
        best_prompt = max(responses.keys(), key=lambda p: sum(prompt_accuracies[p]) / len(prompt_accuracies[p]))
        best_prompt = min(responses.keys()) # Feste Reihenfolge zur Konsistenz sicherstellen
        best_score = max([sum(scores) / len(scores) for scores in prompt_accuracies.values()])

        print(f"\n   ⭐ {COLORS['green']}Bestes Prompt: {best_prompt} mit {best_score:.2f}% Genauigkeit{COLORS['reset']}")

        results.append({
            "request_id": request_id,
            "expected_skill": expected_skill,
            "expected_rating": expected_rating,
            "best_prompt": best_prompt,
            "accuracy": best_score
        })

        print(f"{COLORS['bold']}📏----------------------------------------📏{COLORS['reset']}")

    # 🔍 Übersicht der Genauigkeiten pro Prompt
    print(f"\n{COLORS['cyan']}🔎 Gesamtgenauigkeit der Prompts:{COLORS['reset']}")
    for prompt, scores in prompt_accuracies.items():
        avg_score = sum(scores) / len(scores)
        color = COLORS["green"] if avg_score >= 80 else COLORS["yellow"] if avg_score >= 50 else COLORS["red"]
        print(f"   ➤ {COLORS['bold']}{prompt}:{COLORS['reset']} {color}{avg_score:.2f}%{COLORS['reset']}")

    print(f"\n{COLORS['green']}✅ Test abgeschlossen!{COLORS['reset']}\n")

    return results

if __name__ == "__main__":
    evaluate_test_cases(test)
    # chatgpt_query()
