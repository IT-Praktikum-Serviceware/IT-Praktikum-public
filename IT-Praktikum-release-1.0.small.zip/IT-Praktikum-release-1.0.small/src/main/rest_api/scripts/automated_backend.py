import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from api_functions import get_access_token, Get, Update, Create, Util, ChatGPT
from openai_api import chatgpt_skill_analyze, chatgpt_multi_skill_analyze

# Deprecated

# REST API to backend: Request Handling
# Our backend now fetches the request inside of the AIPE using the REST API.

def request_handling(access_token):
    print("Versuche alle requests ohne zugewiesenen Agenten mit get_pending_requests zu holen.")
    pending_ids = Get.get_pending_requests(access_token)
    print(f"Das sind alle request-IDs ohne zugewiesenen Agenten: {pending_ids}")
    print(f"Anzahl der Requests ohne zugewiesene Agenten: {len(pending_ids)}\n")

    requests = []
    print("Versuche die gesamten Objekte der einzelnen Requests ohne Agenten aufzurufen:")
    for id in pending_ids:
        print("Starte fetch_object.")
        requests.append(Get.fetch_object(id, access_token))
    print("Es wurden alle fetch_object Operationen erfolgreich durchgeführt.\n")
    
    desc = []
    print("Veruche alle einzelnen Titel und Beschreibungen der Requests ohne Agenten zu holen.")
    for id in pending_ids:
        res = Get.get_subject_and_description(id, access_token)
        print(res)
        desc.append(str(res))
    print("Es wurden alle get_subject_and_description Operationen erfolreich durchgeführt.\n")

    # print(desc)
    print(f"Das sind alle Objekt-IDs die nun an die ChatGPT API übergeben werden: {pending_ids}\n\n")

    return pending_ids

# Backend to ChatGPT API: Skill Analyzing
# Our backend sends the request text and a list of skills to the ChatGPT API to determine the required skill.

def skill_analyzing(ids, access_token):
    print("Nun beginnt der Prozess die offenen Requests zu bearbeiten, indem die dafür benötigten Skills, mithilfe von ChatGPT herausgefiltert werden.")
    print(f"Folgende Objekt-IDs werden analysiert: {ids}\n")
    res = []
    for id in ids:
    # id = '443278' # enter custom id 
        request = ""
        print(f"Aktuelle Request-ID, die abgehandelt wird: {id}")
        print("Versuche den Titel der Request herauszufinden.")
        subject = Get.get_subject(id, access_token)
        # print(subject)

        print("Versuche die Beschreibung der Request herauszufinden.")
        desc = Get.get_description(id, access_token)
        # print(desc)
        print("Erfolgreich Titel und Beschreibung abgerufen und gespeichert.")

        request = f"Titel:\n{subject}\nBeschreibung:\n{desc}"
        print(f"\nVersuche nun Titel und Beschreibung als folgende Request an ChatGPT zu senden:\n{request}")

        skill = chatgpt_skill_analyze(request=request)
        print(f"\n-> Analysierter Skill: {skill}\n")
        res.append(skill)
    
    print(f"Folgende Skills werden gebraucht, um die angegebenen Requests zu lösen: {res}\n\n")
    return res

# Backend to DB: Skill Matching
# Our backend retrieves the lists of agents that have this defined skill (“network basics”) from the DB and matches the best matching and available agent to the request.

def skill_matching(skills):
    print("Nun beginnt der Prozess die Datenbank nach den von ChatGPT analysierten benötigten Skills abzufragen.")
    agents = []
    for skill in skills:
        print(f"Es wird aktuell versucht für diesen Skill den passenden Agenten zu finden: {skill}")
        sql_command = f"SELECT display_name FROM agents WHERE skill = '{skill}';"
        print(f"Folgender SQL-Befehl wird versucht auszuführen:\n{sql_command}")
        # agent = db_query(sql_commands=sql_command)
        agent = None
        agents.append(agent[0][0])
        print(f"SQL-Befehl erfolgreich durchgeführt. Der Agent der eine Request mit dem benötigten Skill {skill} bearbeiten kann, ist: {agent[0][0]}\n")
    
    print(f"Das sind die Agenten, die eine Request zugewiesen bekommen werden: {agents}\n\n")
    return agents

# Backend to REST API: Answer
# Using the REST API our backend sends a response to the user and updates their request.

def rest_answer(request_ids, agents, access_token):
    res = []
    # Zuweisung
    print("Nun beginnt der Prozess die Requests den spezialisierten Agenten zuzuweisen.")
    print("Merke: Sarah, David, Sarah sind keine Nutzer in der AIPE. Also werden selbst gewählte, aber echte Agenten zugewiesen.")
    i = 0
    for id in request_ids:
        # Es wurden die display_names übergeben, aber wir brauchen die Agenten-ID
        if agents[i] != '443033': # Der 443033 Agent, hat die gleiche ID, womöglich wird die Request aber automatisch an Jan Svejda zugewiesen :O
            agent = Get.get_agent_id_by_display_name(agents[i], access_token=access_token)
        else:
            agent = '443033'
        print(f"Versuche Request-ID {id} mit dem Titel \"{Get.get_subject(id, access_token=access_token)}\" der Agenten-ID {agent}, also dem Agenten {agents[i]} zuzuweisen.")
        Update.update_link(id, agent, access_token=access_token)
        print(f"Zuweisungsoperation für Request-ID {id} zu Agent-ID {agent} durchgeführt.\n")
        i += 1
    print("Es wurden alle Zuweisungsoperationen durchgeführt.")
    
    # Check, ob erfolgreich hinzugefügt
    # return test_links(request_ids=request_ids, access_token=access_token)

def test_links(request_ids, access_token):
    print("Jetzt wird gecheckt, dass alle angegebenen Requests an einen Agenten geroutet sind.")
    res = [
        Get.get_existing_links(id, access_token=access_token)
        for id in request_ids
    ]
    # print(res)
    status = [link is None and "Fehlercode" not in str(link) for link in res]
    if all(status):
        print("Für alle Request-IDs sind Links vorhanden.")
    else:
        missing = [id for id, valid in zip(request_ids, status) if not valid]
        print(f"Für die folgenden Request-IDs sind keine Links vorhanden: {missing}")

    return status

def main():
    print("Versuche den Access Token zu speichern.")
    access_token = get_access_token()
    # Request Handling
    res_ids = request_handling(access_token=access_token)
    # all ids to be handled (which are not routed to an agent): ['443021', '443022', '443277', '443278', '443281', '443282', '443283', '443284']
    real_request_ids = ['443281', '443282', '443021'] # only these requests contain an usable title and description and are unrouted
    
    # Skill Analyzing
    res_ids = real_request_ids
    res_skills = skill_analyzing(ids=res_ids, access_token=access_token) # = ['Netzwerkgrundlagen', 'UX-Kompetenz', 'Netzwerkgrundlagen']

    # Skill Matching
    # res_skills = ['Netzwerkgrundlagen', 'UX-Kompetenz', 'Netzwerkgrundlagen']
    res_agents = skill_matching(res_skills)

    real_agents = ['Jan Svejda', '443033', 'Philipp Rauch']
    res_agents = real_agents
    res_assigned = rest_answer(request_ids=real_request_ids, agents=res_agents, access_token=access_token)
    
    # Check here the links
    # test_links(request_ids=real_request_ids, access_token=access_token)

if __name__ == "__main__":
    print("Versuche den Access Token zu speichern.")
    access_token = get_access_token()
    # Request Handling
    res_ids = request_handling(access_token=access_token)
    # all ids to be handled (which are not routed to an agent): ['443021', '443022', '443277', '443278', '443281', '443282', '443283', '443284']
    real_request_ids = ['443281', '443282', '443021'] # these requests contain an usable title and description
    
    # Skill Analyzing
    res_ids = real_request_ids
    res_skills = skill_analyzing(ids=res_ids, access_token=access_token)

    # Skill Matching
    # skills = ['Netzwerkgrundlagen', 'UX-Kompetenz', 'Netzwerkgrundlagen']
    res_agents = skill_matching(res_skills)

    agents = ['Jan Svejda', '443033', 'Philipp Rauch']
    res_assigned = rest_answer(request_ids=real_request_ids, agents=agents, access_token=access_token)
    
    # Check here the links
    # test_links(request_ids=real_request_ids, access_token=access_token)
