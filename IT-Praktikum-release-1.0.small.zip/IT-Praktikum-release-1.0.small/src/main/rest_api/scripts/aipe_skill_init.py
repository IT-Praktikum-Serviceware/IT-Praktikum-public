import os
import sys
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
from api_functions import Get, Update, Create, Util, ChatGPT, get_access_token
import aipe_config

def main():
    """Main function to process requests and create skills."""
    # Retrieve Access Token
    start_time = time.time()
    print("Starting AIPE Skill Initialization...")

    access_token = get_access_token()
    if not access_token:
        print("Error: No Access Token found.")
        return
    
    # Retrieve all requests
    requests = Get.get_all_objects_by_type(aipe_config.REQUESTS, access_token)
    if not access_token:
        print("No requests found")
        return
    
    # Extract subjects and descriptions
    all_requests = Get.extract_subjects_and_descriptions(requests, access_token)
    
    # print(len(all_requests)) # 20193, because that is the length of the string
    # print(len(requests)) # 83
    
    # Determine skills by ChatGPT
    skills = ChatGPT.get_chatgpt_skill_list(all_requests, len(requests))
    # print(skills)
    
    # Create rated sills in the AIPE
    Create.create_rated_skills_in_aipe(skills, access_token)

    # Create the agent to skill links
    Create.create_agent_skill_links(skills, access_token)

    print("AIPE Skill Initialization completed.")
    print(f"Whole initialization process took {time.time() - start_time:.2f} seconds.")

if __name__ == "__main__":
    main()
