import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
from api_functions import Get, Update, Create, Util, ChatGPT, get_access_token
import aipe_config

if __name__ == "__main__":
    access_token = get_access_token()
    # Are you really sure you want to delete all skills in the aipe? Then uncomment the following line
    Update.delete_all_objects(type_name=aipe_config.SKILLS, access_token=access_token)
