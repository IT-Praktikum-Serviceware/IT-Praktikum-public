import os
import sys 
import json
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from api_functions import get_access_token, Get, Update, Create, Util, ChatGPT

# Script is not functional

def evaluate_performance(workflows):
    """
    Bewertet die Performance basierend auf den Workflow-Daten.

    :param workflows: Liste von Workflows mit 'Status', 'Started', 'Ended'.
    
    :return: Dictionary mit Performance-Metriken.
    """
    total_workflows = len(workflows)
    completed_workflows = 0
    cancelled_workflows = 0
    running_workflows = 0
    durations = []
    for workflow in workflows:
        status = workflow.get('Status')
        started = workflow.get('Started')
        ended = workflow.get('Ended')

        if status == "Completed":
            completed_workflows += 1
            # Dauer berechnen, falls Endzeit vorhanden
            if started and ended:
                start_time = datetime.strptime(started, "%m/%d/%Y %I:%M %p")
                end_time = datetime.strptime(ended, "%m/%d/%Y %I:%M %p")
                durations.append((end_time - start_time).total_seconds())
        elif status == "Cancelled":
            cancelled_workflows += 1
        elif status == "Running":
            running_workflows += 1
    # Metriken berechnen
    average_duration = sum(durations) / len(durations) if durations else 0
    success_rate = (completed_workflows / total_workflows) * 100 if total_workflows else 0
    error_rate = (cancelled_workflows / total_workflows) * 100 if total_workflows else 0

    return {
        "Total Workflows": total_workflows,
        "Completed Workflows": completed_workflows,
        "Cancelled Workflows": cancelled_workflows,
        "Running Workflows": running_workflows,
        "Average Duration (seconds)": average_duration,
        "Success Rate (%)": success_rate,
        "Error Rate (%)": error_rate,
    }

def evaluate_and_update_skills(agent_id, workflows, skill_name, access_token):
    """
    Bewertet die Performance eines Agenten und aktualisiert seinen Skill-Level entsprechend.

    :param agent_id: Die ID des Agenten.
    :param workflows: Liste von Workflows mit 'Status', 'Started', 'Ended'.
    :param skill_name: Der Name des Skills, der beobachtet wird.
    :param access_token: Der Authentifizierungs-Token.
    """
    try:
        # Performance-Metriken berechnen
        performance_data = evaluate_performance(workflows)

        success_rate = performance_data["Success Rate (%)"]
        error_rate = performance_data["Error Rate (%)"]
        # Kriterien definieren
        upgrade_threshold = 90  # Erfolgsrate für Upgrade
        downgrade_threshold = 30  # Fehlerquote für Downgrade
        # Aktuelles Skill-Level des Agenten abrufen
        agent_skills = Get.get_agent_skills(agent_id, access_token)
        current_skill = next(
            (skill for skill in agent_skills if skill.startswith(skill_name)), 
            None
        )
        if not current_skill:
            print(f"Skill '{skill_name}' nicht bei Agent gefunden.")
            return
        # Aktuelles Level des Skills extrahieren
        skill_level_mapping = ["schlecht", "mittel", "gut"]  # Reihenfolge der Levels
        current_level = next((level for level in skill_level_mapping if level in current_skill), None)

        if not current_level:
            print(f"Level für Skill '{skill_name}' konnte nicht ermittelt werden.")
            return
        # Upgrade oder Downgrade bestimmen
        current_index = skill_level_mapping.index(current_level)
        new_index = current_index  # Standard: Keine Änderung

        if success_rate >= upgrade_threshold and current_index < len(skill_level_mapping) - 1:
            # Upgrade, wenn Erfolgsrate hoch ist
            new_index = current_index + 1
        elif error_rate >= downgrade_threshold and current_index > 0:
            # Downgrade, wenn Fehlerquote hoch ist
            new_index = current_index - 1

        # Nur ändern, wenn ein Upgrade oder Downgrade erforderlich ist
        if new_index != current_index:
            new_skill_level = skill_level_mapping[new_index]
            exchange_agent_skill(agent_id, skill_name, skill_name, new_skill_level, access_token)
            print(f"Skill '{skill_name}' wurde auf Level '{new_skill_level}' geändert.")
        else:
            print(f"Keine Änderung für Skill '{skill_name}' erforderlich.")
    except Exception as e:
        print(f"Fehler beim Evaluieren und Aktualisieren des Skills: {e}")

def exchange_agent_skill(agent_id, old_skill_name, new_skill_level, access_token):
    """
    Ersetzt einen bestehenden Skill eines Agenten durch einen neuen Skill.

    :param agent_id: Die ID des Agenten.
    :param old_skill_name: Der Name des zu ersetzenden Skills.
    :param new_skill_name: Der Name des neuen Skills.
    :param new_skill_level: Das Level des neuen Skills (z. B. "gut").
    :param access_token: Der Authentifizierungs-Token.
    """
    try:
        delimiter = " - "
        if delimiter in old_skill_name:
            new_skill_name= old_skill_name.split(delimiter)[0]  # Gibt den gesamten Text zurück, falls kein Trennzeichen gefunden wird.
        # Hole alle Skills des Agenten
        agent_skills = Get.get_agent_skills(agent_id, access_token)
        # Suche den ID des zu entfernenden Skills
        skill_to_remove = next(
            (skill for skill in agent_skills if skill.startswith(old_skill_name)), 
            None
        )
        print(skill_to_remove)

        if not skill_to_remove:
            print(f"Skill '{old_skill_name}' nicht bei Agent gefunden.")
            return
        
        # Entferne den alten Skill
        skill_id_to_remove = Get.get_skill_id_by_name(skill_to_remove, access_token)  # Funktion sollte Skill-ID holen
        
        Update.remove_link(agent_id, skill_id_to_remove, access_token)
        # Suche den neuen Skill in der Datenbank
        all_skills = Get.get_all_skill_names(access_token)
        matching_skills = [skill for skill in all_skills if skill.startswith(new_skill_name)]
        if not matching_skills:
            print(f"Skill '{new_skill_name}' nicht in der Datenbank gefunden.")
            return
        # Wähle das passende Level für den neuen Skill
        new_skill_full_name = f"{new_skill_name} - {new_skill_level}"
        # Füge den neuen Skill hinzu
        add_skills_to_api(agent_id,new_skill_full_name)
        print(f"Skill '{old_skill_name}' erfolgreich durch '{new_skill_name} - {new_skill_level}' ersetzt.")
    except Exception as e:
        print(f"Fehler beim Austausch des Skills: {e}")

def add_skills_to_api(agent_id, skill_name_with_skill_level):
    """
    Fügt einem Agenten einen neuen Skill mit dem angegebenen Niveau hinzu, falls dieser Skill noch nicht vorhanden ist.

    :param agent_id: Die ID des Agenten.
    :param skill_name: Der Name des Skills.
    :param skill_level: Das Niveau des Skills.
    """
    try:
        # Initialisiere die Daten der Agenten und deren Skills
        Util.get_all_agent_skills(access_token)
        # Lade die JSON-Daten
        with open('raw_agent_data.json', 'r') as file:
            data = json.load(file)
        for skill_name, skill_level in skill_name_with_skill_level:
            skill = f"{skill_name} - {skill_level}"
            # Hole die Skill-ID anhand des Namens
            skill_id = Get.get_skill_id_by_name(skill,access_token)
            if not skill_id:
                print(f"Skill '{skill}' konnte nicht gefunden werden.")
                continue
            already_has_skill = any(
                str(skill["agent_id"]) == str(agent_id) and
                skill["skill_name"] == skill_name and
                skill["skill_level"] == skill_level
                for skill in data["agent_skills"]
            )
            if already_has_skill : 
                print(f"Der Agent {agent_id} hat bereits die Fähigkeit '{skill_name}' auf dem Niveau '{skill_level}'.")
            # Verknüpfe den Skill mit dem Agenten
            Update.update_skill_link(agent_id, skill_id, access_token)
            print(f"Dem Agent {agent_id} wurde der Skill '{skill_name}' mit dem Niveau '{skill_level}' hinzugefügt.")
    except Exception as e:
        print(f"Fehler beim Hinzufügen der Skills: {e}")

if __name__ == "__main__":
    # Beispiel: Mehrere Skills mit Niveaus
    access_token = get_access_token()
    skills_to_add = {
        ("UX-Kompetenz", "gut"), 
        ("API-Integration", "mittel"), 
        ("Cybersecurity", "schlecht"),
        ("Netzwerkgrundlagen", "mittel"),
        ("Netzwerkgrundlagen", "gut")
    }
    add_skills_to_api(443307, skills_to_add)
