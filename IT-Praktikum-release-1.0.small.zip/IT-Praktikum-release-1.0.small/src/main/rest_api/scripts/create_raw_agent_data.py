import os
import sys
import json
import time
from collections import Counter

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from api_functions import get_access_token, Get, Update, Create, ChatGPT, Util
from openai_api import chatgpt_skill_analyze_rating, chatgpt_query 

def main():
    """Hauptausführpunkt.\n\nInitialisiert Agenten, analysiert Anfragen und berechnet den bestpassendsten Agenten."""
    start_time = time.time()
    # Absoluter Pfad zum Haupt-"data/raw_agent_data"-Ordner
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) # Geht zwei Ebenen über das aktuelle Verzeichnis
    save_path = os.path.join(project_root, "data")
    file_name = "raw_agent_data.json"
    full_path = os.path.join(save_path, file_name)
    
    access_token = get_access_token()
    init_time = time.time()
    print("-> Abrufen der Agenten und ihrer Fähigkeiten...")
    raw_agent_data = Util.get_all_agent_skills(access_token=access_token)
    init_agent_skill_duration=time.time()
    print("Rohdaten von init_agents_skills:")
    print(raw_agent_data)
    try:
        agent_data = json.loads(raw_agent_data)
        with open(full_path, "w", encoding="utf-8") as raw_file:
            json.dump(agent_data, raw_file, ensure_ascii=False, indent=4)
    except (ValueError, json.JSONDecodeError) as e:
        print("Fehler beim Extrahieren oder Verarbeiten von JSON-Daten:", e)
        sys.exit()
    
    if not agent_data or "skills" not in agent_data or "agents" not in agent_data or "agent_skills" not in agent_data:
        print("Fehler: Ungültige oder unvollständige Daten von init_agents_skills erhalten.")
        sys.exit()
    
    skills = agent_data["skills"]
    agents = agent_data["agents"]
    agent_skills = {}

    for entry in agent_data["agent_skills"]:
        agent_id = entry["agent_id"]
        skill_name = entry["skill_name"]
        skill_level = entry["skill_level"]
        if agent_id not in agent_skills:
            agent_skills[agent_id] = {}
        agent_skills[agent_id][skill_name] = skill_level
    
    # Beispielanfragen
    requests = [
        {"subject": "Benutzerfreundlichkeit verbessern", "description": "Identifizieren und beheben Sie Hindernisse in der Benutzeroberfläche, um die Bedienbarkeit zu optimieren. Der Fokus liegt darauf, intuitive Navigation, klare Anweisungen und ansprechendes Design sicherzustellen. Ziel ist es, eine nahtlose und zufriedenstellende Nutzererfahrung zu schaffen."},
        {"subject": "Wetterdaten abrufen", "description": "Rufe die aktuelle Wettervorhersage von der OpenWeatherMap-API. Das sollte recht schnell gehen. Jeder Anfänger kann das"},
        {"subject": "Daten mit Authentifizierung verarbeiten", "description": "Implementiere eine API-Anfrage mit Authentifizierungstoken"},
        {"subject": "Komplexe API-Integration entwickeln", "description": "Erstelle eine mehrstufige API-Integration, die Daten von mehreren Endpunkten kombiniert, sie transformiert und stellt eigenes RESTful API bereit, um die Ergebnisse abzurufen."},
    ]
    # Ein Counter, um Agenten-Einsätze zu zählen
    agent_assignment_counter = Counter()

    for req in requests:
        print(f"Zu verarbeitende Anfrage:\nTitel: {req['subject']}\nBeschreibung: {req['description']}")
        print("-> Bestimmung der benötigten Skills und Levels für die Anfrage...")

        # Führe die Skill-Analyse durch (fiktive Funktion)
        result = chatgpt_skill_analyze_rating(request=req['description'], skill_list=skills)
        
        # Ausgabe der Rohantwort
        print(f"Raw API Response: {result}")

        # Formatierte Ausgabe der Skill-Analyse
        formatted_result = Util.format_skill_analysis(result)
        #formatted_result = result
        if formatted_result is None:
            print("-> Fehler beim Formatieren der Antwort, überspringe diese Anfrage.")
            continue  # Überspringe die Anfrage, wenn das Ergebnis None ist

        print(f"-> Erforderliche Skills und Levels: {formatted_result}")
    
        # Finde den besten Agenten (fiktive Funktion)
        best_agent_id, agent_scores = Util.find_best_agent_for_skill(formatted_result, agent_skills)
        print("\n scores für alle agenten")
        for agent_id, score in agent_scores.items():
            print(f"Agent {agent_id}: Score {score}")
        if best_agent_id:
            # Hole den Namen des zugewiesenen Agenten
            agent_name = next((agent for agent in agents if agent == best_agent_id), None)
            print(f"-> Zugewiesener Agent: {agent_name}")
        else:
            print("-> Kein passender Agent für diese Anfrage gefunden.")
        print()

    print("\nAnzahl der Anfragen pro Agent:")
    for agent, count in agent_assignment_counter.items():
        print(f"{agent}: {count}")
    
    print(f"Zeit für gesamt also mit Access Token: {time.time() - start_time:.2f}")
    print(f"Zeit für init agent skills und co: {time.time() - init_time:.2f}")
    print(f"Zeit für init agent skills: {init_agent_skill_duration - init_time:.2f}")

if __name__ == "__main__":
    main()
