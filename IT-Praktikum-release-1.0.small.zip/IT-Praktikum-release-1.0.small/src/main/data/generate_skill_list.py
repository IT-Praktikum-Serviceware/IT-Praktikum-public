import json
import logging

# Deprecated

# Configure logging.
# - filename='setup.log': Specifies the name of the file where logs will be saved.
# - level=logging.INFO: Sets the logging level (records informational messages and above).
# - format='...': Specifies the format of log messages.
logging.basicConfig(
    filename='src/main/logs/setup.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    encoding="utf-8",
    force = True
)

# This script is designed to generate a JSON file (skill_list.json) containing sample data related to skills, agents, and requests.
# The data is structured and formatted for use in a database or as a reference file for a project.

# The script logs the process of generating the JSON file.
# Logs are written to setup.log, which records:
# Informational messages when the JSON file is created successfully.

def generate_skill_list_json():
    """Generates the JSON file `skill_list.json` containing information about skills, agents, and requests."""
    # Create a dictionary of data to be written to the JSON file.
    data = {
        "skills": [
            {"id": 1,"name": "Troubleshooting & Fehlerdiagnose"},
            {"id": 2,"name": "Datenbankkenntnisse"},
            {"id": 3,"name": "IT-Sicherheitswissen & Password Management"},
            {"id": 4,"name": "Netzwerkgrundlagen"},
            {"id": 5,"name": "API-Integration"},
            {"id": 6,"name": "Cybersecurity"},
            {"id": 7,"name": "UX-Kompetenz"}
        ],
        "agents": [
            {"id": 1, "first_name": "Lisa", "last_name": "Müller", "email": "lisa.mueller@example.de",
             "user_name": "lisa.m"},
            {"id": 2, "first_name": "Tom", "last_name": "Schmidt", "email": "tom.schmidt@example.de",
             "user_name": "tom.s"},
            {"id": 3, "first_name": "Alex", "last_name": "Wagner", "email": "alex.wagner@example.de",
             "user_name": "alex.w"},
            {"id": 4, "first_name": "Sarah", "last_name": "Fischer", "email": "sarah.fischer@example.de",
             "user_name": "sarah.f"},
            {"id": 5, "first_name": "Max", "last_name": "Koch", "email": "max.koch@example.de",
             "user_name": "max.k"},
            {"id": 6, "first_name": "Emily", "last_name": "Weber", "email": "emily.weber@example.de",
             "user_name": "emily.w"},
            {"id": 7, "first_name": "David", "last_name": "Richter", "email": "david.richter@example.de",
             "user_name": "david.r"}
        ],
        "requests": [
            {
                "id": 1,
                "title": "Phishing-Verdacht prüfen",
                "description": "Als Benutzer möchte ich verdächtige E-Mails auf Sicherheitsrisiken prüfen lassen, um Phishing-Angriffe zu vermeiden.",
                "required_skill": "Cybersecurity",
                "assigned_agent": "Lisa"
            },
            {
                "id": 2,
                "title": "Fehlermeldung beim Speichern",
                "description": "Als Benutzer möchte ich Dateien ohne Fehlermeldungen speichern können, um meine Arbeit effizient abzuschließen.",
                "required_skill": "Troubleshooting & Fehlerdiagnose",
                "assigned_agent": "Tom"
            },
            {
                "id": 3,
                "title": "Datenbank-Optimierung für bessere Leistung",
                "description": "Als Benutzer möchte ich, dass Berichte schneller laden, um meine Arbeit ohne Verzögerung durchführen zu können.",
                "required_skill": "Datenbankkenntnisse",
                "assigned_agent": "Alex"
            },
            {
                "id": 4,
                "title": "Sichere Passworterstellung",
                "description": "Als Benutzer möchte ich ein sicheres Passwort erstellen, das den Sicherheitsrichtlinien entspricht, um mein Konto zu schützen.",
                "required_skill": "IT-Sicherheitswissen & Password Management",
                "assigned_agent": "Sarah"
            },
            {
                "id": 5,
                "title": "Stabile VPN-Verbindung herstellen",
                "description": "Als Benutzer möchte ich eine stabile VPN-Verbindung, um sicher und ohne Unterbrechung auf das Netzwerk zugreifen zu können.",
                "required_skill": "Netzwerkgrundlagen",
                "assigned_agent": "Max"
            },
            {
                "id": 6,
                "title": "API-Anbindung an Drittanbietersystem",
                "description": "Als Benutzer möchte ich eine API-Anbindung zu einem Drittanbietersystem herstellen, um Daten nahtlos zwischen den Systemen zu synchronisieren.",
                "required_skill": "API-Integration",
                "assigned_agent": "Emily"
            },
            {
                "id": 7,
                "title": "Benutzerfreundlichkeit der Anwendung verbessern",
                "description": "Als Benutzer möchte ich, dass die Anwendung benutzerfreundlicher gestaltet wird, um schneller und einfacher zu navigieren.",
                "required_skill": "UX-Kompetenz",
                "assigned_agent": "David"
            }
        ],
       "agent_skills": [
             {"agent_id": 1, "agent_name": "Lisa", "skill_id": 6, "skill_name": "Cybersecurity"},
             {"agent_id": 2, "agent_name": "Tom", "skill_id": 1, "skill_name": "Troubleshooting & Fehlerdiagnose"},
             {"agent_id": 2, "agent_name": "Tom", "skill_id": 7, "skill_name": "UX-Kompetenz"},
             {"agent_id": 3, "agent_name": "Alex", "skill_id": 2, "skill_name": "Datenbankkenntnisse"},
             {"agent_id": 3, "agent_name": "Alex", "skill_id": 4, "skill_name": "Netzwerkgrundlagen"},
             {"agent_id": 4, "agent_name": "Sarah", "skill_id": 3, "skill_name": "IT-Sicherheitswissen & Password Management"},
             {"agent_id": 5, "agent_name": "Max", "skill_id": 4, "skill_name": "Netzwerkgrundlagen"},
             {"agent_id": 5, "agent_name": "Max", "skill_id": 5, "skill_name": "API-Integration"},
             {"agent_id": 6, "agent_name": "Emily", "skill_id": 5, "skill_name": "API-Integration"},
             {"agent_id": 7, "agent_name": "David", "skill_id": 3, "skill_name": "IT-Sicherheitswissen & Password Management"},
             {"agent_id": 7, "agent_name": "David", "skill_id": 6, "skill_name": "Cybersecurity"},
             {"agent_id": 7, "agent_name": "David", "skill_id": 7, "skill_name": "UX-Kompetenz"}
         ]
    }

    # Open the file skill_list.json in write mode.
    # - 'w': Open the file for writing (overwrites the file if it already exists).
    # - encoding='utf-8': Use UTF-8 encoding to support special characters.
    with open('src/main/data/skill_list.json', 'w', encoding='utf-8') as file:
        # Write the data dictionary to the JSON file.
        # - ensure_ascii=False: Retains original characters (does not replace them with escape sequences).
        # - indent=4: Formats the JSON with indents for better readability.
        json.dump(data, file, ensure_ascii=False, indent=4)

    # Log the successful creation of the file.
    logging.info("skill_list.json created successfully.")

if __name__ == "__main__":
    # Be careful if you really want to generate a skill list
    generate_skill_list_json()
    pass
