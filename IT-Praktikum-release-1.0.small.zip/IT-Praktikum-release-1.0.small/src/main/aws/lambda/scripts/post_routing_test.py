import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from post_routing import lambda_handler

if __name__ == "__main__":
    request = "bgGNoF"
    test_id = {"body":"{\"id\": \"bgGNoF\"}"}
    lambda_handler(event=test_id, context="")
