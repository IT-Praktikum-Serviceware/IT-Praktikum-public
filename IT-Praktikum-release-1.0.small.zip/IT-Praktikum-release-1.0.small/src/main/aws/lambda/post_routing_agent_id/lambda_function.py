import os
import json
import requests
from openai import OpenAI
import time
#import openai

# Basis-URL für die AIPE
BASE_URL = "https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/data"
AIPE_ENDPOINT = f"{BASE_URL}/api/v1/objects"

MODEL = "gpt-3.5-turbo"
TOKENS = 100
SYSTEM_PROMPT = "You are a helpful assistant that categorizes requests into skills and provides a skill rating as 'gut', 'mittel', or 'schlecht'."

# Definition of available skills
SKILLS = [
    "Troubleshooting & Fehlerdiagnose",
    "Datenbankkenntnisse",
    "IT-Sicherheitswissen & Password Management",
    "Netzwerkgrundlagen",
    "API-Integration",
    "Cybersecurity",
    "UX-Kompetenz"
]

# Funktion: Access Token holen
def get_access_token():
    """Holt das Access Token aus der API, um autorisierte Anfragen zu senden."""
    token_url = os.getenv("TOKEN_URL")
    client_id = os.getenv("CLIENT_ID")
    client_secret = os.getenv("CLIENT_SECRET")

    if not token_url or not client_id or not client_secret:
        raise ValueError("Fehlende Authentifizierungsparameter")

    response = requests.post(token_url, data={
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": os.getenv("GRANT_TYPE")
    })

    if response.status_code != 200:
        raise Exception(f"Fehler beim Abrufen des Access Tokens: {response.text}")

    return response.json().get("access_token")

def get_subject_and_description(data_object_id, access_token):
    """
    Diese Funktion ruft den Subject (display-name) und die Beschreibung (description) eines Objekts ab.

    :param data_object_id: Die ID des Objekts, das abgerufen werden soll.
    :param access_token: Das Authentifizierungs-Token.

    :return: Ein String im Format '"Titel": "...", "Beschreibung": "..."', oder None bei Fehler.
    """
    endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    params = {
        "propertyPaths": ["description", "system.display-name"]
    }
    try:
        response = requests.get(endpoint_url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            # Extraktion der Daten
            description = data.get("values", {}).get("description", "Beschreibung nicht verfügbar")
            subject = data.get("values", {}).get("system.display-name", "Subject nicht verfügbar")
            # return f'"Titel": "{subject}", "Beschreibung": "{description}"'
            return {
                "subject": subject,
                "description": description
            }
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
    return None

# Funktion: Objekte basierend auf einem Typ suchen
def search_objects(type_name, access_token, page=0, size=25, sort_attribute="system.id", sort_direction="asc", filter=None):
    """
    Diese Methode sucht nach Objekten eines bestimmten Typs mit GET-Anfrage.
    
    :param type_name: Der Name des Objekttyps (z. B. "request").
    :param access_token: Das Authentifizierungs-Token.
    :param page: Die Seite, die abgerufen werden soll (Standard: 0).
    :param size: Die Anzahl der Objekte pro Seite (Standard: 25).
    :param sort_attribute: Das Attribut, nach dem sortiert werden soll (Standard: "system.id").
    :param sort_direction: Die Sortierrichtung (Standard: "asc").
    :param filter: Optionaler Filter, um die Objekte weiter einzugrenzen.
    
    :return: Eine Liste der gefundenen Objekte oder None bei Fehler.
    """
    # API-Endpunkt URL
    endpoint_url = "https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/data/api/v1/objects"
    # Header für die Anfrage mit Authentifizierung
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }
    # Parameter für die GET-Anfrage
    params = {
        "typeName": type_name,
        "page": page,  # Seite der Ergebnisse
        "size": size,  # Anzahl der Ergebnisse pro Seite
        "sortAttribute": sort_attribute,  # Sortierung nach Attribut
        "sortDirection": sort_direction  # Sortierrichtung
    }
    # Optionaler Filter, falls angegeben
    if filter:
        params["filter"] = filter
    try:
        # Sende die GET-Anfrage
        response = requests.get(endpoint_url, headers=headers, params=params)
        # Überprüfe den Statuscode der Antwort
        if response.status_code == 200:
            # Extrahiere die Objekte aus der Antwort
            data = response.json()
            objects = data.get("objects", [])
            print(f"Erfolgreich {len(objects)} Objekte vom Typ '{type_name}' gefunden.")
            return objects
        elif response.status_code == 400:
            print("Fehler: Ungültige Anfrage. Bitte überprüfen Sie die Parameter.")
            print("Antwort:", response.text)
        elif response.status_code == 404:
            print(f"Fehler: Kein Objekt vom Typ '{type_name}' gefunden.")
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
        return None

# Funktion: Objekt-ID extrahieren
def get_object_id(obj):
    """
    Extrahiert die Objekt-ID (system.id) aus einem gegebenen Objekt.

    :param obj: Ein einzelnes Objekt (JSON).

    :return: Die Objekt-ID (string) oder None, falls keine ID existiert.
    """
    obj_id = obj.get("system", {}).get("id")
    if obj_id:
        return obj_id
    else:
        print("Warnung: Das Objekt hat keine gültige ID.")
        return None

# Funktion: Links für ein Objekt abrufen
def get_existing_links(data_object_id, access_token):
    """Diese Funktion gibt alle existierenden Links für das angegebene Objekt wieder."""
    endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    # Optionale Parameter für die Link-Abfrage
    params = {
        "linkDefinitionName": "routing",  
        "relationName": "routed-to",  
    }
    try:
        response = requests.get(endpoint_url, headers=headers, params=params)
        if response.status_code == 200:
            links_data = response.json()
            return links_data.get('objects', [])
        elif response.status_code == 404:
            print("Fehler: Definition, Objekt oder Link existiert nicht.")
            return []
        elif response.status_code == 400:
            print("Fehler: Ungültige Anfrage.")
            return []
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
        return []

def find_best_agent_for_skill(required_skills, agent_skills):
    """
    Findet den besten Agenten basierend auf den erforderlichen Fähigkeiten und gibt die Scores aller Agenten aus.

    :param required_skills: Erforderliche Fähigkeiten im Format "Skill - Level" (z.B. Netzwerkgrundlagen - gut).
    :param agent_skills: Verfügbare Fähigkeiten der Agenten mit Leveln.

    :return: Tuple mit (ID des besten Agenten, Scores aller Agenten als Dict).
    """
    best_agent = None
    best_match_score = -1
    agent_scores = {}  # Speichert die Scores für alle Agenten

    # Definiere die Skill-Level als Mapping für den Vergleich
    skill_levels = {
        "schlecht": 1,
        "mittel": 2,
        "gut": 3
    }

    # Iteration über alle Agenten und deren Skills
    for agent_id, skills in agent_skills.items():
        match_score = 0  # Punkte für exakte oder nahe Übereinstimmungen
        partial_match_score = 0  # Punkte für teilweise Übereinstimmungen
        # Überprüfen der erforderlichen Fähigkeiten
        if " - " in required_skills:  # Prüfung des Formats
            skill_name, required_level = required_skills.split(" - ")
            agent_level = skills.get(skill_name)  # Level des Agenten holen
            if agent_level:
                # Berechnen des Unterschieds zwischen erforderlichem Level und aktuellem Level des Agenten
                level_difference = abs(skill_levels[required_level] - skill_levels[agent_level])
                if level_difference == 0:
                    match_score += 2  # Gleiches Level +2 Punkte
                elif level_difference == 1:
                    match_score += 1  # Unterschied von 1 Level +1 Punkt
                elif level_difference == 2:
                    match_score += 0.5  # Unterschied von 2 Level +0,5 Punkte
                else:
                    partial_match_score += 0  # Unterschied größer als 2 Level: 0 Punkte
            else:
                partial_match_score += 0  # Fähigkeit fehlend: 0 Punkte
        else:
            print(f"Ungültiges Format für Skill-Rating: {required_skills}")
        # Berechnen der Gesamtpunktzahl
        total_score = match_score + partial_match_score
        agent_scores[agent_id] = total_score  # Speichere den Score für den Agenten
        # Aktualisiere den besten Agenten, falls die Punktzahl höher ist
        if total_score > best_match_score:
            best_agent = agent_id
            best_match_score = total_score
    # Rückgabe des besten Agenten und der Scores aller Agenten
    return best_agent, agent_scores

# Funktion: Skill-Analyse mit ChatGPT durchführen
def update_link_with_dynamic_relation(left_id, right_id, link_definition, access_token):
    """
    Diese Funktion verlinkt eine Anfrage mit einem Agenten basierend auf einer einzelnen Link-Definition.
    
    :param left_id: Die ID der Anfrage, die verlinkt werden soll.
    :param right_id: Die ID des Agenten, der mit der Anfrage verlinkt werden soll.
    :param link_definition: Ein Dictionary im Format:
        {'linkDefinitionName': 'name1', 'relationName': 'relation1'}.
    :param access_token: Das Authentifizierungs-Token.
    """
    # Überprüfen, ob link_definition ein Dictionary ist
    if not isinstance(link_definition, dict):
        raise ValueError("Der Parameter link_definition muss ein Dictionary sein.")
    # Sicherstellen, dass die Schlüssel vorhanden sind
    link_definition_name = link_definition.get('linkDefinitionName')
    relation_name = link_definition.get('relationName')
    if not link_definition_name or not relation_name:
        raise ValueError("Die Link-Definition muss 'linkDefinitionName' und 'relationName' enthalten.")
    # API-Endpunkt für das Update
    endpoint_url = f"{BASE_URL}/api/v1/external/objects/{left_id}"
    # Header für die Anfrage
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    # Daten-Body der Anfrage (kein "remove" mehr)
    data = {
        "links": [
            {
                "linkDefinitionName": link_definition_name,  # Der angegebene Link-Definition-Name
                "relationName": relation_name,  # Die angegebene Relation
                "add": [right_id]  # Die ID des Agenten hinzufügen
                # Kein "remove" mehr, weil keine Links entfernt werden
            }
        ]
    }
    try:
        # PATCH-Anfrage senden
        response = requests.patch(endpoint_url, headers=headers, json=data)
        # Statuscodes auswerten
        if response.status_code == 200:
            print(f"Link erfolgreich mit {link_definition_name} und {relation_name} aktualisiert.")
        elif response.status_code == 400:
            print("Fehler: Ungültige Objektattribute.")
        elif response.status_code == 404:
            print("Fehler: Objekt nicht gefunden.")
        elif response.status_code == 409:
            print("Fehler: Ein Link konnte nicht hinzugefügt werden.")
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")

# Funktion: Anfrage mit einem Agenten verlinken
def update_request_link(request_id, agent_id, access_token):
    """Diese Funktion verlinkt eine Anfrage (Request) mit einem Agenten, indem sie die Methode `update_link_with_dynamic_relation` mit der passenden Link-Definition aufruft."""
    # Erstelle das Dictionary für die Link-Definition
    link_definitions = {
            "linkDefinitionName": "routing",  # Link-Definition
            "relationName": "routed-to"       # Relation
        }
    
    # Rufe die dynamische Methode auf
    update_link_with_dynamic_relation(request_id, agent_id, link_definitions, access_token)

# Alle IDs von den Agenten abrufen
def get_all_agent_ids(access_token):
    """
    Ruft alle Agenten-IDs aus der API ab.

    :param access_token: Der Authentifizierungs-Token.
    
    :return: Liste der Agenten-IDs.
    """
    try:
        # Abruf aller Agenten
        agents_list = search_objects(type_name="user", access_token=access_token, filter=None)
        if not agents_list:
            print("Keine Requests gefunden.")
            return []
        id_list = []
        for agent in agents_list:
            agent_id = get_object_id(agent)
            if not agent_id:
                continue  # Überspringe Objekte ohne gültige ID
            else:
                id_list.append(agent_id)
        print(f"{len(id_list)} Agenten IDs gefunden.")
        return id_list
    except Exception as e:
        print(f"Fehler bei der Verarbeitung : {e}")
        return []

def get_display_name(data_object_id, access_token):
    """
    Diese Funktion ruft den Subject (display-name) und die Beschreibung (description) eines Objekts ab.

    :param data_object_id: Die ID des Objekts, das abgerufen werden soll.
    :param access_token: Das Authentifizierungs-Token.
    
    :return: Displayname oder None bei Fehler.
    """
    endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    params = {
        "propertyPaths": [ "system.display-name"]
    }
    try:
        response = requests.get(endpoint_url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            # Extraktion der Daten
            displayname = data.get("values", {}).get( "system.display-name", "Displayname nicht verfügbar")
            return displayname
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
    return None

def get_all_skill_names(access_token):
    """
    Ruft alle eindeutigen Skillnamen aus der API ab.

    :param access_token: Der Authentifizierungs-Token.
    :return: Liste von eindeutigen Skillnamen.
    """
    try:
        # Abruf aller Skills
        skill_list = search_objects(type_name="skills", access_token=access_token, filter=None)
        if not skill_list:
            print("Keine Skills gefunden.")
            return []
        skillname_set = set()
        for skill in skill_list:
            id = get_object_id(skill)
            if not id:
                continue  # Überspringe Objekte ohne gültige ID
            name = get_display_name(id, access_token)
            if name:
                skillname = name.split(" - ")[0]  # Nur der Skillname, ohne Level
                skillname_set.add(skillname)  # Duplikate vermeiden
            
        unique_skills = list(skillname_set)
        print(f"{len(unique_skills)} eindeutige Skills gefunden.")
        return unique_skills
    except Exception as e:
        print(f"Fehler bei der Verarbeitung: {e}")
        return []

def get_agent_skills(data_object_id, access_token):
    """
    Diese Funktion gibt alle existierenden Skills für den angegebenen Agenten in der Form "skillname - skilllevel" wieder.

    :param data_object_id: Die ID des Agenten.
    :param access_token: Der Authentifizierungs-Token.

    :return: Liste von Skillnamen in der Form "skillname - skilllevel"
    """
    endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/links"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    params = {
        "linkDefinitionName": "user-has-skills",
        "relationName": "user-has-skills",
    }
    try:
        response = requests.get(endpoint_url, headers=headers, params=params)
        if response.status_code == 200:
            links_data = response.json()
            skill_objects = links_data.get('objects', [])

            skillname_list = []
            for skill in skill_objects:
                id = get_object_id(skill)
                if not id:
                    continue  # Überspringe Objekte ohne gültige ID
                name = get_display_name(id, access_token)
                if name:
                    skillname_list.append(name)

            # print(f"{len(skillname_list)} Skills für den Agenten gefunden.")
            return skillname_list
        elif response.status_code == 404:
            print("Fehler: Definition, Objekt oder Link existiert nicht.")
            return []
        elif response.status_code == 400:
            print("Fehler: Ungültige Anfrage.")
            return []
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
        return []

def init_agents_skills(access_token):
    """
    Initialisiert und gibt eine JSON-Datei zurück, die alle Skills, Agents und Agent-Skills enthält.

    :param access_token: Der Authentifizierungs-Token.

    :return: JSON-Datei mit Skills, Agents und Agent-Skills
    """
    try:
        all_skills = get_all_skill_names(access_token)
        all_agents = get_all_agent_ids(access_token)
        agent_skills = []

        for agent_id in all_agents:
            skills = get_agent_skills(agent_id, access_token)
            for skill_entry in skills:
                skill_parts = skill_entry.split(" - ")
                skill_name = skill_parts[0]
                skill_level = skill_parts[1] if len(skill_parts) > 1 else ""
                agent_skills.append({
                    "agent_id": agent_id,
                    "skill_name": skill_name,
                    "skill_level": skill_level
                })
        result = {
            "skills": all_skills,
            "agents": all_agents,
            "agent_skills": agent_skills
        }
        json_result = json.dumps(result, indent=4, ensure_ascii=False)
        print("JSON-Daten erfolgreich generiert.")
        return json_result
    except Exception as e:
        print(f"Fehler bei der Initialisierung: {e}")
        return {"error": str(e)}

def chatgpt_query(prompt = "What is the number of the universe? Answer only with the joking answer.",
                  system_prompt = "You are a helpful assistant that provides concise answers.",
                  tokens = 50,
                  temperature = 0.5,
                  model = "gpt-3.5-turbo"):
    """
    Queries the OpenAI ChatGPT API with a custom user prompt and system behavior prompt, allowing adjustments to the model, token limit, and temperature.

    :param prompt: The main user query that defines the request for ChatGPT.
    :param system_prompt: A prompt to define the assistant's behavior.
    :param tokens: The maximum number of tokens for the response. Determines the response length.
    :param temperature: A value between 0 and 1 that controls the randomness of the response.
                        - Lower values result in more deterministic responses.
                        - Higher values produce more creative and varied outputs.
    :param model: The name of the OpenAI model to be used. Defaults to "gpt-3.5-turbo".

    :return: The response from ChatGPT as a clean string.
    """
    # Retrieve OpenAI API key
    api_key = os.getenv("OPENAI_API_KEY")
    # openai.api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OpenAI API key is missing. Ensure it is set in the environment variables.")
    # Initialize the OpenAI client with the API key
    client = OpenAI(api_key=api_key)
    # Send request to the ChatGPT API
    try:
        # return "No skill!!"
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            max_tokens=tokens,
            temperature=temperature
        )
        # Extract and return the response content
        return response.choices[0].message.content.strip()
        # return response["choices"][0]["message"]["content"]
    except Exception as e:
        raise Exception(f"Error communicating with the OpenAI API: {e}")

def chatgpt_skill_analyze_rating(system_prompt=SYSTEM_PROMPT, request="", skill_list=None, tokens=TOKENS):
    """
    Analyzes a request to determine the required skill and its rating level ('gut', 'mittel', or 'schlecht').

    :param system_prompt: General system behavior prompt for ChatGPT.
    :param request: The text of the user request to be analyzed.
    :param skill_list: List of available skills for analysis.
    :param tokens: Maximum number of tokens allowed in ChatGPT's response.

    :return: A formatted string with the request, skill, and rating level.
    """
    if skill_list is None:
        skill_list = SKILLS
    # Check for empty request
    if not request.strip():
        return "Request: No valid input provided\nRating: Invalid"
    # Generate the prompt for ChatGPT
    general_prompt = (
        "You are tasked with determining the required skill and its level of proficiency for a given user request.\n"
        "You can choose the skill level from: 'gut', 'mittel', or 'schlecht'.\n\n"
        "Here are the definitions for each rating:\n"
        "'schlecht': The task requires minimal experience with the skill. Basic or introductory knowledge is sufficient.\n"
        "'mittel': The task requires moderate knowledge and experience with the skill but does not demand deep expertise.\n"
        "'gut': The task requires advanced expertise, specialized knowledge, or significant experience with the skill.\n\n"
        "Skills to choose from: {skills}\n\n"
        "### Your Task:\n"
        "Request text: '{request}'\n"
        "Provide your response in this exact format: {{\"skill\": \"Skill Name\", \"rating\": \"schlecht/mittel/gut\"}}."
        "If the request is unrelated to any listed skills, respond with: {{\"skill\": \"None\", \"rating\": \"Invalid\"}}.\n\n"
    ).format(skills=', '.join(SKILLS), request=request)
    try:
        # Send the request to the ChatGPT API and retrieve the response
        response_text = chatgpt_query(prompt=general_prompt, system_prompt=system_prompt, tokens=tokens, temperature=0, model=MODEL)
        print("Raw API Response from chatgpt_skill_anaylze_rating:", response_text)
        try:
            # Parse response as JSON
            skill_data = json.loads(response_text)
            if isinstance(skill_data, dict) and 'skill' in skill_data and 'rating' in skill_data:
                # Validate the rating value
                if skill_data['rating'] not in ['gut','mittel', 'schlecht']:
                    skill_data['rating'] = "Invalid"  # Mark invalid rating
                return f"Skill: {skill_data['skill']} Rating: {skill_data['rating']}"
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON response: {e}")
    except Exception as api_error:
        print(f"Unexpected API Error: {api_error}")
        return f"Skill: Error communicating with API Rating: Invalid"
    # Handle cases where the response structure is unexpected
    return f"Skill: Unknown Rating: Invalid"

def format_skill_analysis(chatgpt_response):
    """
    Formatiert die Antwort von chatgpt_skill_analyze_rating in das Format "skill - rating".

    :param chatgpt_response: Die Antwort von chatgpt_skill_analyze_rating im Format:
        "Skill: Skill Name Rating: schlecht/mittel/gut"

    :return: Ein String im Format "skill - rating" (z.B. "UX-Kompetenz - gut")
    """
    try:
        # Überprüfen, ob die Antwort ein String ist
        if not isinstance(chatgpt_response, str):
            raise ValueError("Die Eingabe muss ein String sein.")
        # Extrahieren von Skill und Rating aus dem String
        skill_prefix = "Skill: "
        rating_prefix = "Rating: "
        
        if skill_prefix in chatgpt_response and rating_prefix in chatgpt_response:
            skill_start = chatgpt_response.index(skill_prefix) + len(skill_prefix)
            rating_start = chatgpt_response.index(rating_prefix) + len(rating_prefix)
            # Extrahieren der Skill- und Rating-Werte
            skill_name = chatgpt_response[skill_start:chatgpt_response.index(rating_prefix)].strip()
            rating = chatgpt_response[rating_start:].strip()
            # Überprüfen, ob die Bewertung gültig ist
            if rating in ['gut', 'mittel', 'schlecht']:
                return f"{skill_name} - {rating}"
            else:
                raise ValueError("Ungültige Bewertung gefunden")
        else:
            raise ValueError("Ungültiges Format der Antwort")
    except ValueError as e:
        print(f"Fehler beim Formatieren der Antwort: {e}")
        return None

def fetch_object(data_object_id, access_token):
    """Diese Funktion ruft die Daten eines Objekts anhand der Objekt-ID ab."""
    # Baue die URL für den Endpunkt, um das spezifische Objekt abzurufen
    endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}"
    # Setze die Header, die das Access Token und das akzeptierte Datenformat (JSON) enthalten
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    try:
        # Sende die GET-Anfrage an den Endpunkt
        response = requests.get(endpoint_url, headers=headers)
        # Überprüfe, ob die Anfrage erfolgreich war (Statuscode 200)
        if response.status_code == 200:
            # Extrahiere die Daten im JSON-Format
            data = response.json()
            print("Daten erfolgreich abgerufen:")
            # Gib die Daten formatiert aus
            print(json.dumps(data, indent=4))
            return data
        elif response.status_code == 400:
            print(f"Fehler: Ungültige Anfrage (Statuscode {response.status_code}).")
        elif response.status_code == 404:
            print(f"Fehler: Objekt mit ID {data_object_id} nicht gefunden (Statuscode {response.status_code}).")
        elif response.status_code == 401:
            print(f"Fehler: Unbefugter Zugriff (Statuscode {response.status_code}). Token möglicherweise ungültig.")
        elif response.status_code == 500:
            print(f"Fehler: Serverfehler (Statuscode {response.status_code}). Bitte später erneut versuchen.")
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
    except requests.exceptions.RequestException as e:
        # Wenn es ein Problem mit der Anfrage gibt, fange die Ausnahme ab und gebe den Fehler aus
        print(f"Fehler bei der Anfrage: {e}")

def get_object_type(data_object_id, access_token):
    """
    Ruft den Typ eines Objekts ab.
    
    :param: data_object_id: Die ID des Objekts, das abgerufen werden soll.
    :param access_token: Das Authentifizierungs-Token.
    
    :return: Der Objekttyp als String, oder None bei Fehler.
    """
    endpoint_url = f"{BASE_URL}/api/v1/objects/{data_object_id}/values"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    params = {
        "propertyPaths": ["system.type-name"]
    }
    try:
        # HTTP GET-Anfrage
        response = requests.get(endpoint_url, headers=headers, params=params)
        if response.status_code == 200:
            # JSON-Daten extrahieren
            data = response.json()
            # Versuchen, den Typ aus den Werten zu extrahieren
            type_name = data.get("values", {}).get("system.type-name", None)
            if type_name:
                return type_name
            else:
                print("Der Objekttyp konnte nicht gefunden werden.")
                return None
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
        return None

def extract_link_definitions_by_types(object_types, access_token):
    """
    Extrahiert eine spezifische Link-Definition basierend auf den angegebenen Objekt-Typen.
    
    :param object_types: Ein Dictionary mit 'word1' und 'word2' als Definitionen der Objekttypen.
    :param access_token: Das Authentifizierungs-Token.
    
    :return: Ein Dictionary mit 'linkDefinitionName' und 'relationName', oder None, falls keine passende Definition gefunden wird.
    """
    # Abrufen aller Link-Definitionen über die get_all_link_definitions-Methode
    link_definitions = get_all_link_definitions(access_token)
    if not link_definitions:
        print("Fehler beim Abrufen der Link-Definitionen.")
        return None
    left_object_type = object_types.get("word1")
    right_object_type = object_types.get("word2")
    # Variable für die Zählung der passenden Definitionen
    matched_definitions = []
    # Durchsuchen der Link-Definitionen nach passender Definition
    for definition in link_definitions:
        left_to_right = definition.get("leftToRight", {})
        right_to_left = definition.get("rightToLeft", {})

        left_source = left_to_right.get("source", {})
        right_source = right_to_left.get("source", {})
        if (left_source.get("definitionName") == left_object_type and
                right_source.get("definitionName") == right_object_type):
            matched_definitions.append({
                "linkDefinitionName": definition.get("name"),
                "relationName": left_to_right.get("relationName"),
            })
    # Ausgabe, wie viele passende Definitionen gefunden wurden
    print(f"Anzahl der passenden Definitionen für {left_object_type} und {right_object_type}: {len(matched_definitions)}")
    if matched_definitions:
        return matched_definitions[0]  # Gibt die erste passende Definition zurück
    else:
        print("Keine passende Route-Definition gefunden.")
        return None

def get_all_link_definitions(access_token):
    """
    Ruft alle Link-Definitionen von der API ab.

    :param access_token: Der Authentifizierungs-Token.

    :return: Eine Liste aller Link-Definitionen oder None bei Fehler.
    """
    # Endpunkt-URL für den Abruf aller Link-Definitionen
    endpoint_url = f"{BASE_URL}/api/v1/link-definitions"
    # Header für die GET-Anfrage mit Authentifizierung
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
    }
    try:
        # Sende die GET-Anfrage
        response = requests.get(endpoint_url, headers=headers)
        # Überprüfe den Statuscode der Antwort
        if response.status_code == 200:
            # JSON-Daten extrahieren
            data = response.json()
            link_definitions = data.get("linkDefinitions", [])
            print(f"Erfolgreich {len(link_definitions)} Link-Definitionen abgerufen.")
            return link_definitions
        else:
            print(f"Fehler: Statuscode {response.status_code}, Antwort: {response.text}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e}")
        return None

def remove_link(data_object_id, linked_object_id, access_token):
    """Entfernt einen Link von einem Objekt."""
    # Abrufen der Objekttypen
    object_type_1 = get_object_type(data_object_id, access_token)
    object_type_2 = get_object_type(linked_object_id, access_token)
    if not object_type_1 or not object_type_2:
        print("Fehler: Objekttypen konnten nicht abgerufen werden.")
        return None
    # Link-Definitionen basierend auf den Typen extrahieren
    link_definition = extract_link_definitions_by_types(
        {"word1": object_type_1, "word2": object_type_2},
        access_token
    )
    if not link_definition:
        print("Keine passende Link-Definition gefunden.")
        return None
    # URL und Header für die Anfrage
    url = f"{BASE_URL}/api/v1/objects/{data_object_id}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    # Payload erstellen
    payload = {
        "links": [
            {
                "linkDefinitionName": link_definition["linkDefinitionName"],
                "relationName": link_definition["relationName"],
                "remove": [linked_object_id],
            }
        ]
    }
    try:
        # PATCH-Anfrage
        response = requests.patch(url, json=payload, headers=headers)
        # Überarbeitung der Statuscode-Logik
        if response.status_code == 200:
            print("Link erfolgreich entfernt.")
            return response  # Kein weiterer Output notwendig
        elif response.status_code == 400:
            print("Fehlerhafte Anfrage:", response.json())
        elif response.status_code == 404:
            print("Objekt nicht gefunden.")
        elif response.status_code == 409:
            print("Konflikt beim Entfernen des Links:", response.json())
        else:
            print(f"Unerwarteter Fehler: {response.status_code}, {response.text}")
        return response
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Anfrage: {e} (Wahrscheinlich gab es zwischen den Objekten keinen Link)")
        return None



def lambda_handler(event, context):
    """Funktion zur Rückgabe der Agent ID für eine Anfrage."""
    try:
        # Schritt 1: Zugriffstoken abrufen
        access_token = get_access_token()
        if not access_token:
            return {
                'statusCode': 401,
                'body': json.dumps("Access Token konnte nicht abgerufen werden.")
            }
        
        # Schritt 2: Request ID extrahieren
        body = json.loads(event.get("body", "{}"))
        request_id = body.get("id")
        if not request_id:
            return {
                'statusCode': 400,
                'body': json.dumps("Request ID fehlt im Request-Body.")
            }
 
        # Schritt 3: Abrufen der Aufgabenbeschreibung
        request_text = get_subject_and_description(request_id, access_token)
        request = f"Titel:\n{request_text.get('subject')}\nBeschreibung:\n{request_text.get('description')}"
        
        # Schritt 4: Analyse der erforderlichen Fähigkeiten
        skill_list = get_all_skill_names(access_token)
        skill_analysis = chatgpt_skill_analyze_rating(
            system_prompt=SYSTEM_PROMPT,
            request=request,
            skill_list=skill_list,
            tokens=TOKENS
        )
        formatted_skill = format_skill_analysis(skill_analysis)

        # Schritt 5: Initialisierung der Fähigkeiten der Agenten
        agents_skills_json = init_agents_skills(access_token)
        agent_data = json.loads(agents_skills_json)
        if not agent_data or "agent_skills" not in agent_data:
            return {
                'statusCode': 500,
                'body': json.dumps("Fehler beim Laden der Fähigkeiten der Agenten.")
            }

        agent_skills = {}
        for entry in agent_data["agent_skills"]:
            agent_id = entry["agent_id"]
            skill_name = entry["skill_name"]
            skill_level = entry["skill_level"]
            if agent_id not in agent_skills:
                agent_skills[agent_id] = {}
            agent_skills[agent_id][skill_name] = skill_level
        
        # Schritt 6: Finden des passenden Agenten
        suitable_agent_id, _ = find_best_agent_for_skill(formatted_skill, agent_skills)

        # Schritt 7: Rückgabe der Agent ID 
        return {
            'statusCode': 200,
            'body': suitable_agent_id 
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Ein Fehler ist aufgetreten: {str(e)}")
        }
