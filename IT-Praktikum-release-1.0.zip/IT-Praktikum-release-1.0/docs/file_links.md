# Links zu sämtlichen Dateien, die während des Projekts bearbeitet wurden

## Allgemein

Es gibt keinen Report, Retro, Review oder Notizen dazu für den Sprint 4, da dieser in der Winterpause war. Aber die Arbeit in der Zeit wurde in Report 5 abgehandelt.

### Arbeitszeittabelle
[Google-Sheets-Link](https://docs.google.com/spreadsheets/d/1Xr9x0_rXhtw-_N0IAWgys3HOj0YDLzXkFJ74ODZ6eeo/edit?gid=0#gid=0)

### Benutzerhandbuch
[Google-Docs-Link](https://docs.google.com/document/d/1mQBKxgl05HLzxmK-FFZySlugvd36oWqt28KIImxvHmM/edit?usp=sharing)  
[Word-Link](https://studtudarmstadtde-my.sharepoint.com/:w:/g/personal/jawor_kostadinov_stud_tu-darmstadt_de/ERZC0N2J7L9Pv_ECGTtOGRkBTMBQyS4_8Vfs4xSevwVphg?e=Tsq077)

### Abschlussbericht mit Vorlage
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/EXsKgpvRwRRBguLF0Ff5Y2YBqVe_vrNtgWkItr4ut1Cs7w?e=qv08Hw)

### Abschlussbericht v1 ohne Vorlage
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/EY90rZkxv2tDi4o8BEuhK1AB0VQfgcp5jqy-putZ2q-iHQ?e=Z0FYez)

### Abschlusspräsentation
[PowerPoint-Link](https://1drv.ms/p/c/ae6f75c5e31814a9/ERn_tlgSXltMmrSrnNVNfFEBOMBsdDRpxL9lo8sv7X6VRw?e=kFdhx4)

### Definition of Done
[Google-Docs-Link](https://docs.google.com/document/d/1nvwoQbaZbf4PiG9VfYmSO52xXe4ViHTpCFnX_4XUDXY/edit?usp=sharing)

### Zielbild 
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/zakariye_geedi_stud_tu-darmstadt_de/EReWhjOaYqhLkOUoHUmRpl0B2-NG9CvyVLBMyjq32oK0bQ?e=Ekd5ap)

### Uni Zwischenpräsentation 16.1
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/jawor_kostadinov_stud_tu-darmstadt_de/EUYvvZJMB9xFi_bXHzvOtJsBR74YMFIHM-2LavdhkZCGlw?e=LeDSiV)

### Projekt Timeline für Abschlussbericht
[PowerPoint-Link](https://1drv.ms/p/c/9d3f6c0abd442145/EQuF2Mlv2XZCmL8hR4Ec4koB0TY7T4FXMsYTBF-ROroHwg?e=7lac6c)


## SW Meeting Notizen

### Sondermeeting #1 mit Tristan
Link nicht vorhanden, weil keine Notizen gemacht wurden

### Sondermeeting #2 mit Tristan
[Google-Docs-Link](https://docs.google.com/document/d/1nVmNMQ67nhD89YPElcwUBZb1RXgZPOArODtSmdZpoig/edit?usp=sharing)

### Sprint Review Notizen 1
[Google-Docs-Link](https://docs.google.com/document/d/1Bo9b4u6uTyXDpIg-JrxjMqmZ3n_55mz9Ff4odR-ti0c/edit?usp=sharing)

### Sprint Review Notizen 2
[Google-Docs-Link](https://docs.google.com/document/d/1FiwnXup8R1OFrQqIZmzYYsvg1mM3TuKH0fySNBMqp9k/edit?usp=sharing)

### Sprint Review Notizen 3
[Google-Docs-Link](https://docs.google.com/document/d/1KMp8NIYPw9C5elXdP9BGF3neq0VoQuT1RwXEFy0-u1A/edit?usp=sharing)

### Sprint Review Notizen 5
[Google-Docs-Link](https://docs.google.com/document/d/1iZw8OyauMJibZ34R2TPZrNMRLJdmjCkgqTl43KIiBdo/edit?usp=sharing)

### Midterm Notizen 24.1
[Google-Docs-Link](https://docs.google.com/document/d/1eVoer-YDcPDoqSCiLOrZoKmZE8Gq28VqOMSI1ZEZVBk/edit?usp=sharing)

### Sprint Review Notizen 6
[Google-Docs-Link](https://docs.google.com/document/d/1y3Dg_S7blqpN4_Okc2O6c9r5xKHxJ2zxeJUwKYVrDyg/edit?usp=sharing)

### Sprint Review Notizen 7
[Google-Docs-Link](https://docs.google.com/document/d/1aEC-xJVe8iqDA5Tq_0s490M5rUIdhWjBxDmnHBfRRYg/edit?usp=sharing)


## Sprint Reviews

### Sprint Review 1
Keine Präsentation, nur [diese automated_backend.py demo](https://github.com/IT-Praktikum-Serviceware/IT-Praktikum/blob/2111141028c2e89ac79827d3edd52a4ffa2502bd/backend/automated_backend.py) und die ReadMe dazu (veraltet seit dem 21.11.24)

### Sprint Review 2
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/philipp_rauch_stud_tu-darmstadt_de/Ecv7F32ez3NFlJZH556o4YQBjtzF3oNR53zv5sCo0Crpig?e=ymEvYR)

### Sprint Review 3
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/philipp_rauch_stud_tu-darmstadt_de/ETvEr83Yb3RMtt6YW5XXKCABNtiIkhPlj8oaP58ooYhGHw?e=gA6kwd)

### Sprint Review 5
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/philipp_rauch_stud_tu-darmstadt_de/ERDz9oi5Cc1KqNJb65VviwUBrHPRYzEX3687IwU45go_IA?rtime=LGsA0Pgz3Ug)

### Midterm Präsentation bei Serviceware 24.1
[PowerPoint-Link](https://1drv.ms/p/c/9d3f6c0abd442145/EXh8ZizyYvJPg1M68Nhfq8UBx1PIHc7C0NH_Bi-1K8V13A?e=ctnCH5)

### Sprint Review 6
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/vuong_trinh_stud_tu-darmstadt_de/EVF9qtbX4ApHl4i03R4pdo4BnuPDESx9IQw6xQQXq6R35g?e=DwfcVu)

### Sprint Review 7
[PowerPoint-Link](https://studtudarmstadtde-my.sharepoint.com/:p:/g/personal/philipp_rauch_stud_tu-darmstadt_de/ESoWgW8yiZxKktOsFhGMtyoBOLe9NhXNeP60f6rdYFCldQ?e=xzGLVC)


## Sprint Reports

### Sprint Report 1
[Google-Docs-Link](https://docs.google.com/document/d/1kdsWy_3EmFAUyvyvS7hyKrk-ERBoXgkUgirhC2L57YQ/edit?usp=sharing)

### Sprint Report 2
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/EUGNm235yb1EpXL3lqcU4S0Bs7WyUNm7WKmbvc1UjnPrZQ?e=oWq1dv)

### Sprint Report 3
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/EazTsmf5odpDkA9MQiiwh-8BX_LnA13z43AKC--f79U6zA?e=XioAyk)

### Sprint Report 5
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/EYixVt3RLV5Ir3AdPfC8szYBHR6UDA8qQXKCcKaSJB_N1Q?e=e1oFdZ)

### Sprint Report 6
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/EaVtSFSIHeZBrT-2Gv7wRk8BOumfw5l80vRvP8H2RqfLwQ?e=hIB5vC)

### Sprint Report 7
[Word-Link](https://1drv.ms/w/c/9d3f6c0abd442145/Ec34yR6hbelEl1fz1ZKjZx8BoO4AzVo_SVQeioC1f6Eiig?e=FOM2cl)


## Sprint Retros

### Sprint Retro 1
[Google-Docs-Link](https://docs.google.com/document/d/1uVuy5RzySXGPOSrmn3vZl_6B-JE2SQ2p9tmPj5LrbVk/edit?usp=sharing)

### Sprint Retro 2
[Google-Docs-Link](https://docs.google.com/document/d/1ovW6kxpp0LJ5_3nqbDF6V0zI4zPpO2SOsmLdprzVdgE/edit?usp=sharing)

### Sprint Retro 3
[Google-Docs-Link](https://docs.google.com/document/d/1aR6YYRSc2HIWygTQJH514nbUOFkqxV57jC0DO_7kqTw/edit?usp=sharing)

### Sprint Retro 5
[Google-Docs-Link](https://docs.google.com/document/d/1tGXoX0xP6T25n5v0tlRA2mhDP1UarYDKXK5r8VaHVVM/edit?usp=sharing)

### Sprint Retro 6
[Google-Docs-Link](https://docs.google.com/document/d/1jhRgVm_fqp5gnr9dinjmb8vFHzYIvuIlctIGXn_pO6s/edit?usp=sharing)

### Sprint Retro 7
[Google-Docs-Link](https://docs.google.com/document/d/1MYwk26jizatkVi3QtxznAhD1rSdXws4R945u5_ZrP6c/edit?usp=sharing)
