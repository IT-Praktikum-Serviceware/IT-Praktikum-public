##### Note: This version of the readme can be edited anytime if you want to. Just be careful in the readme in the root directory. Better yet, do not touch it, unless you know what you are doing or you told the team.
# IT-Praktikum 24/25 ServiceWare
Code repository for the practical IT project management module in the winter semester 24/25.

## Current State:
Release of sprint 4 - 07.01.2025

## ToDos

### General
- Look in Discord for new messages and be up to date.
- Take a look in to the [Jira project](https://tuda.atlassian.net/jira/software/projects/SW/boards/28/backlog?epics=visible) and check your assigned tasks.
- Take a look in the [GitHub Issues](https://github.com/lolepp/IT-Praktikum/issues) and [Pull Requests](https://github.com/lolepp/IT-Praktikum/pulls). Perhaps you have been assigned a task or have one open.
- Update your project, someone surely has committed somewhere, if not, nothing bad happens
    - Remember, you do this using `git pull`, also a `git fetch origin` (literally) cannot hurt
- Read the [ServiceWare documentation](https://docs.serviceware-se.com/serviceware-platform/de/ai_process_engine.html)
- Code the very first MVP
- Product Backlog Refinement -> If you have any ideas feel free to share them or just add them in the Jira Backlog. Kind of really important to push this project forward.
- Code Review
- Expand documentation
- Keep README & BPMN Diagram up to date

### Development
- Documentation of (reused) code, also kind of really important!
- Extend and automate skill routing module (skill rating, analyze skill,...)
- Create a workflow in the AIPE that can be executed
- Work more with the AIPE -> map skill rating in the AIPE,...
- Implement a function “Get_agent_name” that reads and returns the name of the agent
- Solve database IP connection problem

### Very First MVP:
1. Automatically deriving the required skills based on existing requests
2. Assigning those skills to agents automatically
3. Automatically detecting the required skill(s) for an incoming, new request
4. Automatically routing this request to the agent(s) with the best matching skills

### Things to be sorted out after the MVP:
- Figure out 24/7 service
- Figure out deployment and production
- Set up docker and containerize
- Set up CI pipeline
- Implement a skill updater 
- User should receive a response from the backend & the status of their request should be updated
- Implement tests
- Figure out optimal statistical optimization/allocation algorithms
- Implement a small frontend

## Getting started

### GitHub Tips
- Clone this repo
- Open terminal
- Use git **checkout \<branch>** to open the branch you want to work on
- With **git add .** changes are saved for the next commit; instead of the dot you can specify which files should be added
- **git commit -m “\<message here>”** is the reference that is then pushed
- With **git push origin \<branch>** all commits are pushed
- **git pull** fetches all changes from the repo and merges them directly
- With **git fetch origin (\<branch>)** all changes (from a special branch) are downloaded from the online repo
- Use **git merge \<branch>** to integrate changes from the specified branch into the current branch
- Commands for information:
    - **git branch** (which branch you are on or have locally),
    - **git status** (current local changes compared to the last commit),
    - **git log** (check the log of all commits (on the selected branch)),
    - **git -help** (shows the help view for git, can also be combined with other commands)
    - **git --help** (opens local html documentation for git, can also be combined with other commands)
- **Keep the security of confidential information in mind**, more information here:

    [Removing confidential data from a repository](https://docs.github.com/de/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository)
    
    [Support GitHub](https://support.github.com/request)

### Weblinks
[Webclient of Serviceware](https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/)

[Dokumentation of the Serviceware AI Process Engine](https://docs.serviceware-se.com/serviceware-platform/de/ai_process_engine.html)

[RestAPI](https://petstore.swagger.io/?url=https://tud-praktikum-24.ai-process-engine.testing.swops.cloud/data/docs)

[GitHub Repository](https://github.com/lolepp/IT-Praktikum)

## Project structure

### UML diagram
![UML-Diagramm](assets/it-praktikum-v3.0.png)

### Processes
A short overview in what order and  how the architecture of our software and of the AIPE currently functions. A glossary of used abbreviations is below.

#### Skill-Based-Routing Backend Process
1. **Request Initiation by User**
    - The user (or the client application) submits a request through the AIPE UI.
    - This step is managed by the AIPE frontend of SW.
2. **REST API to Backend: Request Handling**    
  The backend processes all pending requests (i.e., requests without an assigned agent) retrieved from the AIPE Data Explorer using the REST API.
    - It fetches all unprocessed requests.
    - For each request, the full object is retrieved, including its title and description.
    - These details are extracted and structured to be passed on for further processing.
3. **ChatGPT API: Skill Analyzing & Answer**  
  The backend sends the request's title and description as a structured prompt to the ChatGPT API to identify the required skills.
     - For each unprocessed request, the title and description are retrieved and combined into a structured request prompt.
     - The list of skills provided to ChatGPT is pulled from the AIPE Data Explorer, where skills are stored with different levels of proficiency (e.g., basic, good, expert).
     - ChatGPT analyzes the input and returns the required skill(s).
     - The identified skills are collected and prepared for the next processing step.
4. **Skill Matching**  
 The backend identifies suitable agents from the ~~Database~~ AIPE Data Explorer who possess the required skills determined by ChatGPT.
    - The system matches agents based on skill proficiency.
    - A list of suitable agent names is returned, ready for assignment to the respective requests.
5. **Backend to REST API: Answer**  
 The backend assigns the requests to the identified agents and updates their status using the REST API. The system prepares notifications:
    - The user is notified: “Your request has been assigned to [Agent Name], who will contact you shortly.”
    - The assigned agent is notified: “A new request has been assigned to you .”  
    - If no suitable agent is available: “There are currently no agents available with the requested qualifications.”
6. **User and Agent Receive the Update**  
 The current state of the request, along with the assigned agent's details, is displayed in the AIPE UI for both the user and the agent. 

#### AIPE Process
1. **Request Creation**
    - The user (or client application) submits a request through the AIPE UI.
    - This step is managed by the AIPE frontend of SW.
2. **Backend Process Triggered**  
   The backend process starts automatically based on a defined trigger event by the  user in AIPE, such as:
     - a button click
     - regular checks for new requests
3. **Quick Action Boundary Event**  
    Once the user request is created, a Quick Action button becomes available in the user workspace for manual intervention. The request is automatically routed based on user actions:
    - **Route to Skilled Agent:** If the user presses the button, the request is routed to an agent with the necessary skills.
    - **Route to HelpDesk:** Otherwise, the request is escalated for manual handling.
4. **Request Processing**
    - The backend fetches and analyzes the request data via the REST API.
    - This includes retrieving the request’s title, description, and relevant details for further processing.
5. **Skill-Based Agent Matching** 
    - The system identifies agents with the required skills from AIPE Data Explorer and matches the request to the most suitable available agent.
6. **Response to User and Agent**  
  The user and assigned agent are notified of the request’s status:
    - If an agent is found: “Your request has been assigned to  [Agent Name], who will contact you shortly.”
    - If no agent is available: “There are currently no agents available with the requested qualification.”
    - The assigned agent also receives a notification: “This request has been assigned to you.”


#### Glossary
- AIPE = AI Process Engine
- SW = ServiceWare
- DB = Database
