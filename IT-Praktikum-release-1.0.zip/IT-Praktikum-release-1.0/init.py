from src.main.rest_api.scripts.aipe_skill_init import main

# The central initialization script for creating skills and the according links to predefined users in the AIPE with using ChatGPT for skill analysis

if __name__ == "__main__":
    main()
